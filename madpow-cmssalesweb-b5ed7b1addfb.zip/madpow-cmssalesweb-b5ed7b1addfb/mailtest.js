let mailer = require('nodemailer')

let transporter = mailer.createTransport({
  type: 'smtp',
  host: 'email-smtp.us-east-1.amazonaws.com',
  port: 465,
  secure: true,
  auth: {
    user: 'AKIAIYXGJWHODTL7QFUA',
    pass: 'AkKULr9kTYeS4C6dCu7KWy454o+5TuFtFjdRsBZQ7Lnb'
  }
});

let email = {
  from: 'info@espnsalesapp.com',
  to: 'ken.dunnington@gmail.com',
  subject: 'Test',
  text: 'This is a test',
  html: '<h1>This is a test</h1>'
}
transporter.sendMail(email, (err, result) => {
  if (err) {
    console.log(err)
  } else {
    console.log(result)
  }
})