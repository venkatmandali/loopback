import angular from 'angular'
import ngResource from 'angular-resource'
import ngAnimate from 'angular-animate'
import ngTouch from 'angular-touch'
import ngSanitize from 'angular-sanitize'
import ngMessages from 'angular-messages'

import uiRouter from '@uirouter/angularjs'
import uiBootstrap from 'angular-ui-bootstrap'
import uiGrid from 'angular-ui-grid'
import uiGridDraggableRows from 'ui-grid-draggable-rows'

import treeControl from 'angular-tree-control'
import contextMenu from 'angular-tree-control/context-menu'
import ngTagsInput from 'ng-tags-input'

import lodash from 'lodash'
import ngFileUpload from 'ng-file-upload'

import videogular from 'videogular/dist/videogular/videogular.js'
import videogularControls from 'videogular/dist/controls/vg-controls.js'
import videogularOverlayPlay from 'videogular/dist/overlay-play/vg-overlay-play.js'
import videogularPoster from 'videogular/dist/poster/vg-poster.js'

import globalStyles from '../asset/scss/app.scss'

import config from './app.config'

import lbServices from './lb-services'

import NavigationComponent from './navigation/navigation.component'

import Common from './common'
import Login from './login'
import Dashboard from './dashboard'
import Users from './users'
import Tags from './tags'
import Assets from './assets'
import Categories from './categories'
import Newsfeed from './newsfeed'
import SharedConversations from './shared-conversations'
import Reports from './reports'

let app = angular.module('cmssalesweb', [
  uiRouter,
  ngResource,
  ngTouch,
  ngAnimate,
  ngSanitize,
  ngMessages,
  ngFileUpload,
  uiBootstrap,
  uiGrid,
  'ui.grid.draggable-rows',
  'ui.grid.pagination',
  'ui.grid.autoResize',
  treeControl,
  'ngTagsInput',
  'com.2fdevs.videogular',
  'com.2fdevs.videogular.plugins.controls',
  'com.2fdevs.videogular.plugins.overlayplay',
  'com.2fdevs.videogular.plugins.poster',
  lbServices,
  Common,
  Dashboard,
  Login,
  Users,
  Tags,
  Assets,
  Categories,
  Newsfeed,
  SharedConversations,
  Reports
])

app.constant('AppConfig', config)
app.constant('_', lodash)
app.component(NavigationComponent.selector, NavigationComponent.config)

/* @ngInject */
// app.config((LoopBackResourceProvider, AppConfig) => {
//   LoopBackResourceProvider.setUrlBase(AppConfig.lbBaseUrl + '/api')
// })

/* @ngInject */
app.config($compileProvider => {
  $compileProvider.aHrefSanitizationWhitelist(
    /^\s*(https?|mailto|itms-services):/
  )
})

/* @ngInject */
app.config($httpProvider => {
  /* @ngInject */
  $httpProvider.interceptors.push(($q, LoopBackAuth, $state, AppConfig) => {
    return {
      responseError: function(rejection) {
        if (rejection.status === 401) {
          if (AppConfig.noAuth.indexOf($state.current.name) === -1) {
            // Clearing the loopback values from client browser for safe logout...
            LoopBackAuth.clearUser()
            LoopBackAuth.clearStorage()
            if ($state.current.name !== 'login') {
              $state.nextAfterLogin = $state.current
            }
            $state.go('login')
          }
        }
        return $q.reject(rejection)
      }
    }
  })
})

/* @ngInject */
app.config(
  (
    $stateProvider,
    $locationProvider,
    $urlRouterProvider,
    $transitionsProvider
  ) => {
    $locationProvider.html5Mode(true)
    $urlRouterProvider.otherwise('/')
    // $transitionsProvider.onStart({}, (transition) => {
    //   console.log(transition)
    // })
  }
)
/* @ngInject */
// app.run(function($trace) { $trace.enable('TRANSITION'); })
/* @ngInject */
app.run(function(AppConfig, UserProfile, $transitions) {
  let noAuth = AppConfig.noAuth
  $transitions.onStart(
    {
      to: function(state) {
        return noAuth.indexOf(state.name) === -1
      },
      from: true
    },
    function(trans) {
      if (!UserProfile.isAuthenticated()) {
        // User isn't authenticated. Redirect to a new Target State
        return trans.router.stateService.target('login')
      } else {
        return UserProfile.getCurrent({
          filter: {
            include: 'roles'
          }
        }).$promise.then(function(user) {
          let authorized = user.roles.some(function(role) {
            return role.name === 'administrator'
          })
          if (!authorized) {
            return trans.router.stateService.target('unauthorized')
          } else {
            return authorized
          }
        })
      }
    }
  )
})

export default app.name
