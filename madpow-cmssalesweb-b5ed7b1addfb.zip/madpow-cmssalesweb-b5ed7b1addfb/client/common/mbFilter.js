export default function () {
  return function (value) {
    let result = value
    let kb = 1024
    let mb = kb * 1024
    let gb = mb * 1024
    if (value < kb) {
      result = value + ' B'
    } else if (value < mb) {
      result = Math.ceil(Math.round((value / kb) * 1000) / 1000) + ' KB'
    } else if (value < gb) {
      result = Math.ceil(Math.round((value / mb) * 1000) / 1000) + ' MB'
    } else {
      result = Math.ceil(Math.round((value / gb) * 1000) / 1000) + ' GB'
    }
    return result
  }
}
