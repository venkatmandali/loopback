import ViewModalController from './view-modal.controller'

export default {
  selector: 'viewModal',
  config: {
    controller: ViewModalController,
    template: require('./view-modal.html'),
    bindings: {
      resolve: '<',
      close: '&',
      dismiss: '&'
    }
  }
}
