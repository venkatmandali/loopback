export default function () {
  return function (input, start) {
    start = +start // ensure we have an int
    return input.slice(start)
  }
}
