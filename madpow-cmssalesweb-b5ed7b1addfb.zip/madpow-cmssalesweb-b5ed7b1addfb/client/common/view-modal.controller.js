export default class ViewModalController {
  constructor ($sce) {
    Object.assign(this, { $sce })
  }

  $onInit () {
    this.asset = this.resolve.asset
    if (this.asset.type.indexOf('image') > -1) {
      this.isImage = true
    }
    if (this.asset.type.indexOf('pdf') > -1) {
      this.isPDF = true
    }
    if (this.asset.type.indexOf('video') > -1) {
      this.isVideo = true
    }
    this.config = {
      sources: [
        { src: this.$sce.trustAsResourceUrl(this.asset.url), type: this.asset.type }
      ]
    }
  }

  download () {

  }
}
