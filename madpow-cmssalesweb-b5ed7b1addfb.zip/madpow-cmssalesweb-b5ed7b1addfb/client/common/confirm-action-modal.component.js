import ConfirmActionModalComponent from './confirm-action-modal.controller'

export default {
  selector: 'confirmActionModal',
  config: {
    controller: ConfirmActionModalComponent,
    template: require('./confirm-action-modal.html'),
    bindings: {
      resolve: '<',
      close: '&',
      dismiss: '&'
    }
  }
}
