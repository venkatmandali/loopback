import angular from 'angular'

import videogular from 'videogular/dist/videogular/videogular.js'
import videogularControls from 'videogular/dist/controls/vg-controls.js'
import videogularOverlayPlay from 'videogular/dist/overlay-play/vg-overlay-play.js'
import videogularPoster from 'videogular/dist/poster/vg-poster.js'

import ConfirmActionModalComponent from './confirm-action-modal.component'
import ViewModalComponent from './view-modal.component'
import ModalService from './modalService'

import mbFilter from './mbFilter'
import filenameFilter from './filenameFilter'
import capitalizeFilter from './capitalizeFilter'
import boolFilter from './bool-to-yesNo.filter'
import startFromFilter from './start-from.filter'

import ErrorService from './errorService'

export default angular.module('common', [])
  .component(ConfirmActionModalComponent.selector, ConfirmActionModalComponent.config)
  .component(ViewModalComponent.selector, ViewModalComponent.config)
  .filter('mb', mbFilter)
  .filter('filename', filenameFilter)
  .filter('capitalize', capitalizeFilter)
  .filter('bool', boolFilter)
  .filter('startFrom', startFromFilter)
  .service('ErrorService', ErrorService)
  .service('ModalService', ModalService)
  .name
