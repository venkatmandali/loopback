export default class ModalService {

  constructor($uibModal) {
    Object.assign(this, { $uibModal })

    this.hasModal = false
  }

  show(settings) {
    if (this.hasModal) {
      return false
    }
    this.hasModal = true

    const modal = this.$uibModal.open(settings)
    modal.result.catch(reason => {
      // Do nothing
    }).finally(() => {
      this.hasModal = false
    })
    return modal
  }

}
