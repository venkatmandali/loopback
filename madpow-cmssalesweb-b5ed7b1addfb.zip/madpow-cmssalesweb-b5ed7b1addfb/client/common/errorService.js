export default class ErrorService {
  /**
   * Process an error object returned from loopback
   * The loopback ValidationError object has this form
   * {
   *   "name": "ValidationError",
   *   "status": 422,
   *   "message": "The Model instance is not valid. \
   *   See `details` property of the error object for more info.",
   *   "statusCode": 422,
   *   "details": {
   *     "context": "user",
   *     "codes": {
   *       "password": [
   *         "presence"
   *       ],
   *       "email": [
   *         "uniqueness"
   *       ]
   *     },
   *     "messages": {
   *       "password": [
   *         "can't be blank"
   *       ],
   *       "email": [
   *         "Email already exists"
   *       ]
   *     }
   *   },
   * }
   * @param {any} err Angular HTTP error object
   *
   * @memberOf ErrorService
   */
  process (err) {
    let result = {
      message: []
    }
    let error = err.data.error
    if (error.name === 'ValidationError' && error.details) {
      let messages = error.details.messages
      let codes = error.details.codes
      for (let key in codes) {
        if (codes.hasOwnProperty(key)) {
          let codeItem = codes[key]
          for (let e = 0; e < codeItem.length; e++) {
            result[key] = {}
            result[key][codeItem[e]] = messages[key][e]
            result.message.push(messages[key][e])
          }
        }
      }
    } else if (error.name === 'InvalidParameterType' || error.message) {
      result.message.push(error.message)
      if (error.code) {
        result[error.code] = error.message
      }
    } else if (typeof error === 'string') {
      result.message = error
    }
    return result
  }
}
