export default function () {
  return function (value, delim = '/') {
    if (value) {
      return value.substr(value.lastIndexOf(delim) + 1)
    }
    return value
  }
}
