export default function () {
  return function (input) {
    return (input === true || input === 'true') ? 'Yes' : 'No'
  }
}
