export default class ConfirmActionModalComponent {

}
