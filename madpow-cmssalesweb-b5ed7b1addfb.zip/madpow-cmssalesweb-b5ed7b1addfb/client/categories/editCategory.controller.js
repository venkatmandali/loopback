export default class EditCategoryController {
  constructor (Category, $state, $uibModal, _) {
    Object.assign(this, { Category, $state, $uibModal, _ })
  }

  $onInit () {
    this.categoryId = this.category.id
    this.categoryOptions = {
      multiSelection: false,
      allowDeselect: true,
      isSelectable: (node) => {
        return node.id !== this.categoryId
      }
    }
    this.setupCategories()
  }

  setupCategories () {
    function find (array, id) {
      if (typeof array !== 'undefined') {
        for (var i = 0; i < array.length; i++) {
          if (array[i].id === id) {
            return [array[i]]
          }
          var a = find(array[i].children, id)
          if (a != null) {
            a.unshift(array[i])
            return a
          }
        }
      }
      return null
    }
    if (this.category.id) {
      this.expandedCategories = find(this.categories, this.category.parentId) || []
      if (this.category.parentId && this.expandedCategories.length) {
        this.categoryParent = this.expandedCategories[this.expandedCategories.length - 1]
      }
    }
  }

  depth (id) {
    let category = this.flatCategories[id]
    let level = 1
    while (category.parentId) {
      level++
      category = this.flatCategories[category.parentId]
    }
    return level
  }

  save () {
    this.errorMessage = null
    if (this.categoryParent) {
      // Check the depth of categoryParent
      let depth = this.depth(this.categoryParent.id)
      if (depth >= 5) {
        this.errorMessage = 'Categories may be no more than 5 levels deep.'
        return false
      }
      this.category.parentId = this.categoryParent.id
      this.category.isTopLevel = false
    } else {
      this.category.parentId = null
      this.category.isTopLevel = true
    }
    this.category.$save((result) => {
      this.$state.go('categories.list', null, { reload: true })
    }, (error) => {
      this.errorMessage = ''
      let messages = error.data.error.details.messages
      for (let message in messages) {
        this.errorMessage += messages[message].join('<br />')
      }
    })
  }

  delete () {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'category' },
        name: () => { return this.category.name },
        message: () => { return 'If the category is in use by any asset, those assets will lose this category.' }
      }
    }).result

    modal.then(() => {
      this.category.$delete((result) => {
        this.$state.go('categories.list', null, { reload: true })
      }, (error) => {
        this.errorMessage = error.data.error.message
      })
    })
  }
}
