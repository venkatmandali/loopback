/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'categories',
      abstract: true,
      url: '/categories',
      resolve: {
        categories: function (Category) {
          return Category.__get__all().$promise
        },
        flatCategories: function (Category) {
          return Category.find().$promise.then(function (categories) {
            let result = {}
            categories.forEach(function (category) {
              result[category.id] = category
            })
            return result
          })
        }
      },
      data: {
        title: 'Categories'
      }
    })
    .state({
      name: 'categories.list',
      url: '',
      component: 'categoryList'
    })
    .state({
      name: 'categories.edit',
      url: '/edit/{id}',
      component: 'editCategory',
      resolve: {
        category: function (Category, $transition$) {
          return Category.findById({ id: $transition$.params().id }).$promise
        }
      }
    })
    .state({
      name: 'categories.add',
      url: '/create',
      component: 'editCategory',
      resolve: {
        category: function (Category, $transition$) {
          return new Category()
        }
      }
    })
}
