import angular from 'angular'
import uiRouting from '@uirouter/angularjs'

import CategoryComponent from './categories.component'
import EditCategoryComponent from './editCategory.component'
import categoryRouting from './categories.routing'

/* @ngInject */
export default angular.module('categories', [uiRouting])
  .config(categoryRouting)
  .component(CategoryComponent.selector, CategoryComponent.config)
  .component(EditCategoryComponent.selector, EditCategoryComponent.config)
  .name
