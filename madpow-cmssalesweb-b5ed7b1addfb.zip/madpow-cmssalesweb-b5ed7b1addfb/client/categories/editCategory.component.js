import EditCategoryController from './editCategory.controller'

export default {
  selector: 'editCategory',
  config: {
    controller: EditCategoryController,
    template: require('./editCategory.html'),
    bindings: {
      categories: '<',
      flatCategories: '<',
      category: '<'
    }
  }
}
