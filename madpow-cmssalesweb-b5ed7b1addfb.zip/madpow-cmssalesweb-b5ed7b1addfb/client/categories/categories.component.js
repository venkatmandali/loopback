import CategoryController from './categories.controller'

export default {
  selector: 'categoryList',
  config: {
    controller: CategoryController,
    template: require('./categories.html'),
    bindings: {
      categories: '<'
    }
  }
}
