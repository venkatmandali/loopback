export default class CategoryController {
  /* @ngInject */
  constructor (Category, $uibModal) {
    Object.assign(this, { Category, $uibModal })
  }

  $onInit () {
    this.categoryOptions = {
      dirSelectable: false,
      isSelectable: this.isSelectable
    }
  }

  isSelectable (node) {
    return false
  }

  search (searchTerm) {
    if (searchTerm.length < 3) {
      return
    }

    let whereFilter = {
      name: { regexp: '/' + searchTerm + '/i' }
    }
    let filter = {
      where: whereFilter
    }
    // Return flatten data on the search - it will not keep the child/parent treeview format
    return this.Category.find({ filter: filter }, (result) => {
      this.categories = result
    }).$promise
  }

  getCategories () {
    if (this.searchTerm && this.searchTerm.length >= 3) {
      return this.search(this.searchTerm)
    }
    // Return relational data to display in a treeview format
    return this.Category.__get__all((result) => {
      this.categories = result
    }).$promise
  }

  delete (node) {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'category' },
        name: () => { return node.name },
        message: () => { return 'If the category is in use by any asset, those assets will lose this category.' }
      }
    }).result

    modal.then(() => {
      this.Category.destroyById({ id: node.id }, (result) => {
        // We're returning the Category.all() result in 'deleteById' to save
        // on extra HTTP requests
        this.categories = result.categories
      })
    })
  }
}
