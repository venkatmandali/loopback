import TagController from './tags.controller'

export default {
  selector: 'tagList',
  config: {
    controller: TagController,
    template: require('./tags.html'),
    bindings: {
      tags: '<'
    }
  }
}
