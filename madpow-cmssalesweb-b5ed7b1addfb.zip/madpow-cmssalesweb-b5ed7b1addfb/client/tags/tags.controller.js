export default class TagController {
  /* @ngInject */
  constructor (Tag, AppConfig, $scope, $uibModal, uiGridConstants) {
    Object.assign(this, { Tag, $scope, $uibModal, uiGridConstants })
    this.limit = AppConfig.limit
  }

  $onInit () {
    this.currentPage = 1
    this.isLoaded = true
    this.sort = 'createdDate DESC'
    this.gridSort = '-createdDate'

    let gridApi // Local handle for the api
    function caseInsensitiveSort (a, b, rowA, rowB, direction) {
      let nulls = gridApi.core.sortHandleNulls(a, b)
      if (nulls !== null) {
        return nulls
      }
      // Ignore 'direction' - the grid reverses the sort if needed
      if (a.toLowerCase() < b.toLowerCase()) return -1
      if (a.toLowerCase() > b.toLowerCase()) return 1
      return 0
    }

    this.gridOptions = {
      data: this.tags,
      showGridFooter: false,
      enableColumnMenus: false,
      onRegisterApi: (api) => {
        this.gridApi = gridApi = api
        api.pagination.on.paginationChanged(this.$scope, (newPage, pageSize) => {
          this.currentPage = newPage
        })
        api.core.on.sortChanged(this.$scope, (grid, sortColumns) => {
          this.sort = null
          if (sortColumns.length) {
            let field = sortColumns[0].field
            let direction = sortColumns[0].sort.direction.toUpperCase()
            this.sort = field + ' ' + direction
            this.gridSort = (direction === 'DESC' ? '-' : '+') + field
          }
        })
      },
      enablePaginationControls: false,
      paginationPageSizes: [10, 25],
      paginationPageSize: this.limit,
      totalItems: this.tags.length,
      rowHeight: 65,
      columnDefs: [
        {
          displayName: 'Date Added',
          cellFilter: 'date',
          name: 'createdDate',
          width: 150,
          sort: {
            direction: this.uiGridConstants.DESC
          }
        },
        {
          name: 'name',
          minWidth: 100,
          sortingAlgorithm: caseInsensitiveSort
        },
        {
          name: 'edit',
          displayName: null,
          cellTemplate: '<a class="table-link" ui-sref="tags.edit({ id: row.entity.id })" title="Edit Tag"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        },
        {
          name: 'delete',
          displayName: null,
          cellTemplate: '<a class="table-link" ng-click="grid.appScope.$ctrl.delete(row.entity)" title="Delete Tag"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        }
      ]
    }
  }

  changePage () {
    this.gridApi.pagination.seek(this.currentPage)
  }

  search (searchTerm) {
    if (searchTerm.length < 3) {
      return
    }

    let whereFilter = {
      name: { regexp: '/' + searchTerm + '/i' }
    }
    let filter = {
      where: whereFilter
    }
    this.currentPage = 1
    return this.Tag.find({ filter: filter }, (result) => {
      this.gridOptions.data = this.tags = result
      this.gridOptions.totalItems = this.tags.length
    }).$promise
  }

  getTags () {
    if (this.searchTerm && this.searchTerm.length >= 3) {
      return this.search(this.searchTerm)
    }
    return this.Tag.find((result) => {
      this.gridOptions.data = this.tags = result
      this.gridOptions.totalItems = this.tags.length
    }).$promise
  }

  delete (tag) {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'tag' },
        name: () => { return tag.name },
        message: () => { return 'If this tag is in use by any asset, those assets will lose this tag.' }
      }
    }).result

    modal.then(() => {
      this.Tag.destroyById({ id: tag.id }, (result) => {
        this.tags.splice(this.tags.indexOf(tag), 1)
        this.gridOptions.totalItems = this.tags.length
      })
    })
  }
}
