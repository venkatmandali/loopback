import angular from 'angular'
import uiRouting from '@uirouter/angularjs'

import TagComponent from './tags.component'
import EditTagComponent from './editTag.component'
import tagRouting from './tags.routing'

/* @ngInject */
export default angular.module('tags', [uiRouting])
  .config(tagRouting)
  .component(TagComponent.selector, TagComponent.config)
  .component(EditTagComponent.selector, EditTagComponent.config)
  .name
