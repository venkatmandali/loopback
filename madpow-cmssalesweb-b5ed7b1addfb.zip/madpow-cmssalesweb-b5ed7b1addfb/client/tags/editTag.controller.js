export default class EditTagController {
  constructor (Tag, $state, $uibModal) {
    Object.assign(this, { Tag, $state, $uibModal })
  }

  $onInit () {
    this.tagId = this.tag.id
  }

  save () {
    this.tag.$save((result) => {
      this.$state.go('tags.list', null, { reload: true })
    }, (error) => {
      this.errorMessage = ''
      let messages = error.data.error.details.messages
      for (let message in messages) {
        this.errorMessage += messages[message].join('<br />')
      }
    })
  }

  delete () {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'tag' },
        name: () => { return this.tag.name },
        message: () => { return 'If this tag is in use by any asset, those assets will lose this tag.' }
      }
    }).result

    modal.then(() => {
      this.tag.$delete((result) => {
        this.$state.go('tags.list', null, { reload: true })
      }, (error) => {
        this.errorMessage = error.data.error.message
      })
    })
  }
}
