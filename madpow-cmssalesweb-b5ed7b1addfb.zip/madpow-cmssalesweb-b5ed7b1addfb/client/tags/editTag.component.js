import EditTagController from './editTag.controller'

export default {
  selector: 'editTag',
  config: {
    controller: EditTagController,
    template: require('./editTag.html'),
    bindings: {
      tag: '<'
    }
  }
}
