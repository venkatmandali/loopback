/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'tags',
      abstract: true,
      url: '/tags',
      data: {
        title: 'Tags'
      }
    })
    .state({
      name: 'tags.list',
      url: '',
      component: 'tagList',
      resolve: {
        tags: function (Tag) {
          return Tag.find().$promise
        }
      }
    })
    .state({
      name: 'tags.edit',
      url: '/:id',
      component: 'editTag',
      resolve: {
        tag: function (Tag, $transition$) {
          return Tag.findById({ id: $transition$.params().id }).$promise
        }
      }
    })
    .state({
      name: 'tags.add',
      url: '/create',
      component: 'editTag',
      resolve: {
        tag: function (Tag) {
          return new Tag()
        }
      }
    })
}
