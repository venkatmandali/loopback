export default {
  lbBaseUrl: 'http://localhost:3000',
  limit: 25,
  noAuth: [
    'login',
    'unauthorized',
    'users.forgot',
    'users.reset',
    'users.verified',
    'install',
    'instructions',
    'sharedConversations'
  ],
  defaultTItle: 'ESPN Sales CMS Administrator',
  noAuthTitle: 'ESPN SalesCenter'
}
