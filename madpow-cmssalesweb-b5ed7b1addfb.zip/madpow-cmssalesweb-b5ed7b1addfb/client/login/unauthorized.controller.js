export default class UnauthorizedController {
  constructor (UserProfile, $state) {
    Object.assign(this, { UserProfile, $state })
  }

  logout () {
    this.UserProfile.logout(() => {
      this.$state.go('login')
    })
  }
}
