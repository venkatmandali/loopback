/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'login',
      url: '/login',
      views: {
        '@': {
          component: 'loginComponent'
        }
      },
      params: {
        message: ''
      }
    })
    .state({
      name: 'unauthorized',
      url: '/unauthorized',
      views: {
        '@': {
          component: 'unauthorized'
        }
      },
      data: {
        hideHeader: true
      }
    })
}
