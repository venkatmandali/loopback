import LoginController from './login.controller'

export default {
  selector: 'loginComponent',
  config: {
    controller: LoginController,
    template: require('./login.html'),
    binding: {
      'onLogin': '&'
    }
  }
}
