import angular from 'angular'
import uiRouter from '@uirouter/angularjs'

import loginRouting from './login.routing'
import LoginComponent from './login.component'
import UnauthorizedComponent from './unauthorized.component'

/* @ngInject */
export default angular.module('login', [uiRouter])
  .config(loginRouting)
  .component(LoginComponent.selector, LoginComponent.config)
  .component(UnauthorizedComponent.selector, UnauthorizedComponent.config)
  .name
