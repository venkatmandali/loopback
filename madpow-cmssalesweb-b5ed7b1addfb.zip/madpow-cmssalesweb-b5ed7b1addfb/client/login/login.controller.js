export default class LoginController {
  /* @ngInject */
  constructor ($state, UserProfile, LoopBackAuth) {
    Object.assign(this, { $state, UserProfile, LoopBackAuth })
    if (UserProfile.isAuthenticated()) {
      this.$state.go('dashboard')
    }
  }

  $onInit () {
    this.message = this.$state.params.message
  }

  login (username, password, rememberMe) {
    var next = this.$state.nextAfterLogin || '/'
    this.$state.nextAfterLogin = null
    this.errors = {}
    if (!rememberMe) {
      this.LoopBackAuth.clearStorage()
    }

    this.UserProfile.login({
      include: 'user',
      rememberMe: rememberMe
    },
      {
        email: username,
        password: password
      }).$promise.then((result) => {
        if (next && next.name) {
          this.$state.go(next)
        } else {
          this.$state.go('dashboard')
        }
      }).catch((err) => {
        this.errors[err.data.error.code] = true
      })
  }
}
