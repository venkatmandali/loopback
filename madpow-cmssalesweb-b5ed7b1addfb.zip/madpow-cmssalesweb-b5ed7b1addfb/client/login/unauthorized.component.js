import UnauthorizedController from './unauthorized.controller'

export default {
  selector: 'unauthorized',
  config: {
    controller: UnauthorizedController,
    template: require('./unauthorized.html')
  }
}
