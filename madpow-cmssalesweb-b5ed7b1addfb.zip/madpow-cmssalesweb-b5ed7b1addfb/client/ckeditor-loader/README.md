# CKEditor Webpack Loader

This is an example of integrating CKEditor 4 with webpack. However, it is not actually used in this project because it was taking too long to get working correctly, especially with Angular.

__DO NOT USE THIS MODULE__

This is here for reference/posterity only.

Based on [this](https://www.fomfus.com/articles/how-to-use-ckeditor-4-with-webpack) guide
