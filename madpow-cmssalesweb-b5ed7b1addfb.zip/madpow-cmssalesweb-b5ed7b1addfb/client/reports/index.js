import angular from 'angular'
import uiRouter from '@uirouter/angularjs'

import moment from 'angular-moment'

import ReportsComponent from './reports.component'
import ReportsRouting from './reports.routing'

export default angular.module('Reports', [uiRouter, 'chart.js', moment])
  .config(ReportsRouting)
  .config((ChartJsProvider) => {
    ChartJsProvider.setOptions({
      tooltips: {
        intersect: false,
        position: 'nearest'
      }
    })
  })
  .component(ReportsComponent.selector, ReportsComponent.config)
  .name
