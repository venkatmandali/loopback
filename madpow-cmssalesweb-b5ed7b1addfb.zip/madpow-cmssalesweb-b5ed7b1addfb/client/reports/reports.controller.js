export default class ReportsController {

  constructor($state, moment, _) {
    Object.assign(this, { $state, moment, _ })
  }

  $onInit() {
    let from = this.$state.params.from ? this.moment(this.$state.params.from) : null
    let to = this.$state.params.to ? this.moment(this.$state.params.to) : null
    if (from && from.isValid()) {
      this.from = from.toDate()
    }
    if (to && to.isValid()) {
      this.to = to.toDate()
    }

    this.labels = this.stats.map((stat) => {
      return this.moment(stat.timestamp).format('ll')
    })
    this.series = ["Total Conversations", "External Shared Conversations", "Internal Shared Conversations"]
    this.data = []
    this.data.push(this.stats.map((stat) => stat.totalConversations ))
    this.data.push(this.stats.map((stat) => stat.totalSharedConversations ))
    this.data.push(this.stats.map((stat) => stat.totalInternalSharedConversations ))

    this.dataOverride = [
      {
        label: 'Total Conversations',
        fill: false,
        pointRadius: 5,
        pointHitRadius: 10
      },
      {
        label: 'External Shared Conversations',
        fill: false,
        pointRadius: 5,
        pointHitRadius: 10
      },
      {
        label: 'Internal Shared Conversations',
        fill: false,
        pointRadius: 5,
        pointHitRadius: 10
      }
    ]

    this.options = {
      legend: {
        display: true
      },
      title: {
        display: true,
        text: "Conversations"
      }
    }
    this.colors = ['#803690', '#46BFBD', '#EC971F']
    // TODO: Take an average of assets/users counts over the duration of the report
    /**
     * Loop over all stats
     * Loop over shared assets array for each stat
     * Record the asset name
     * Look at the count
     *   Compare count to existing
     *
     */
    let sharedAssets = {}
    let favoritedAssets = {}
    let activeUsers = {}
    this.stats.forEach((stat, index) => {
      function processCollection(collection, key, id, count) {
        if (collection[key]) {
          collection[key].total = count
        } else {
          collection[key] = {
            total: count,
            prev: count,
            change: 0,
            changeUp: 0,
            changeDown: 0,
            avg: 0,
            counts: [],
            id: id,
            name: key
          }
        }
        let change = count - collection[key].prev
        if (change > 0) {
          collection[key].changeUp += change
        } else if (change < 0) {
          collection[key].changeDown += change
        }
        collection[key].change += count - collection[key].prev
        collection[key].prev = count
        collection[key].counts.push(count)
        collection[key].avg = Math.floor(collection[key].counts.reduce((a, b) => a + b) / collection[key].counts.length)
      }

      stat.topSharedAssets.forEach(asset => processCollection(sharedAssets, asset.name, asset.assetId, asset.count))
      stat.topFavoritedAssets.forEach(asset => processCollection(favoritedAssets, asset.name, asset.assetId, asset.count))
      stat.topActiveUsers.forEach(user => processCollection(activeUsers, user.email, user.userId, user.score))
    })
    this.sharedAssets = _.orderBy(sharedAssets, ['change', 'total'], ['desc', 'desc'])
    this.favoritedAssets = _.orderBy(favoritedAssets, ['change', 'total'], ['desc', 'desc'])
    this.activeUsers = _.orderBy(activeUsers, ['change', 'total'], ['desc', 'desc'])
  }

  getReport() {
    this.$state.go(this.$state.current, {
      from: this.moment(this.from).format('YYYY-MM-DD'),
      to: this.moment(this.to).format('YYYY-MM-DD')
    })
  }

  showAll() {
    this.from = this.to = this.$state.params.from = this.$state.params.to = null
    this.$state.reload()
  }

}
