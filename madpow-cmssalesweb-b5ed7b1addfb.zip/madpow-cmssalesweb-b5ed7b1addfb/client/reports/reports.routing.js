/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'reports',
      url: '/reports?from&to',
      component: 'reports',
      resolve: {
        stats: function(Statistics, $transition$) {
          let from = $transition$.params().from
          let to = $transition$.params().to
          if (from && to) {
            return Statistics.find({
              filter: {
                  where: {
                  timestamp: {
                    between: [
                      from, to
                    ]
                  }
                }
              }
            }).$promise
          }
          return Statistics.find().$promise
        }
      }
    })
}
