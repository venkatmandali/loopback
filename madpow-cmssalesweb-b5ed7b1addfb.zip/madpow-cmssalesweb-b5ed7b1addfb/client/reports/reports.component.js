import ReportsController from './reports.controller'

export default {
  selector: 'reports',
  config: {
    template: require('./reports.html'),
    controller: ReportsController,
    bindings: {
      stats: '<'
    }
  }
}
