export default {
  selector: 'dashboard',
  config: {
    template: require('./dashboard.html')
  }
}
