/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'dashboard',
      url: '/',
      component: 'dashboard'
    })
}
