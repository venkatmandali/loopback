import angular from 'angular'
import uiRouter from '@uirouter/angularjs'

import DashboardComponent from './dashboard.component'
import dashboardRouting from './dashboard.routing'

export default angular.module('Dashboard', [uiRouter])
  .config(dashboardRouting)
  .component(DashboardComponent.selector, DashboardComponent.config)
  .name
