import ForgotPasswordController from './forgotPassword.controller'

export default {
  selector: 'forgotPassword',
  config: {
    controller: ForgotPasswordController,
    template: require('./forgotPassword.html')
  }
}
