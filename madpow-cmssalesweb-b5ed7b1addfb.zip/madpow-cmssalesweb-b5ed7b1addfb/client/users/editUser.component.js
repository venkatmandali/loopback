import EditUserController from './editUser.controller'

export default {
  selector: 'editUser',
  config: {
    controller: EditUserController,
    template: require('./editUser.html'),
    bindings: {
      user: '<'
    }
  }
}
