export default class UserController {
  /* @ngInject */
  constructor (UserProfile, AppConfig, $scope, $uibModal, uiGridConstants) {
    Object.assign(this, { UserProfile, $scope, $uibModal, uiGridConstants })
    this.limit = AppConfig.limit
  }

  $onInit () {
    this.currentPage = 1
    this.isLoaded = true
    this.sort = 'createdDate DESC'
    this.gridSort = '-createdDate'

    let gridApi // Local handle for the api
    function caseInsensitiveSort (a, b, rowA, rowB, direction) {
      let nulls = gridApi.core.sortHandleNulls(a, b)
      if (nulls !== null) {
        return nulls
      }
      // Ignore 'direction' - the grid reverses the sort if needed
      if (a.toLowerCase() < b.toLowerCase()) return -1
      if (a.toLowerCase() > b.toLowerCase()) return 1
      return 0
    }

    this.gridOptions = {
      data: this.users,
      showGridFooter: false,
      enableColumnMenus: false,
      onRegisterApi: (api) => {
        this.gridApi = gridApi = api
        api.pagination.on.paginationChanged(this.$scope, (newPage, pageSize) => {
          this.currentPage = newPage
        })
        api.core.on.sortChanged(this.$scope, (grid, sortColumns) => {
          this.sort = null
          if (sortColumns.length) {
            let field = sortColumns[0].field
            let direction = sortColumns[0].sort.direction.toUpperCase()
            this.sort = field + ' ' + direction
            this.gridSort = (direction === 'DESC' ? '-' : '+') + field
          }
        })
      },
      enablePaginationControls: false,
      paginationPageSizes: [25],
      paginationPageSize: this.limit,
      totalItems: this.users.length,
      rowHeight: 65,
      columnDefs: [
        {
          displayName: 'Date Added',
          cellFilter: 'date',
          name: 'createdDate',
          width: 150,
          sort: {
            direction: this.uiGridConstants.DESC
          }
        },
        {
          displayName: 'First Name',
          name: 'firstName',
          minWidth: 150,
          sortingAlgorithm: caseInsensitiveSort
        },
        {
          displayName: 'Last Name',
          name: 'lastName',
          minWidth: 150,
          sortingAlgorithm: caseInsensitiveSort
        },
        { displayName: 'ESPN Email Address', name: 'email', minWidth: 200 },
        {
          name: 'edit',
          displayName: null,
          cellTemplate: '<a class="table-link" ui-sref="users.edit({ id: row.entity.id })" title="Edit User"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        },
        {
          name: 'delete',
          displayName: null,
          cellTemplate: '<a class="table-link" ng-click="grid.appScope.$ctrl.delete(row.entity)" title="Delete User"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        }
      ]
    }
  }

  changePage () {
    this.gridApi.pagination.seek(this.currentPage)
  }

  search (searchTerm) {
    if (searchTerm.length < 3) {
      return
    }

    let whereFilter = {
      or: [
        { firstName: { regexp: '/' + searchTerm + '/i' } },
        { lastName: { regexp: '/' + searchTerm + '/i' } },
        { email: { regexp: '/' + searchTerm + '/i' } }
      ]
    }
    let filter = {
      where: whereFilter
    }
    this.currentPage = 1
    return this.UserProfile.find({ filter: filter }, (result) => {
      this.gridOptions.data = this.users = result
      this.gridOptions.totalItems = this.users.length
    }).$promise
  }

  getUsers () {
    if (this.searchTerm && this.searchTerm.length >= 3) {
      return this.search(this.searchTerm)
    }
    return this.UserProfile.find((result) => {
      this.gridOptions.data = this.users = result
      this.gridOptions.totalItems = this.users.length
    }).$promise
  }

  delete (user) {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'profile' },
        name: () => { return user.email }
      }
    }).result

    modal.then(() => {
      this.UserProfile.destroyById({ id: user.id }, (result) => {
        this.users.splice(this.users.indexOf(user), 1)
        this.gridOptions.totalItems = this.users.length
      })
    })
  }
}
