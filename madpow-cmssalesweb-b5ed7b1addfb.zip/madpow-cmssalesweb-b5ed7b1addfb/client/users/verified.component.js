import VerifiedController from './verified.controller'

export default {
  selector: 'verified',
  config: {
    controller: VerifiedController,
    template: require('./verified.html')
  }
}
