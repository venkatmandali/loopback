/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'users',
      abstract: true,
      url: '/profiles',
      resolve: {
        currentUser: function (UserProfile) {
          if (UserProfile.isAuthenticated()) {
            return UserProfile.getCurrent()
          }
        }
      },
      data: {
        title: 'Profiles',
        test: '123'
      }
    })
    .state({
      name: 'users.list',
      url: '',
      component: 'userList',
      resolve: {
        users: function (UserProfile) {
          return UserProfile.find().$promise
        }
      }
    })
    .state({
      name: 'users.edit',
      url: '/:id',
      component: 'editUser',
      resolve: {
        user: function (UserProfile, $transition$) {
          return UserProfile.findById({
            id: $transition$.params().id,
            filter: {
              include: 'roles'
            }
          }).$promise
        }
      }
    })
    .state({
      name: 'users.add',
      url: '/create',
      component: 'editUser',
      resolve: {
        user: function (UserProfile) {
          return new UserProfile()
        }
      }
    })
    .state({
      name: 'users.verified',
      url: '/verified?access_token',
      views: {
        '@': {
          component: 'verified'
        }
      },
      data: {
        hideHeader: true
      }
    })
    .state({
      name: 'users.forgot',
      url: '/forgot',
      views: {
        '@': {
          component: 'forgotPassword'
        }
      },
      data: {
        test: 'abc',
        hideHeader: true
      }
    })
    .state({
      name: 'users.reset',
      url: '/reset?access_token&firstTime',
      views: {
        '@': {
          component: 'resetPassword'
        }
      },
      data: {
        hideHeader: true
      }
    })
    .state({
      name: 'install',
      url: '/install',
      views: {
        '@': {
          template: require('./install.html')
        }
      },
      data: {
        hideHeader: true
      }
    })
    .state({
      name: 'instructions',
      url: '/instructions',
      views: {
        '@': {
          template: require('./trustingEnterpriseDeveloper.html')
        }
      },
      data: {
        hideHeader: true
      }
    })
}
