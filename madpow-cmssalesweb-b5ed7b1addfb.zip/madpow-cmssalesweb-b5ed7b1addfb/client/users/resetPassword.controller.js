export default class ResetPasswordController {
  constructor (UserProfile, $state, AppConfig, ErrorService) {
    Object.assign(this, { UserProfile, $state, ErrorService })
  }

  $onInit () {
    this.password = ''
    this.confirmPassword = ''
    this.passwordCheck = /^(?=.*[a-zA-Z])(?=.*\d)[A-Za-z0-9-+_!@#$%^&*.,?]{8,50}$/
    this.submitted = false
    this.firstTime = this.showConfirmation = this.$state.params.firstTime
    this.header = this.firstTime ? 'Set Password' : 'Reset Password'
  }

  submit () {
    let accessToken = this.$state.params.access_token
    this.errors = {}
    this.showConfirmation = false
    this.UserProfile.replacePassword({
      credentials: {
        password: this.password,
        confirmPassword: this.confirmPassword,
        accessToken: accessToken
      }
    }).$promise.then((response) => {
      this.header = 'Success!'
      this.submitted = true
      // this.$state.go('login', { message: 'Your password has been successfully reset. Please login below using your new password.' })
    }).catch((error) => {
      this.errors = this.ErrorService.process(error)
      this.header = this.firstTime ? 'Set Password' : 'Reset Password'
      this.submitted = false
    })
  }
}
