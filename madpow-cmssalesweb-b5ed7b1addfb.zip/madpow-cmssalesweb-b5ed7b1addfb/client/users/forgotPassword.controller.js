export default class ForgotPasswordController {
  constructor (UserProfile, ErrorService) {
    Object.assign(this, { UserProfile, ErrorService })
  }

  $onInit () {
    this.email = ''
    this.emailCheck = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    this.header = 'Forgot Password'
    this.submitted = false
  }

  resetPassword () {
    this.errors = {}
    if (!this.email) {
      this.errors.email = true
    } else {
      if (this.email.match(this.emailCheck)) {
        this.errors.email = true
      }
      this.submitted = true
      this.UserProfile.resetPassword({ email: this.email }, (result) => {
        this.header = 'Thank You!'
      }, (err) => {
        console.log(err)
        let errors = this.ErrorService.process(err)
        console.log(errors)
        this.errors = errors
        this.header = 'Forgot Password'
        this.submitted = false
      })
    }
  }
}
