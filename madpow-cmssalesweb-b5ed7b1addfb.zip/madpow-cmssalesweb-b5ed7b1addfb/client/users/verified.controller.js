export default class VerifiedController {
  constructor ($state) {
    Object.assign(this, { $state })
  }

  $onInit () {
    console.log(this.$state)
    this.token = this.$state.params.access_token
  }
}
