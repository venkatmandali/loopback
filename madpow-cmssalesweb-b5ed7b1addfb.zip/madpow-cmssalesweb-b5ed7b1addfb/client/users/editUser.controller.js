export default class EditUserController {
  constructor (UserProfile, $state, $uibModal, ErrorService) {
    Object.assign(this, { UserProfile, $state, $uibModal, ErrorService })
  }

  $onInit () {
    this.userId = this.user.id
    this.isAdmin = this.originalAdmin = this.user.roles ? this.user.roles.some(function (role) {
      return role.name === 'administrator'
    }) : false
  }

  randomPassword (length) {
    var chars = 'abcdefghijklmnopqrstuvwxyz!@#$%^&*()-+<>ABCDEFGHIJKLMNOP1234567890'
    var pass = ''
    for (var x = 0; x < length; x++) {
      var i = Math.floor(Math.random() * chars.length)
      pass += chars.charAt(i)
    }
    return pass
  }

  save () {
    this.errorMessage = ''
    this.serverValidation = null
    // Because the default save requires a password, but we don't want to store that
    // on the client, we use updateAttributes (which maps to patchAttributes)
    // but we need to only submit a subset of data, or else the db will get incorrect
    // values such as 'id', 'createdDate', 'roles', etc.
    let data = {
      firstName: this.user.firstName,
      lastName: this.user.lastName,
      email: this.user.email
    }
    let successHandler = (result) => {
      this.user.id = result.id
      if (this.isAdmin !== this.originalAdmin) {
        if (this.isAdmin === false) {
          this.user.$prototype$removeFromRole({
            roleName: 'administrator'
          }, () => {
            this.$state.go('users.list', null, { reload: true })
          })
        }
        if (this.isAdmin === true) {
          this.user.$prototype$addToRole({
            roleName: 'administrator'
          }, () => {
            this.$state.go('users.list', null, { reload: true })
          })
        }
      } else {
        this.$state.go('users.list', null, { reload: true })
      }
    }
    let errorHandler = (err) => {
      let error = this.ErrorService.process(err)
      this.serverValidation = error
    }
    if (!this.user.id) {
      // Passwords cannot be null, set to a random one and then send out the reset email
      data.password = this.randomPassword(16)
      this.UserProfile.create(data, successHandler, errorHandler)
      // this.user.$save(successHandler, errorHandler)
    } else {
      this.UserProfile['prototype$updateAttributes']({ id: this.user.id }, data).$promise.then(successHandler, errorHandler)
    }
  }

  resetPassword () {
    this.UserProfile.resetPassword({
      email: this.user.email
    }, (result) => {
      this.message = 'Reset Password email sent'
    }, (error) => {
      console.log(error)
      this.message = error.data.error.message
    })
  }

  delete () {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'profile' },
        name: () => { return this.user.email }
      }
    }).result

    modal.then(() => {
      this.user.$delete((result) => {
        this.$state.go('users.list', null, { reload: true })
      }, (error) => {
        this.errorMessage = error.data.error.message
      })
    })
  }
}
