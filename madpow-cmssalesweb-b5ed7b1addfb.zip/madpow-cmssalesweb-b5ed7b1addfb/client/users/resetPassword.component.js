import ResetPasswordController from './resetPassword.controller'

export default {
  selector: 'resetPassword',
  config: {
    controller: ResetPasswordController,
    template: require('./resetPassword.html')
  }
}
