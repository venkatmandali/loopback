import angular from 'angular'
import uiRouting from '@uirouter/angularjs'

import UserComponent from './users.component'
import EditUserComponent from './editUser.component'
import ForgotPasswordComponent from './forgotPassword.component'
import ResetPasswordComponent from './resetPassword.component'
import VerifiedComponent from './verified.component'

import userRouting from './users.routing'

/* @ngInject */
export default angular.module('users', [uiRouting])
  .config(userRouting)
  .component(UserComponent.selector, UserComponent.config)
  .component(EditUserComponent.selector, EditUserComponent.config)
  .component(ForgotPasswordComponent.selector, ForgotPasswordComponent.config)
  .component(ResetPasswordComponent.selector, ResetPasswordComponent.config)
  .component(VerifiedComponent.selector, VerifiedComponent.config)
  .name
