import UserController from './users.controller'

export default {
  selector: 'userList',
  config: {
    controller: UserController,
    template: require('./users.html'),
    bindings: {
      users: '<'
    }
  }
}
