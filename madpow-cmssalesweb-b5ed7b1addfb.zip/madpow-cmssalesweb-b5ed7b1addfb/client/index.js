/* global document */
import angular from 'angular'

import appModule from './app.module'

angular.element(document).ready(() => {
  let body = document.getElementsByTagName('body')
  angular.bootstrap(body, [appModule])
})
