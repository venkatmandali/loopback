import angular from 'angular'
import uiRouting from '@uirouter/angularjs'

import NewsfeedComponent from './newsfeed.component'
import newsfeedRouting from './newsfeed.routing'

/* @ngInject */
export default angular.module('newsfeed', [uiRouting])
  .config(newsfeedRouting)
  .component(NewsfeedComponent.selector, NewsfeedComponent.config)
  .name
