export default class NewsfeedController {
  constructor (SalesPriority, $uibModal, uiGridConstants, $scope) {
    Object.assign(this, { SalesPriority, $uibModal, uiGridConstants, $scope })
  }

  $onInit () {
    this.gridOptions = {
      data: this.salesPriorities,
      showGridFooter: false,
      enableColumnMenus: false,
      onRegisterApi: (api) => {
        this.grid = api
        api.draggableRows.on.rowDropped(this.$scope, (info, dropTarget) => {
          api.dragndrop.setDragDisabled(true)
          this.salesPriorities.forEach((sp, index, coll) => {
            sp.sortOrder = index
            // Loopback 3.0 dropped support for bulk upsert, so we need to call
            // $save() on each model. This is highly inefficient, but the newsfeed
            // isn't meant to have thousands of entries, and this code is only used
            // by admins, so it's a reasonable comprimise for now
            // We're using the class method because we don't want to change the
            // underlying grid data
            this.SalesPriority.update({
              where: { id: sp.id }
            }, sp, (result) => {
              // Re-enable drag/drop after the last update is complete
              if (index === coll.length - 1) {
                api.dragndrop.setDragDisabled(false)
              }
            }, (err) => {
              // TODO: Show error and reset index
              console.log(err)
              api.dragndrop.setDragDisabled(false)
            })
          })
        })
      },
      enablePaginationControls: false,
      rowHeight: 65,
      enableSorting: false,
      rowTemplate: '<div grid="grid" class="ui-grid-draggable-row" draggable="true"><div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader, \'custom\': true }" ui-grid-cell></div></div>',
      columnDefs: [
        {
          displayName: 'Date Added',
          cellFilter: 'date',
          name: 'createdDate',
          width: 150
        },
        {
          name: 'asset.name',
          displayName: 'Name',
          cellClass: 'text-bold'
        },
        {
          name: 'edit',
          displayName: null,
          cellTemplate: '<a class="table-link" ui-sref="assets.edit({ id: row.entity.assetId })" title="Edit Asset"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        },
        {
          name: 'delete',
          displayName: null,
          cellTemplate: '<a class="table-link" ng-click="grid.appScope.$ctrl.delete(row.entity)" title="Delete"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        }
      ]
    }
  }

  delete (salesPriority) {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: function () { return 'Sales Priority' },
        name: function () { return salesPriority.asset.name }
      }
    }).result

    modal.then(() => {
      this.SalesPriority.destroyById({ id: salesPriority.id }, (result) => {
        this.salesPriorities.splice(this.salesPriorities.indexOf(salesPriority), 1)
      })
    })
  }
}
