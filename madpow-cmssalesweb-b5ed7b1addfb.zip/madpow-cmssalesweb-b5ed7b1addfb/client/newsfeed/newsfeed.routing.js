/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'newsfeed',
      abstract: true,
      url: '/salesPriorities',
      data: {
        title: 'Sales Priorities'
      }
    })
    .state({
      name: 'newsfeed.list',
      url: '',
      component: 'newsfeed',
      resolve: {
        salesPriorities: function (SalesPriority, $transition$) {
          return SalesPriority.find({
            order: 'sortOrder'
          }).$promise
        }
      }
    })
}
