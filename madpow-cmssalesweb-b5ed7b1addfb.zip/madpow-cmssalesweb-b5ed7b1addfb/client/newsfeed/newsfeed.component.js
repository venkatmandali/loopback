import NewsfeedController from './newsfeed.controller'

export default {
  selector: 'newsfeed',
  config: {
    controller: NewsfeedController,
    template: require('./newsfeed.html'),
    bindings: {
      salesPriorities: '<'
    }
  }
}
