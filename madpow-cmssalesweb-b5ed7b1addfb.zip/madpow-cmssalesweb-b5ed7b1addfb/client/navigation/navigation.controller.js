export default class NavigationController {
  constructor ($state, $transitions, UserProfile) {
    Object.assign(this, { $state, UserProfile, $transitions })
  }

  get isAuthenticated () {
    return this.UserProfile.isAuthenticated()
  }

  $onInit () {
    this.isNavCollapsed = true
    this.$transitions.onEnter({ entering: '*' }, (transition, state) => {
      this.isPublicView = false
      this.hideHeader = false
      let currentState = transition.to()
      if (currentState.data) {
        if (currentState.data.isPublicView !== undefined) {
          this.isPublicView = currentState.data.isPublicView
        }
        if (currentState.data.hideHeader !== undefined) {
          this.hideHeader = currentState.data.hideHeader
        }
      }
    })
  }

  logout () {
    this.UserProfile.logout(() => {
      this.$state.go('login')
    })
  }
}
