import NavigationController from './navigation.controller'

export default {
  selector: 'navigation',
  config: {
    template: require('./navigation.html'),
    controller: NavigationController,
    headline: '<'
  }
}
