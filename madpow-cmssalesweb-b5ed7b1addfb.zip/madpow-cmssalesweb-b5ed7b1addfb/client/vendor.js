import angular from 'angular'
import ngAnimate from 'angular-animate'
import ngResource from 'angular-resource'
import ngTouch from 'angular-touch'
import ngSanitize from 'angular-sanitize'
import ngMessages from 'angular-messages'

import Analytics from 'angular-google-analytics'

import uiRouter from '@uirouter/angularjs'
import uiGrid from 'angular-ui-grid'
import uiGridDraggableRows from 'ui-grid-draggable-rows'
import uiBootstrap from 'angular-ui-bootstrap'

import treeControl from 'angular-tree-control'
import contextMenu from 'angular-tree-control/context-menu'
import ngTagsInput from 'ng-tags-input'

import Masonry from 'masonry-layout/dist/masonry.pkgd'
import imagesLoaded from 'imagesloaded'

import ChartJs from 'angular-chart.js'

import AngularCK from 'angular-ckeditor/angular-ckeditor'

import moment from 'angular-moment'
import lodash from 'lodash'
import ngFileUpload from 'ng-file-upload'

import videogular from 'videogular/dist/videogular/videogular.js'
import videogularControls from 'videogular/dist/controls/vg-controls.js'
import videogularOverlayPlay from 'videogular/dist/overlay-play/vg-overlay-play.js'
import videogularPoster from 'videogular/dist/poster/vg-poster.js'

import 'angular-ui-grid/ui-grid.css'
import 'angular-tree-control/css/tree-control.css'
import 'ng-tags-input/build/ng-tags-input.css'
import 'ng-tags-input/build/ng-tags-input.bootstrap.css'
import 'ui-grid-draggable-rows/less/draggable-rows.less'
import 'videogular/dist/themes/default/videogular.scss'
