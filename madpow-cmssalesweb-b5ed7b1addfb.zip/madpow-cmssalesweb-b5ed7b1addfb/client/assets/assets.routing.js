/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'assets',
      abstract: true,
      url: '/assets',
      data: {
        title: 'Assets'
      }
    })
    .state({
      name: 'assets.list',
      url: '',
      component: 'assetList',
      resolve: {
        assets: function (Asset) {
          return Asset.find({
            filter: {
              where: {
                deleted: false
              }
            }
          }).$promise
        }
      }
    })
    .state({
      name: 'assets.edit',
      url: '/:id',
      component: 'editAsset',
      resolve: {
        asset: function (Asset, $transition$) {
          return Asset.findById({
            id: $transition$.params().id,
            filter: {
              include: ['categories', 'tags']
            }
          }).$promise
        },
        salesPriority: function (SalesPriority, $transition$) {
          return SalesPriority.find({ filter: {
            where: {
              assetId: $transition$.params().id
            }
          }}).$promise
        },
        categories: function (Category) {
          return Category.__get__all().$promise
        },
        currentUser: function (UserProfile) {
          return UserProfile.getCurrent()
        }
      }
    })
    .state({
      name: 'assets.add',
      url: '/create',
      component: 'editAsset',
      resolve: {
        asset: function (Asset, $transition$) {
          let asset = new Asset()
          asset.isInternalOnly = false
          asset.type = 'fileUpload'
          return asset
        },
        salesPriority: function (SalesPriority, $transition$) {
          return new SalesPriority()
        },
        categories: function (Category) {
          return Category.__get__all().$promise
        },
        currentUser: function (UserProfile) {
          return UserProfile.getCurrent()
        }
      }
    })
}
