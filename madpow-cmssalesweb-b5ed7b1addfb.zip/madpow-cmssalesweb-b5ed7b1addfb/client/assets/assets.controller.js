import Masonry from 'masonry-layout'
import imagesLoaded from 'imagesloaded'

export default class AssetController {
  /* @ngInject */
  constructor (Asset, $uibModal, $timeout, $scope, AppConfig, uiGridConstants) {
    Object.assign(this, { Asset, $uibModal, $timeout, $scope, uiGridConstants })
    this.limit = AppConfig.limit
  }

  switchView (mode) {
    this.viewMode = mode
    if (mode === 'grid') {
      this.refreshGrid()
    }
  }

  $onInit () {
    this.viewMode = 'list'
    this.currentPage = 1
    this.isLoaded = true
    this.sort = 'createdDate DESC'
    this.gridSort = '-createdDate'

    let gridApi // Local handle for the api
    function caseInsensitiveSort (a, b, rowA, rowB, direction) {
      let nulls = gridApi.core.sortHandleNulls(a, b)
      if (nulls !== null) {
        return nulls
      }
      // Ignore 'direction' - the grid reverses the sort if needed
      if (a.toLowerCase() < b.toLowerCase()) return -1
      if (a.toLowerCase() > b.toLowerCase()) return 1
      return 0
    }

    this.gridOptions = {
      data: this.assets,
      showGridFooter: false,
      enableColumnMenus: false,
      onRegisterApi: (api) => {
        this.gridApi = gridApi = api
        api.pagination.on.paginationChanged(this.$scope, (newPage, pageSize) => {
          this.currentPage = newPage
        })
        api.core.on.sortChanged(this.$scope, (grid, sortColumns) => {
          this.sort = null
          if (sortColumns.length) {
            let field = sortColumns[0].field
            let direction = sortColumns[0].sort.direction.toUpperCase()
            this.sort = field + ' ' + direction
            this.gridSort = (direction === 'DESC' ? '-' : '+') + field
          }
        })
      },
      enablePaginationControls: false,
      paginationPageSizes: [25],
      paginationPageSize: this.limit,
      totalItems: this.assets.length,
      rowHeight: 65,
      columnDefs: [
        {
          displayName: 'Date Added',
          cellFilter: 'date',
          name: 'createdDate',
          width: 150,
          sort: {
            direction: this.uiGridConstants.DESC
          }
        },
        {
          name: 'name',
          cellClass: 'cell-text-bold',
          minWidth: 150,
          sortingAlgorithm: caseInsensitiveSort
        },
        {
          name: 'summary',
          displayName: 'Description',
          minWidth: 150,
          sortingAlgorithm: caseInsensitiveSort
        },
        {
          name: 'isInternalOnly',
          displayName: 'Internal',
          cellFilter: 'bool',
          width: 150
        },
        {
          name: 'edit',
          displayName: null,
          cellTemplate: '<a class="table-link" ui-sref="assets.edit({ id: row.entity.id })" title="Edit Asset"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        },
        {
          name: 'delete',
          displayName: null,
          cellTemplate: '<a class="table-link" ng-click="grid.appScope.$ctrl.delete(row.entity)" title="Delete Asset"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>',
          enableSorting: false,
          enableColumnMenu: false,
          width: 40
        }
      ]
    }
  }

  refreshGrid () {
    if (!this.grid) {
      this.$timeout(() => {
        imagesLoaded('[masonry]', () => {
          this.grid = new Masonry('[masonry]', {
            itemSelector: '.mason-grid-item',
            columnWidth: '.mason-grid-sizer',
            percentPosition: true,
            layoutInstant: true
          })
        })
      })
    } else {
      this.$timeout(() => {
        imagesLoaded('[masonry]', () => {
          this.grid.reloadItems()
          this.grid.layout()
        })
      })
    }
  }

  changePage () {
    this.gridApi.pagination.seek(this.currentPage)
    if (this.viewMode === 'grid') {
      this.refreshGrid()
    }
  }

  search (searchTerm) {
    if (searchTerm === '') {
      return this.getAssets()
    }
    if (searchTerm.length < 3) {
      return
    }

    this.currentPage = 1
    return this.Asset.search({ query: searchTerm }, (result) => {
      this.gridOptions.data = this.assets = result
      this.gridOptions.totalItems = this.assets.length
      this.changePage()
    }).$promise
  }

  getAssets () {
    if (this.searchTerm && this.searchTerm.length >= 3) {
      return this.search(this.searchTerm)
    }
    let filter = {
      where: { deleted: false }
    }
    return this.Asset.find({ filter: filter }, (result) => {
      this.gridOptions.data = this.assets = result
      this.gridOptions.totalItems = this.assets.length
      if (this.viewMode === 'grid') {
        this.refreshGrid()
      }
    }).$promise
  }

  delete (asset) {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'asset' },
        name: () => { return asset.name }
      }
    }).result

    modal.then(() => {
      this.Asset.destroyById({ id: asset.id }, (result) => {
        this.assets.splice(this.assets.indexOf(asset), 1)
        this.gridOptions.totalItems = this.assets.length
        if (this.viewMode === 'grid') {
          this.refreshGrid()
        }
      })
    })
  }
}
