// import TmplThreeHeadlines from '../asset/editor-templates/three-headlines.html'
// import TmplWeeklyLineUp from '../asset/editor-templates/weekly-lineup.html'
// import TmplSFB from '../asset/editor-templates/sfb.html'

export default class EditAssetController {
  constructor (Asset, SalesPriority, Tag, Upload, $templateRequest, $state, $q, $window, $uibModal, LoopBackResource, AppConfig, ErrorService) {
    Object.assign(this, { Asset, SalesPriority, Tag, Upload, $templateRequest, $state, $q, $window, $uibModal, ErrorService })
    this.urlBase = LoopBackResource.getUrlBase()
  }

  $onInit () {
    this.assetId = this.asset.id
    this.isNew = Object.is(this.asset.id, undefined)
    this.isSaving = false
    this.isHtml = this.asset.type === 'text/html'
    if (this.asset.originalContent) {
      this.asset.editorContent = this.asset.originalContent
    }
    if (this.salesPriority.length) {
      // Workaround for the broken 'findOne' method
      this.salesPriority = this.salesPriority[0]
    }
    this.isNewsfeed = !!this.salesPriority.id

    let expandedCategories = this.expandedCategories = []
    let categories = this.categories

    function setupCategories (asset) {
      // Loop over the category tree, looking for any parents with children
      function checkCategories (categories, parent) {
        categories.forEach(function (category) {
          let hasChildren = category.children && category.children.length > 0
          if (hasChildren) {
            expandedCategories.push(category)
            return checkCategories(category.children)
          }
        })
      }
      checkCategories(categories)
    }

    this.categoryOptions = {
      multiSelection: true,
      equality: function (a, b) {
        if (!a || !b) return false
        return a.id === b.id
      }
    }

    this.editorOptions = {
      fullPage: true,
      extraPlugins: 'docprops',
      allowedContent: true,
      filebrowserImageUploadUrl: this.urlBase + '/Assets/uploadHTMLAsset',
      toolbar: [[
        'Format',
        'Bold',
        'Italic',
        'TextColor',
        'Link',
        'Unlink',
        'BulletedList',
        'NumberedList',
        'Blockquote',
        'Image',
        'Undo',
        'Redo',
        'Source',
        'DocProps'
      ]]
    }

    this.templateOptions = [
      {
        id: '1',
        title: 'Three Headlines',
        url: './asset/editor-templates/three-headlines.html'
      },
      {
        id: '2',
        title: 'Weekly Lineup',
        url: './asset/editor-templates/weekly-lineup.html'
      },
      {
        id: '3',
        title: 'SFB',
        url: './asset/editor-templates/sfb.html'
      }
    ]

    setupCategories()
  }

  getTags (query) {
    return this.Tag.find({
      filter: {
        where: {
          name: {
            regexp: '/' + query + '/i'
          }
        }
      }
    }).$promise
  }

  uploadFile () {
    if (!this.assetFile) {
      if (!this.asset.url) {
        return this.$q.reject('Please select a file to upload.')
      } else {
        return this.$q.resolve()
      }
    }
    // Use ngFileUpload instead of the resource
    return this.Upload.upload({
      url: this.urlBase + '/Assets/upload',
      data: {
        file: this.assetFile,
        assetId: this.asset.id
      }
    }).then((response) => {
      console.log(response)
      this.asset.url = response.data.url
      this.asset.originalFilename = response.data.originalFilename
      this.asset.thumbnailUrl = response.data.thumbnailUrl
      this.asset.type = response.data.type
      this.asset.size = response.data.size
      this.assetFile.progress = null
    }, (error) => {
      console.log(error)
      // Throw the error to be caught later
      throw error
    }, (notification) => {
      console.log(notification)
      this.assetFile.progress = Math.min(100, parseInt(100.0 * notification.loaded / notification.total))
    })
  }

  confirmTemplateValueChange(oldValue) {
    if (!this.$window.CKEDITOR.instances.wysiwyg.checkDirty()) {
      this.loadTemplate()
      return
    }

    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'update' },
        type: () => { return 'asset\'s content' },
        message: () => { return 'Switching templates will clear all of the contents from the Content Editor.' }
      }
    }).result

    modal.then(() => {
      this.loadTemplate()
    }, () =>  {
      oldValue = oldValue.replace('"{', '{').replace('}"', '}')
      this.template = JSON.parse(oldValue)
    })
  }

  loadTemplate() {
    this.errorMessage = ''
    if (!this.template) {
      this.assetId.editorContent = ''
    } else {
      const url = this.template.url

      this.$templateRequest(url)
        .then((response) => {
          this.asset.editorContent = response;
        })
        .catch(function () {
          this.errorMessage = `Error loading template at ${url}`
        })
    }
  }

  save () {
    if (this.asset.categories) this.asset.categoryIds = this.asset.categories.map((category) => category.id)
    if (this.asset.tags) this.asset.tagIds = this.asset.tags.map((tag) => tag.id)

    this.isSaving = true

    if (!this.isHtml) {
      this.uploadFile().then(() => {
        this.saveAsset()
      }).catch((error) => {
        console.log(error)
        let err = this.ErrorService.process(error)
        this.errorMessage = err.message.join('<br />')
        this.isSaving = false
      })
    } else {
      this.asset.type = 'text/html'

      // Check if we're in source view
      if (this.$window.CKEDITOR.instances.wysiwyg.mode === 'source') {
        // Grab the data directly - switching back to normal mode and waiting for the digest to run is too unreliable
        this.asset.editorContent = this.$window.CKEDITOR.instances.wysiwyg.getData()
      }
      this.saveAsset()
    }
  }

  saveAsset() {
    this.asset.$save((result) => {
      if (this.salesPriority.id && !this.isNewsfeed) {
        this.salesPriority.$delete()
      } else if (this.isNewsfeed && !this.salesPriority.id) {
        this.SalesPriority.create({
          assetId: result.id,
          userId: this.currentUser.id,
          sortOrder: 0
        })
      }
      this.$state.go('assets.list', null, { reload: true })
    }, (error) => {
      throw error
    })
  }

  delete () {
    let modal = this.$uibModal.open({
      component: 'confirmActionModal',
      resolve: {
        action: () => { return 'delete' },
        type: () => { return 'asset' },
        name: () => { return this.asset.name }
      }
    }).result

    modal.then(() => {
      this.Asset.destroyById({ id: this.asset.id }, (result) => {
        this.$state.go('assets.list', null, { reload: true })
      })
    })
  }
}
