import AssetController from './assets.controller'

export default {
  selector: 'assetList',
  config: {
    controller: AssetController,
    template: require('./assets.html'),
    bindings: {
      assets: '<'
    }
  }
}
