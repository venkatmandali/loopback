import EditAssetController from './editAsset.controller'

export default {
  selector: 'editAsset',
  config: {
    controller: EditAssetController,
    template: require('./editAsset.html'),
    bindings: {
      categories: '<',
      asset: '<',
      salesPriority: '<',
      currentUser: '<'
    }
  }
}
