import angular from 'angular'
import uiRouting from '@uirouter/angularjs'

import AngularCK from 'angular-ckeditor/angular-ckeditor'

import AssetComponent from './assets.component'
import EditAssetComponent from './editAsset.component'
import assetRouting from './assets.routing'

/* @ngInject */
export default angular.module('assets', [uiRouting, 'ckeditor'])
  .config(assetRouting)
  .component(AssetComponent.selector, AssetComponent.config)
  .component(EditAssetComponent.selector, EditAssetComponent.config)
  .name
