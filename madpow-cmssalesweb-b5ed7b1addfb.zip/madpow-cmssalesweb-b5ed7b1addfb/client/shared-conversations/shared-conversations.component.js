import SharedConversationController from './shared-conversations.controller'

export default {
  selector: 'sharedConversation',
  config: {
    controller: SharedConversationController,
    template: require('./shared-conversations.html'),
    bindings: {
      conversation: '<'
    }
  }
}
