import Masonry from 'masonry-layout'
import imagesLoaded from 'imagesloaded'

export default class SharedConversationController {
  constructor (SharedConversation, $state, ModalService, $timeout, $window, Analytics) {
    Object.assign(this, { SharedConversation, $state, ModalService, $timeout, $window, Analytics })
  }

  $onInit() {
    // this.Analytics.set('sendHitTask', null)
    this.Analytics.trackPage(this.Analytics.getUrl(), this.conversation.subject)

    this.$timeout(() => {
      imagesLoaded('[masonry]', () => {
        this.grid = new Masonry('[masonry]', {
          itemSelector: '.mason-grid-item',
          columnWidth: '.mason-grid-sizer',
          percentPosition: true
        })
      })
    }, 0)
    if (this.$state.params.assetId) {
      const asset = this.conversation.assets.find((asset) => (asset.id === this.$state.params.assetId))
      if (asset) {
        this.view(asset)
      }
    }
  }

  view(asset) {
    this.Analytics.trackEvent('Asset', 'click', asset.name, null, null, {
      dimension1: asset.type
    })
    if (asset.type.indexOf('pdf') > -1 || asset.type.indexOf('html') > -1) {
      this.$window.open(asset.url)
    } else {
      const setState = () => {
        return this.$state.go('.', {
          id: this.$state.params.id,
          assetId: asset.id
        }, {
          inherit: false,
          notify: false,
          reload: false,
          location: 'replace'
        })
      }
      const resetState = (reason) => {
        return this.$state.go('.', {
          id: this.$state.params.id,
          assetId: undefined
        }, {
          inherit: false,
          notify: false,
          reload: false,
          location: 'replace'
        })
      }
      const modal = this.ModalService.show({
        component: 'viewModal',
        resolve: {
          asset: function () { return asset }
        },
        size: 'lg'
      })
      if (modal) {
        modal.opened.then(() => {
          setState()
        })
        modal.result.then(resetState, resetState)
      }
    }
  }
}
