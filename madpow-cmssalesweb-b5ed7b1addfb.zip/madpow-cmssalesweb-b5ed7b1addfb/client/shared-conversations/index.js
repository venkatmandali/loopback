import angular from 'angular'
import uiRouter from '@uirouter/angularjs'
import Analytics from 'angular-google-analytics'

import SharedConversationComponent from './shared-conversations.component'
import routing from './shared-conversations.routing'

export default angular.module('SharedConversation', [
  uiRouter,
  Analytics
])
  .config(routing)
  .config((AnalyticsProvider) => {
    AnalyticsProvider.setAccount({
      tracker: 'UA-105880949-1', trackEvent: true
    }).trackPages(false)
  })
  .component(SharedConversationComponent.selector, SharedConversationComponent.config)
  .name
