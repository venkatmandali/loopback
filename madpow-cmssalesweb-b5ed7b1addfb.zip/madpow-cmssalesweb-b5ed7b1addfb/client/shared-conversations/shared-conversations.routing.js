/* @ngInject */
export default function routing ($stateProvider) {
  $stateProvider
    .state({
      name: 'sharedConversations',
      url: '/shared/{id}?assetId',
      component: 'sharedConversation',
      params: {
        assetId: {
          dynamic: true
        }
      },
      resolve: {
        conversation: function (SharedConversation, $transition$, $state) {
          return SharedConversation.findById({
            id: $transition$.params().id
          }).$promise.catch(function (err) {
            if (err) {
              console.log('Invalid Conversation, redirecting to login...')
              console.log(err)
            }
            // Redirect to login
            $state.go('login', { message: 'The URL you have entered is invalid.' })
          })
        }
      },
      data: {
        isPublicView: true
      }
    })
}
