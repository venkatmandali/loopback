// CommonJS package manager support
if (typeof module !== 'undefined' && typeof exports !== 'undefined' &&
  module.exports === exports) {
  // Export the *name* of this Angular module
  // Sample usage:
  //
  //   import lbServices from './lb-services';
  //   angular.module('app', [lbServices]);
  //
  module.exports = "lbServices";
}

(function(window, angular, undefined) {
  'use strict';

  var urlBase = "/api/v1";
  var authHeader = 'authorization';

  function getHost(url) {
    var m = url.match(/^(?:https?:)?\/\/([^\/]+)/);
    return m ? m[1] : null;
  }
  // need to use the urlBase as the base to handle multiple
  // loopback servers behind a proxy/gateway where the host
  // would be the same.
  var urlBaseHost = getHost(urlBase) ? urlBase : location.host;

/**
 * @ngdoc overview
 * @name lbServices
 * @module
 * @description
 *
 * The `lbServices` module provides services for interacting with
 * the models exposed by the LoopBack server via the REST API.
 *
 */
  var module = angular.module("lbServices", ['ngResource']);

/**
 * @ngdoc object
 * @name lbServices.Category
 * @header lbServices.Category
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `Category` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "Category",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/Categories/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use Category.parent() instead.
            "prototype$__get__parent": {
              url: urlBase + "/Categories/:id/parent",
              method: "GET",
            },

            // INTERNAL. Use Category.children.findById() instead.
            "prototype$__findById__children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/:fk",
              method: "GET",
            },

            // INTERNAL. Use Category.children.destroyById() instead.
            "prototype$__destroyById__children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.children.updateById() instead.
            "prototype$__updateById__children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.children.link() instead.
            "prototype$__link__children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.children.unlink() instead.
            "prototype$__unlink__children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.children.exists() instead.
            "prototype$__exists__children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Category.assets.findById() instead.
            "prototype$__findById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use Category.assets.destroyById() instead.
            "prototype$__destroyById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.assets.updateById() instead.
            "prototype$__updateById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.assets.link() instead.
            "prototype$__link__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.assets.unlink() instead.
            "prototype$__unlink__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.assets.exists() instead.
            "prototype$__exists__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Category.children() instead.
            "prototype$__get__children": {
              isArray: true,
              url: urlBase + "/Categories/:id/children",
              method: "GET",
            },

            // INTERNAL. Use Category.children.create() instead.
            "prototype$__create__children": {
              url: urlBase + "/Categories/:id/children",
              method: "POST",
            },

            // INTERNAL. Use Category.children.destroyAll() instead.
            "prototype$__delete__children": {
              url: urlBase + "/Categories/:id/children",
              method: "DELETE",
            },

            // INTERNAL. Use Category.children.count() instead.
            "prototype$__count__children": {
              url: urlBase + "/Categories/:id/children/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#__get__all
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Queries all of Category.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "__get__all": {
              isArray: true,
              url: urlBase + "/Categories/all",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#__count__all
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Counts all of Category.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "__count__all": {
              url: urlBase + "/Categories/all/count",
              method: "GET",
            },

            // INTERNAL. Use Category.assets() instead.
            "prototype$__get__assets": {
              isArray: true,
              url: urlBase + "/Categories/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use Category.assets.create() instead.
            "prototype$__create__assets": {
              url: urlBase + "/Categories/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Category.assets.destroyAll() instead.
            "prototype$__delete__assets": {
              url: urlBase + "/Categories/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use Category.assets.count() instead.
            "prototype$__count__assets": {
              url: urlBase + "/Categories/:id/assets/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#create
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/Categories",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#createMany
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/Categories",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#patchOrCreate
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/Categories",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#replaceOrCreate
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/Categories/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#upsertWithWhere
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/Categories/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#exists
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/Categories/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#findById
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/Categories/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#replaceById
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/Categories/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#find
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/Categories",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#findOne
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/Categories/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#updateAll
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/Categories/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#deleteById
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/Categories/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#count
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/Categories/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#prototype$patchAttributes
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/Categories/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Category#createChangeStream
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/Categories/change-stream",
              method: "POST",
            },

            // INTERNAL. Use Category.parent() instead.
            "::get::Category::parent": {
              url: urlBase + "/Categories/:id/parent",
              method: "GET",
            },

            // INTERNAL. Use Category.children.findById() instead.
            "::findById::Category::children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/:fk",
              method: "GET",
            },

            // INTERNAL. Use Category.children.destroyById() instead.
            "::destroyById::Category::children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.children.updateById() instead.
            "::updateById::Category::children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.children.link() instead.
            "::link::Category::children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.children.unlink() instead.
            "::unlink::Category::children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.children.exists() instead.
            "::exists::Category::children": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/children/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Category.children() instead.
            "::get::Category::children": {
              isArray: true,
              url: urlBase + "/Categories/:id/children",
              method: "GET",
            },

            // INTERNAL. Use Category.children.create() instead.
            "::create::Category::children": {
              url: urlBase + "/Categories/:id/children",
              method: "POST",
            },

            // INTERNAL. Use Category.children.createMany() instead.
            "::createMany::Category::children": {
              isArray: true,
              url: urlBase + "/Categories/:id/children",
              method: "POST",
            },

            // INTERNAL. Use Category.children.destroyAll() instead.
            "::delete::Category::children": {
              url: urlBase + "/Categories/:id/children",
              method: "DELETE",
            },

            // INTERNAL. Use Category.children.count() instead.
            "::count::Category::children": {
              url: urlBase + "/Categories/:id/children/count",
              method: "GET",
            },

            // INTERNAL. Use Asset.categories.findById() instead.
            "::findById::Asset::categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/:fk",
              method: "GET",
            },

            // INTERNAL. Use Asset.categories.destroyById() instead.
            "::destroyById::Asset::categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.categories.updateById() instead.
            "::updateById::Asset::categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.categories.link() instead.
            "::link::Asset::categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.categories.unlink() instead.
            "::unlink::Asset::categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.categories.exists() instead.
            "::exists::Asset::categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Asset.categories() instead.
            "::get::Asset::categories": {
              isArray: true,
              url: urlBase + "/Assets/:id/categories",
              method: "GET",
            },

            // INTERNAL. Use Asset.categories.create() instead.
            "::create::Asset::categories": {
              url: urlBase + "/Assets/:id/categories",
              method: "POST",
            },

            // INTERNAL. Use Asset.categories.createMany() instead.
            "::createMany::Asset::categories": {
              isArray: true,
              url: urlBase + "/Assets/:id/categories",
              method: "POST",
            },

            // INTERNAL. Use Asset.categories.destroyAll() instead.
            "::delete::Asset::categories": {
              url: urlBase + "/Assets/:id/categories",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.categories.count() instead.
            "::count::Asset::categories": {
              url: urlBase + "/Assets/:id/categories/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.Category#upsert
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Category#updateOrCreate
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Category#patchOrCreateWithWhere
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.Category#update
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.Category#destroyById
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Category#removeById
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Category#prototype$updateAttributes
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.Category#modelName
        * @propertyOf lbServices.Category
        * @description
        * The name of the model represented by this $resource,
        * i.e. `Category`.
        */
        R.modelName = "Category";


            /**
             * @ngdoc method
             * @name lbServices.Category#parent
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Fetches belongsTo relation parent.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `refresh` – `{boolean=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.parent = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::get::Category::parent"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.Category.children
     * @header lbServices.Category.children
     * @object
     * @description
     *
     * The object `Category.children` groups methods
     * manipulating `Category` instances related to `Category`.
     *
     * Call {@link lbServices.Category#children Category.children()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.Category#children
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Queries children of Category.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.children = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::get::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#count
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Counts children of Category.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.children.count = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::count::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#create
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Creates a new instance in children of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.children.create = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::create::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#createMany
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Creates a new instance in children of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.children.createMany = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::createMany::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#destroyAll
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Deletes all children of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.children.destroyAll = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::delete::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#destroyById
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Delete a related item by id for children.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for children
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.children.destroyById = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::destroyById::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#exists
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Check the existence of children relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for children
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.children.exists = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::exists::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#findById
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Find a related item by id for children.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for children
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.children.findById = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::findById::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#link
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Add a related item by id for children.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `fk` – `{*}` - Foreign key for children
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.children.link = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::link::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#unlink
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Remove the children relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for children
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.children.unlink = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::unlink::Category::children"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.children#updateById
             * @methodOf lbServices.Category.children
             *
             * @description
             *
             * Update a related item by id for children.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `fk` – `{*}` - Foreign key for children
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.children.updateById = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::updateById::Category::children"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.Category.assets
     * @header lbServices.Category.assets
     * @object
     * @description
     *
     * The object `Category.assets` groups methods
     * manipulating `Asset` instances related to `Category`.
     *
     * Call {@link lbServices.Category#assets Category.assets()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.Category#assets
             * @methodOf lbServices.Category
             *
             * @description
             *
             * Queries assets of Category.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::get::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#count
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Counts assets of Category.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.assets.count = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::count::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#create
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.create = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::create::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#createMany
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.createMany = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::createMany::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#destroyAll
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Deletes all assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyAll = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::delete::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#destroyById
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Delete a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::destroyById::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#exists
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Check the existence of assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.exists = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::exists::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#findById
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Find a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.findById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::findById::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#link
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Add a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.link = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::link::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#unlink
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Remove the assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.unlink = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::unlink::Category::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Category.assets#updateById
             * @methodOf lbServices.Category.assets
             *
             * @description
             *
             * Update a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Category id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.updateById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::updateById::Category::assets"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.Asset
 * @header lbServices.Asset
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `Asset` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "Asset",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/Assets/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use Asset.categories.findById() instead.
            "prototype$__findById__categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/:fk",
              method: "GET",
            },

            // INTERNAL. Use Asset.categories.destroyById() instead.
            "prototype$__destroyById__categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.categories.updateById() instead.
            "prototype$__updateById__categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.categories.link() instead.
            "prototype$__link__categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.categories.unlink() instead.
            "prototype$__unlink__categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.categories.exists() instead.
            "prototype$__exists__categories": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/categories/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Asset.tags.findById() instead.
            "prototype$__findById__tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/:fk",
              method: "GET",
            },

            // INTERNAL. Use Asset.tags.destroyById() instead.
            "prototype$__destroyById__tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.tags.updateById() instead.
            "prototype$__updateById__tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.tags.link() instead.
            "prototype$__link__tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.tags.unlink() instead.
            "prototype$__unlink__tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.tags.exists() instead.
            "prototype$__exists__tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Asset.categories() instead.
            "prototype$__get__categories": {
              isArray: true,
              url: urlBase + "/Assets/:id/categories",
              method: "GET",
            },

            // INTERNAL. Use Asset.categories.create() instead.
            "prototype$__create__categories": {
              url: urlBase + "/Assets/:id/categories",
              method: "POST",
            },

            // INTERNAL. Use Asset.categories.destroyAll() instead.
            "prototype$__delete__categories": {
              url: urlBase + "/Assets/:id/categories",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.categories.count() instead.
            "prototype$__count__categories": {
              url: urlBase + "/Assets/:id/categories/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#__get__library
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Queries library of Asset.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "__get__library": {
              isArray: true,
              url: urlBase + "/Assets/library",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#__count__library
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Counts library of Asset.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "__count__library": {
              url: urlBase + "/Assets/library/count",
              method: "GET",
            },

            // INTERNAL. Use Asset.tags() instead.
            "prototype$__get__tags": {
              isArray: true,
              url: urlBase + "/Assets/:id/tags",
              method: "GET",
            },

            // INTERNAL. Use Asset.tags.create() instead.
            "prototype$__create__tags": {
              url: urlBase + "/Assets/:id/tags",
              method: "POST",
            },

            // INTERNAL. Use Asset.tags.destroyAll() instead.
            "prototype$__delete__tags": {
              url: urlBase + "/Assets/:id/tags",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.tags.count() instead.
            "prototype$__count__tags": {
              url: urlBase + "/Assets/:id/tags/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#create
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/Assets",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#createMany
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/Assets",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#patchOrCreate
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/Assets",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#replaceOrCreate
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/Assets/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#upsertWithWhere
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/Assets/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#exists
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/Assets/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#findById
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/Assets/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#replaceById
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/Assets/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#find
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/Assets",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#findOne
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/Assets/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#updateAll
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/Assets/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#deleteById
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/Assets/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#count
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/Assets/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#prototype$patchAttributes
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/Assets/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#createChangeStream
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/Assets/change-stream",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#search
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Search Assets by name, description, category and tag
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `query` – `{string}` - The query string to search by
             *
             *  - `filter` – `{object=}` - Additional filters to apply
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The search results
             */
            "search": {
              isArray: true,
              url: urlBase + "/Assets/search",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Asset#upload
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Upload an Asset
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `options` – `{object=}` -
             *
             * @param {Object} postData Request data.
             *
             *  - `ctx` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
            "upload": {
              url: urlBase + "/Assets/upload",
              method: "POST",
            },

            // INTERNAL. Use Category.assets.findById() instead.
            "::findById::Category::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use Category.assets.destroyById() instead.
            "::destroyById::Category::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.assets.updateById() instead.
            "::updateById::Category::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.assets.link() instead.
            "::link::Category::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Category.assets.unlink() instead.
            "::unlink::Category::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Category.assets.exists() instead.
            "::exists::Category::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Categories/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Category.assets() instead.
            "::get::Category::assets": {
              isArray: true,
              url: urlBase + "/Categories/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use Category.assets.create() instead.
            "::create::Category::assets": {
              url: urlBase + "/Categories/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Category.assets.createMany() instead.
            "::createMany::Category::assets": {
              isArray: true,
              url: urlBase + "/Categories/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Category.assets.destroyAll() instead.
            "::delete::Category::assets": {
              url: urlBase + "/Categories/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use Category.assets.count() instead.
            "::count::Category::assets": {
              url: urlBase + "/Categories/:id/assets/count",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.findById() instead.
            "::findById::UserProfile::favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/:fk",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.destroyById() instead.
            "::destroyById::UserProfile::favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.updateById() instead.
            "::updateById::UserProfile::favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.link() instead.
            "::link::UserProfile::favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.unlink() instead.
            "::unlink::UserProfile::favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.exists() instead.
            "::exists::UserProfile::favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use UserProfile.favoriteAssets() instead.
            "::get::UserProfile::favoriteAssets": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/favoriteAssets",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.create() instead.
            "::create::UserProfile::favoriteAssets": {
              url: urlBase + "/UserProfiles/:id/favoriteAssets",
              method: "POST",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.createMany() instead.
            "::createMany::UserProfile::favoriteAssets": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/favoriteAssets",
              method: "POST",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.destroyAll() instead.
            "::delete::UserProfile::favoriteAssets": {
              url: urlBase + "/UserProfiles/:id/favoriteAssets",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.count() instead.
            "::count::UserProfile::favoriteAssets": {
              url: urlBase + "/UserProfiles/:id/favoriteAssets/count",
              method: "GET",
            },

            // INTERNAL. Use Conversation.assets.findById() instead.
            "::findById::Conversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use Conversation.assets.destroyById() instead.
            "::destroyById::Conversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Conversation.assets.updateById() instead.
            "::updateById::Conversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Conversation.assets.link() instead.
            "::link::Conversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Conversation.assets.unlink() instead.
            "::unlink::Conversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Conversation.assets.exists() instead.
            "::exists::Conversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Conversation.assets() instead.
            "::get::Conversation::assets": {
              isArray: true,
              url: urlBase + "/Conversations/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use Conversation.assets.create() instead.
            "::create::Conversation::assets": {
              url: urlBase + "/Conversations/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Conversation.assets.createMany() instead.
            "::createMany::Conversation::assets": {
              isArray: true,
              url: urlBase + "/Conversations/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Conversation.assets.destroyAll() instead.
            "::delete::Conversation::assets": {
              url: urlBase + "/Conversations/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use Conversation.assets.count() instead.
            "::count::Conversation::assets": {
              url: urlBase + "/Conversations/:id/assets/count",
              method: "GET",
            },

            // INTERNAL. Use SharedConversation.assets.findById() instead.
            "::findById::SharedConversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use SharedConversation.assets.destroyById() instead.
            "::destroyById::SharedConversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SharedConversation.assets.updateById() instead.
            "::updateById::SharedConversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SharedConversation.assets.link() instead.
            "::link::SharedConversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SharedConversation.assets.unlink() instead.
            "::unlink::SharedConversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SharedConversation.assets.exists() instead.
            "::exists::SharedConversation::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use SharedConversation.assets() instead.
            "::get::SharedConversation::assets": {
              isArray: true,
              url: urlBase + "/SharedConversations/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use SharedConversation.assets.create() instead.
            "::create::SharedConversation::assets": {
              url: urlBase + "/SharedConversations/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use SharedConversation.assets.createMany() instead.
            "::createMany::SharedConversation::assets": {
              isArray: true,
              url: urlBase + "/SharedConversations/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use SharedConversation.assets.destroyAll() instead.
            "::delete::SharedConversation::assets": {
              url: urlBase + "/SharedConversations/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use SharedConversation.assets.count() instead.
            "::count::SharedConversation::assets": {
              url: urlBase + "/SharedConversations/:id/assets/count",
              method: "GET",
            },

            // INTERNAL. Use Tag.assets.findById() instead.
            "::findById::Tag::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use Tag.assets.destroyById() instead.
            "::destroyById::Tag::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Tag.assets.updateById() instead.
            "::updateById::Tag::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Tag.assets.link() instead.
            "::link::Tag::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Tag.assets.unlink() instead.
            "::unlink::Tag::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Tag.assets.exists() instead.
            "::exists::Tag::assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Tag.assets() instead.
            "::get::Tag::assets": {
              isArray: true,
              url: urlBase + "/Tags/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use Tag.assets.create() instead.
            "::create::Tag::assets": {
              url: urlBase + "/Tags/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Tag.assets.createMany() instead.
            "::createMany::Tag::assets": {
              isArray: true,
              url: urlBase + "/Tags/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Tag.assets.destroyAll() instead.
            "::delete::Tag::assets": {
              url: urlBase + "/Tags/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use Tag.assets.count() instead.
            "::count::Tag::assets": {
              url: urlBase + "/Tags/:id/assets/count",
              method: "GET",
            },

            // INTERNAL. Use SalesPriority.asset() instead.
            "::get::SalesPriority::asset": {
              url: urlBase + "/SalesPriorities/:id/asset",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.Asset#upsert
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Asset#updateOrCreate
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Asset#patchOrCreateWithWhere
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.Asset#update
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.Asset#destroyById
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Asset#removeById
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Asset#prototype$updateAttributes
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.Asset#modelName
        * @propertyOf lbServices.Asset
        * @description
        * The name of the model represented by this $resource,
        * i.e. `Asset`.
        */
        R.modelName = "Asset";

    /**
     * @ngdoc object
     * @name lbServices.Asset.categories
     * @header lbServices.Asset.categories
     * @object
     * @description
     *
     * The object `Asset.categories` groups methods
     * manipulating `Category` instances related to `Asset`.
     *
     * Call {@link lbServices.Asset#categories Asset.categories()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.Asset#categories
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Queries categories of Asset.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.categories = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::get::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#count
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Counts categories of Asset.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.categories.count = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::count::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#create
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Creates a new instance in categories of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.categories.create = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::create::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#createMany
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Creates a new instance in categories of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.categories.createMany = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::createMany::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#destroyAll
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Deletes all categories of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.categories.destroyAll = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::delete::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#destroyById
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Delete a related item by id for categories.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for categories
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.categories.destroyById = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::destroyById::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#exists
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Check the existence of categories relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for categories
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.categories.exists = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::exists::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#findById
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Find a related item by id for categories.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for categories
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.categories.findById = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::findById::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#link
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Add a related item by id for categories.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `fk` – `{*}` - Foreign key for categories
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.categories.link = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::link::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#unlink
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Remove the categories relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for categories
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.categories.unlink = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::unlink::Asset::categories"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.categories#updateById
             * @methodOf lbServices.Asset.categories
             *
             * @description
             *
             * Update a related item by id for categories.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `fk` – `{*}` - Foreign key for categories
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Category` object.)
             * </em>
             */
        R.categories.updateById = function() {
          var TargetResource = $injector.get("Category");
          var action = TargetResource["::updateById::Asset::categories"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.Asset.tags
     * @header lbServices.Asset.tags
     * @object
     * @description
     *
     * The object `Asset.tags` groups methods
     * manipulating `Tag` instances related to `Asset`.
     *
     * Call {@link lbServices.Asset#tags Asset.tags()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.Asset#tags
             * @methodOf lbServices.Asset
             *
             * @description
             *
             * Queries tags of Asset.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R.tags = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::get::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#count
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Counts tags of Asset.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.tags.count = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::count::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#create
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Creates a new instance in tags of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R.tags.create = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::create::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#createMany
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Creates a new instance in tags of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R.tags.createMany = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::createMany::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#destroyAll
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Deletes all tags of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.tags.destroyAll = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::delete::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#destroyById
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Delete a related item by id for tags.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for tags
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.tags.destroyById = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::destroyById::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#exists
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Check the existence of tags relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for tags
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R.tags.exists = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::exists::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#findById
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Find a related item by id for tags.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for tags
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R.tags.findById = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::findById::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#link
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Add a related item by id for tags.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `fk` – `{*}` - Foreign key for tags
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R.tags.link = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::link::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#unlink
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Remove the tags relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for tags
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.tags.unlink = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::unlink::Asset::tags"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Asset.tags#updateById
             * @methodOf lbServices.Asset.tags
             *
             * @description
             *
             * Update a related item by id for tags.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Asset id
             *
             *  - `fk` – `{*}` - Foreign key for tags
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R.tags.updateById = function() {
          var TargetResource = $injector.get("Tag");
          var action = TargetResource["::updateById::Asset::tags"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.UserProfile
 * @header lbServices.UserProfile
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `UserProfile` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "UserProfile",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/UserProfiles/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__findById__accessTokens
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Find a related item by id for accessTokens.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for accessTokens
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "prototype$__findById__accessTokens": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/accessTokens/:fk",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__destroyById__accessTokens
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Delete a related item by id for accessTokens.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for accessTokens
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "prototype$__destroyById__accessTokens": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/accessTokens/:fk",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__updateById__accessTokens
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Update a related item by id for accessTokens.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `fk` – `{*}` - Foreign key for accessTokens
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "prototype$__updateById__accessTokens": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/accessTokens/:fk",
              method: "PUT",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.findById() instead.
            "prototype$__findById__favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/:fk",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.destroyById() instead.
            "prototype$__destroyById__favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.updateById() instead.
            "prototype$__updateById__favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.link() instead.
            "prototype$__link__favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.unlink() instead.
            "prototype$__unlink__favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.exists() instead.
            "prototype$__exists__favoriteAssets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/favoriteAssets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use UserProfile.conversations.findById() instead.
            "prototype$__findById__conversations": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/conversations/:fk",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.conversations.destroyById() instead.
            "prototype$__destroyById__conversations": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/conversations/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.conversations.updateById() instead.
            "prototype$__updateById__conversations": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/conversations/:fk",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__get__accessTokens
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Queries accessTokens of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "prototype$__get__accessTokens": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/accessTokens",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__create__accessTokens
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Creates a new instance in accessTokens of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "prototype$__create__accessTokens": {
              url: urlBase + "/UserProfiles/:id/accessTokens",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__delete__accessTokens
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Deletes all accessTokens of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "prototype$__delete__accessTokens": {
              url: urlBase + "/UserProfiles/:id/accessTokens",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__count__accessTokens
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Counts accessTokens of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "prototype$__count__accessTokens": {
              url: urlBase + "/UserProfiles/:id/accessTokens/count",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.favoriteAssets() instead.
            "prototype$__get__favoriteAssets": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/favoriteAssets",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.create() instead.
            "prototype$__create__favoriteAssets": {
              url: urlBase + "/UserProfiles/:id/favoriteAssets",
              method: "POST",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.destroyAll() instead.
            "prototype$__delete__favoriteAssets": {
              url: urlBase + "/UserProfiles/:id/favoriteAssets",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.favoriteAssets.count() instead.
            "prototype$__count__favoriteAssets": {
              url: urlBase + "/UserProfiles/:id/favoriteAssets/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__get__roles
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Queries roles of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "prototype$__get__roles": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/roles",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$__count__roles
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Counts roles of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "prototype$__count__roles": {
              url: urlBase + "/UserProfiles/:id/roles/count",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.conversations() instead.
            "prototype$__get__conversations": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/conversations",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.conversations.create() instead.
            "prototype$__create__conversations": {
              url: urlBase + "/UserProfiles/:id/conversations",
              method: "POST",
            },

            // INTERNAL. Use UserProfile.conversations.destroyAll() instead.
            "prototype$__delete__conversations": {
              url: urlBase + "/UserProfiles/:id/conversations",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.conversations.count() instead.
            "prototype$__count__conversations": {
              url: urlBase + "/UserProfiles/:id/conversations/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#create
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/UserProfiles",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#createMany
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/UserProfiles",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#patchOrCreate
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/UserProfiles",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#replaceOrCreate
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/UserProfiles/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#upsertWithWhere
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/UserProfiles/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#exists
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/UserProfiles/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#findById
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/UserProfiles/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#replaceById
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/UserProfiles/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#find
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/UserProfiles",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#findOne
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/UserProfiles/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#updateAll
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/UserProfiles/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#deleteById
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/UserProfiles/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#count
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/UserProfiles/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$patchAttributes
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/UserProfiles/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#createChangeStream
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/UserProfiles/change-stream",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#login
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Login a user with username/email and password.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `include` – `{string=}` - Related objects to include in the response. See the description of return value for more details.
             *   Default value: `user`.
             *
             *  - `rememberMe` - `boolean` - Whether the authentication credentials
             *     should be remembered in localStorage across app/browser restarts.
             *     Default: `true`.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The response body contains properties of the AccessToken created on login.
             * Depending on the value of `include` parameter, the body may contain additional properties:
             *   - `user` - `U+007BUserU+007D` - Data of the currently logged in user. (`include=user`)
             *
             */
            "login": {
              params: {
                include: 'user',
              },
              interceptor: {
                response: function(response) {
                  var accessToken = response.data;
                  LoopBackAuth.setUser(
                    accessToken.id, accessToken.userId, accessToken.user);
                  LoopBackAuth.rememberMe =
                    response.config.params.rememberMe !== false;
                  LoopBackAuth.save();
                  return response.resource;
                },
              },
              url: urlBase + "/UserProfiles/login",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#logout
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Logout a user with access token.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `access_token` – `{string=}` - Do not supply this argument, it is automatically extracted from request headers.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "logout": {
              interceptor: {
                response: function(response) {
                  LoopBackAuth.clearUser();
                  LoopBackAuth.clearStorage();
                  return response.resource;
                },
                responseError: function(responseError) {
                  LoopBackAuth.clearUser();
                  LoopBackAuth.clearStorage();
                  return responseError.resource;
                },
              },
              url: urlBase + "/UserProfiles/logout",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$verify
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Trigger user's identity verification with configured verifyOptions
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `verifyOptions` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "prototype$verify": {
              url: urlBase + "/UserProfiles/:id/verify",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#confirm
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Confirm a user registration with identity verification token.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `uid` – `{string}` -
             *
             *  - `token` – `{string}` -
             *
             *  - `redirect` – `{string=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "confirm": {
              url: urlBase + "/UserProfiles/confirm",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#resetPassword
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Reset password for a user with email.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "resetPassword": {
              url: urlBase + "/UserProfiles/reset",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#changePassword
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Change a user's password.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `id` – `{*=}` -
             *
             *  - `oldPassword` – `{string}` -
             *
             *  - `newPassword` – `{string}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "changePassword": {
              url: urlBase + "/UserProfiles/change-password",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#setPassword
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Reset user's password via a password-reset token.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `id` – `{*=}` -
             *
             *  - `newPassword` – `{string}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "setPassword": {
              url: urlBase + "/UserProfiles/reset-password",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#replacePassword
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Reset a user's password. Requires a valid short-term auth token.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `credentials` – `{object}` - The password, confirmPassword and accessToken values.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "replacePassword": {
              url: urlBase + "/UserProfiles/resetPassword",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$changePassword
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Change the user's password
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `currentPassword` – `{string}` - User's current password
             *
             *  - `newPassword` – `{string}` - New password to set
             *
             *  - `verifyPassword` – `{string}` - Validation field
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The updated User object
             */
            "prototype$changePassword": {
              url: urlBase + "/UserProfiles/:id/changePassword",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$addToRole
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Add User to the named role
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `roleName` – `{string}` - Name of the role to add.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "prototype$addToRole": {
              params: {
                'roleName': '@roleName',
              },
              url: urlBase + "/UserProfiles/:id/roles/:roleName",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$removeFromRole
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Remove User to the named role
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `roleName` – `{string}` - Name of the role to remove.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "prototype$removeFromRole": {
              url: urlBase + "/UserProfiles/:id/roles/:roleName",
              method: "DELETE",
            },

            // INTERNAL. Use Conversation.user() instead.
            "::get::Conversation::user": {
              url: urlBase + "/Conversations/:id/user",
              method: "GET",
            },

            // INTERNAL. Use SharedConversation.user() instead.
            "::get::SharedConversation::user": {
              url: urlBase + "/SharedConversations/:id/user",
              method: "GET",
            },

            // INTERNAL. Use SalesPriority.user() instead.
            "::get::SalesPriority::user": {
              url: urlBase + "/SalesPriorities/:id/user",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#getCurrent
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Get data of the currently logged user. Fail with HTTP result 401
             * when there is no user logged in.
             *
             * @param {function(Object,Object)=} successCb
             *    Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *    `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             */
            'getCurrent': {
              url: urlBase + "/UserProfiles" + '/:id',
              method: 'GET',
              params: {
                id: function() {
                  var id = LoopBackAuth.currentUserId;
                  if (id == null) id = '__anonymous__';
                  return id;
                },
              },
              interceptor: {
                response: function(response) {
                  LoopBackAuth.currentUserData = response.data;
                  return response.resource;
                },
                responseError: function(responseError) {
                  LoopBackAuth.clearUser();
                  LoopBackAuth.clearStorage();
                  return $q.reject(responseError);
                },
              },
              __isGetCurrentUser__: true,
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.UserProfile#upsert
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#updateOrCreate
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#patchOrCreateWithWhere
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#update
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#destroyById
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#removeById
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.UserProfile#prototype$updateAttributes
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];

        /**
         * @ngdoc method
         * @name lbServices.UserProfile#getCachedCurrent
         * @methodOf lbServices.UserProfile
         *
         * @description
         *
         * Get data of the currently logged user that was returned by the last
         * call to {@link lbServices.UserProfile#login} or
         * {@link lbServices.UserProfile#getCurrent}. Return null when there
         * is no user logged in or the data of the current user were not fetched
         * yet.
         *
         * @returns {Object} A UserProfile instance.
         */
        R.getCachedCurrent = function() {
          var data = LoopBackAuth.currentUserData;
          return data ? new R(data) : null;
        };

        /**
         * @ngdoc method
         * @name lbServices.UserProfile#isAuthenticated
         * @methodOf lbServices.UserProfile
         *
         * @returns {boolean} True if the current user is authenticated (logged in).
         */
        R.isAuthenticated = function() {
          return this.getCurrentId() != null;
        };

        /**
         * @ngdoc method
         * @name lbServices.UserProfile#getCurrentId
         * @methodOf lbServices.UserProfile
         *
         * @returns {Object} Id of the currently logged-in user or null.
         */
        R.getCurrentId = function() {
          return LoopBackAuth.currentUserId;
        };

        /**
        * @ngdoc property
        * @name lbServices.UserProfile#modelName
        * @propertyOf lbServices.UserProfile
        * @description
        * The name of the model represented by this $resource,
        * i.e. `UserProfile`.
        */
        R.modelName = "UserProfile";

    /**
     * @ngdoc object
     * @name lbServices.UserProfile.favoriteAssets
     * @header lbServices.UserProfile.favoriteAssets
     * @object
     * @description
     *
     * The object `UserProfile.favoriteAssets` groups methods
     * manipulating `Asset` instances related to `UserProfile`.
     *
     * Call {@link lbServices.UserProfile#favoriteAssets UserProfile.favoriteAssets()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.UserProfile#favoriteAssets
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Queries favoriteAssets of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.favoriteAssets = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::get::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#count
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Counts favoriteAssets of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.favoriteAssets.count = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::count::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#create
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Creates a new instance in favoriteAssets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.favoriteAssets.create = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::create::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#createMany
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Creates a new instance in favoriteAssets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.favoriteAssets.createMany = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::createMany::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#destroyAll
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Deletes all favoriteAssets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.favoriteAssets.destroyAll = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::delete::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#destroyById
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Delete a related item by id for favoriteAssets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for favoriteAssets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.favoriteAssets.destroyById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::destroyById::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#exists
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Check the existence of favoriteAssets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for favoriteAssets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.favoriteAssets.exists = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::exists::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#findById
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Find a related item by id for favoriteAssets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for favoriteAssets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.favoriteAssets.findById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::findById::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#link
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Add a related item by id for favoriteAssets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `fk` – `{*}` - Foreign key for favoriteAssets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.favoriteAssets.link = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::link::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#unlink
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Remove the favoriteAssets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for favoriteAssets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.favoriteAssets.unlink = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::unlink::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.favoriteAssets#updateById
             * @methodOf lbServices.UserProfile.favoriteAssets
             *
             * @description
             *
             * Update a related item by id for favoriteAssets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `fk` – `{*}` - Foreign key for favoriteAssets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.favoriteAssets.updateById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::updateById::UserProfile::favoriteAssets"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.UserProfile.conversations
     * @header lbServices.UserProfile.conversations
     * @object
     * @description
     *
     * The object `UserProfile.conversations` groups methods
     * manipulating `Conversation` instances related to `UserProfile`.
     *
     * Call {@link lbServices.UserProfile#conversations UserProfile.conversations()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.UserProfile#conversations
             * @methodOf lbServices.UserProfile
             *
             * @description
             *
             * Queries conversations of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R.conversations = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::get::UserProfile::conversations"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.conversations#count
             * @methodOf lbServices.UserProfile.conversations
             *
             * @description
             *
             * Counts conversations of UserProfile.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.conversations.count = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::count::UserProfile::conversations"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.conversations#create
             * @methodOf lbServices.UserProfile.conversations
             *
             * @description
             *
             * Creates a new instance in conversations of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R.conversations.create = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::create::UserProfile::conversations"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.conversations#createMany
             * @methodOf lbServices.UserProfile.conversations
             *
             * @description
             *
             * Creates a new instance in conversations of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R.conversations.createMany = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::createMany::UserProfile::conversations"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.conversations#destroyAll
             * @methodOf lbServices.UserProfile.conversations
             *
             * @description
             *
             * Deletes all conversations of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.conversations.destroyAll = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::delete::UserProfile::conversations"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.conversations#destroyById
             * @methodOf lbServices.UserProfile.conversations
             *
             * @description
             *
             * Delete a related item by id for conversations.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for conversations
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.conversations.destroyById = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::destroyById::UserProfile::conversations"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.conversations#findById
             * @methodOf lbServices.UserProfile.conversations
             *
             * @description
             *
             * Find a related item by id for conversations.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for conversations
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R.conversations.findById = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::findById::UserProfile::conversations"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.UserProfile.conversations#updateById
             * @methodOf lbServices.UserProfile.conversations
             *
             * @description
             *
             * Update a related item by id for conversations.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - UserProfile id
             *
             *  - `fk` – `{*}` - Foreign key for conversations
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R.conversations.updateById = function() {
          var TargetResource = $injector.get("Conversation");
          var action = TargetResource["::updateById::UserProfile::conversations"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.Conversation
 * @header lbServices.Conversation
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `Conversation` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "Conversation",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/Conversations/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use Conversation.user() instead.
            "prototype$__get__user": {
              url: urlBase + "/Conversations/:id/user",
              method: "GET",
            },

            // INTERNAL. Use Conversation.assets.findById() instead.
            "prototype$__findById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use Conversation.assets.destroyById() instead.
            "prototype$__destroyById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Conversation.assets.updateById() instead.
            "prototype$__updateById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Conversation.assets.link() instead.
            "prototype$__link__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Conversation.assets.unlink() instead.
            "prototype$__unlink__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Conversation.assets.exists() instead.
            "prototype$__exists__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Conversations/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Conversation.assets() instead.
            "prototype$__get__assets": {
              isArray: true,
              url: urlBase + "/Conversations/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use Conversation.assets.create() instead.
            "prototype$__create__assets": {
              url: urlBase + "/Conversations/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Conversation.assets.destroyAll() instead.
            "prototype$__delete__assets": {
              url: urlBase + "/Conversations/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use Conversation.assets.count() instead.
            "prototype$__count__assets": {
              url: urlBase + "/Conversations/:id/assets/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#create
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/Conversations",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#createMany
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/Conversations",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#patchOrCreate
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/Conversations",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#replaceOrCreate
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/Conversations/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#upsertWithWhere
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/Conversations/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#exists
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/Conversations/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#findById
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/Conversations/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#replaceById
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/Conversations/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#find
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/Conversations",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#findOne
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/Conversations/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#updateAll
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/Conversations/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#deleteById
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/Conversations/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#count
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/Conversations/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#prototype$patchAttributes
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/Conversations/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Conversation#createChangeStream
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/Conversations/change-stream",
              method: "POST",
            },

            // INTERNAL. Use UserProfile.conversations.findById() instead.
            "::findById::UserProfile::conversations": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/conversations/:fk",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.conversations.destroyById() instead.
            "::destroyById::UserProfile::conversations": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/conversations/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.conversations.updateById() instead.
            "::updateById::UserProfile::conversations": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/UserProfiles/:id/conversations/:fk",
              method: "PUT",
            },

            // INTERNAL. Use UserProfile.conversations() instead.
            "::get::UserProfile::conversations": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/conversations",
              method: "GET",
            },

            // INTERNAL. Use UserProfile.conversations.create() instead.
            "::create::UserProfile::conversations": {
              url: urlBase + "/UserProfiles/:id/conversations",
              method: "POST",
            },

            // INTERNAL. Use UserProfile.conversations.createMany() instead.
            "::createMany::UserProfile::conversations": {
              isArray: true,
              url: urlBase + "/UserProfiles/:id/conversations",
              method: "POST",
            },

            // INTERNAL. Use UserProfile.conversations.destroyAll() instead.
            "::delete::UserProfile::conversations": {
              url: urlBase + "/UserProfiles/:id/conversations",
              method: "DELETE",
            },

            // INTERNAL. Use UserProfile.conversations.count() instead.
            "::count::UserProfile::conversations": {
              url: urlBase + "/UserProfiles/:id/conversations/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.Conversation#upsert
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Conversation#updateOrCreate
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Conversation#patchOrCreateWithWhere
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.Conversation#update
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.Conversation#destroyById
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Conversation#removeById
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Conversation#prototype$updateAttributes
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Conversation` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.Conversation#modelName
        * @propertyOf lbServices.Conversation
        * @description
        * The name of the model represented by this $resource,
        * i.e. `Conversation`.
        */
        R.modelName = "Conversation";


            /**
             * @ngdoc method
             * @name lbServices.Conversation#user
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Fetches belongsTo relation user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `refresh` – `{boolean=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R.user = function() {
          var TargetResource = $injector.get("UserProfile");
          var action = TargetResource["::get::Conversation::user"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.Conversation.assets
     * @header lbServices.Conversation.assets
     * @object
     * @description
     *
     * The object `Conversation.assets` groups methods
     * manipulating `Asset` instances related to `Conversation`.
     *
     * Call {@link lbServices.Conversation#assets Conversation.assets()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.Conversation#assets
             * @methodOf lbServices.Conversation
             *
             * @description
             *
             * Queries assets of Conversation.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::get::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#count
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Counts assets of Conversation.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.assets.count = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::count::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#create
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.create = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::create::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#createMany
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.createMany = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::createMany::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#destroyAll
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Deletes all assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyAll = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::delete::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#destroyById
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Delete a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::destroyById::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#exists
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Check the existence of assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.exists = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::exists::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#findById
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Find a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.findById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::findById::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#link
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Add a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.link = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::link::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#unlink
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Remove the assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.unlink = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::unlink::Conversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Conversation.assets#updateById
             * @methodOf lbServices.Conversation.assets
             *
             * @description
             *
             * Update a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Conversation id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.updateById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::updateById::Conversation::assets"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.SharedConversation
 * @header lbServices.SharedConversation
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `SharedConversation` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "SharedConversation",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/SharedConversations/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use SharedConversation.user() instead.
            "prototype$__get__user": {
              url: urlBase + "/SharedConversations/:id/user",
              method: "GET",
            },

            // INTERNAL. Use SharedConversation.assets.findById() instead.
            "prototype$__findById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use SharedConversation.assets.destroyById() instead.
            "prototype$__destroyById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SharedConversation.assets.updateById() instead.
            "prototype$__updateById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SharedConversation.assets.link() instead.
            "prototype$__link__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SharedConversation.assets.unlink() instead.
            "prototype$__unlink__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SharedConversation.assets.exists() instead.
            "prototype$__exists__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SharedConversations/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use SharedConversation.assets() instead.
            "prototype$__get__assets": {
              isArray: true,
              url: urlBase + "/SharedConversations/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use SharedConversation.assets.create() instead.
            "prototype$__create__assets": {
              url: urlBase + "/SharedConversations/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use SharedConversation.assets.destroyAll() instead.
            "prototype$__delete__assets": {
              url: urlBase + "/SharedConversations/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use SharedConversation.assets.count() instead.
            "prototype$__count__assets": {
              url: urlBase + "/SharedConversations/:id/assets/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#create
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/SharedConversations",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#createMany
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/SharedConversations",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#patchOrCreate
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/SharedConversations",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#replaceOrCreate
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/SharedConversations/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#upsertWithWhere
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/SharedConversations/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#exists
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/SharedConversations/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#findById
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/SharedConversations/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#replaceById
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/SharedConversations/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#find
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/SharedConversations",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#findOne
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/SharedConversations/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#updateAll
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/SharedConversations/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#deleteById
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/SharedConversations/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#count
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/SharedConversations/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#prototype$patchAttributes
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/SharedConversations/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#createChangeStream
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/SharedConversations/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#upsert
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#updateOrCreate
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#patchOrCreateWithWhere
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#update
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#destroyById
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#removeById
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#prototype$updateAttributes
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SharedConversation` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.SharedConversation#modelName
        * @propertyOf lbServices.SharedConversation
        * @description
        * The name of the model represented by this $resource,
        * i.e. `SharedConversation`.
        */
        R.modelName = "SharedConversation";


            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#user
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Fetches belongsTo relation user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `refresh` – `{boolean=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R.user = function() {
          var TargetResource = $injector.get("UserProfile");
          var action = TargetResource["::get::SharedConversation::user"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.SharedConversation.assets
     * @header lbServices.SharedConversation.assets
     * @object
     * @description
     *
     * The object `SharedConversation.assets` groups methods
     * manipulating `Asset` instances related to `SharedConversation`.
     *
     * Call {@link lbServices.SharedConversation#assets SharedConversation.assets()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.SharedConversation#assets
             * @methodOf lbServices.SharedConversation
             *
             * @description
             *
             * Queries assets of SharedConversation.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::get::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#count
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Counts assets of SharedConversation.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.assets.count = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::count::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#create
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.create = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::create::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#createMany
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.createMany = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::createMany::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#destroyAll
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Deletes all assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyAll = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::delete::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#destroyById
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Delete a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::destroyById::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#exists
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Check the existence of assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.exists = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::exists::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#findById
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Find a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.findById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::findById::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#link
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Add a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.link = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::link::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#unlink
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Remove the assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.unlink = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::unlink::SharedConversation::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SharedConversation.assets#updateById
             * @methodOf lbServices.SharedConversation.assets
             *
             * @description
             *
             * Update a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SharedConversation id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.updateById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::updateById::SharedConversation::assets"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.Tag
 * @header lbServices.Tag
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `Tag` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "Tag",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/Tags/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use Tag.assets.findById() instead.
            "prototype$__findById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/:fk",
              method: "GET",
            },

            // INTERNAL. Use Tag.assets.destroyById() instead.
            "prototype$__destroyById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Tag.assets.updateById() instead.
            "prototype$__updateById__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Tag.assets.link() instead.
            "prototype$__link__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Tag.assets.unlink() instead.
            "prototype$__unlink__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Tag.assets.exists() instead.
            "prototype$__exists__assets": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Tags/:id/assets/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Tag.assets() instead.
            "prototype$__get__assets": {
              isArray: true,
              url: urlBase + "/Tags/:id/assets",
              method: "GET",
            },

            // INTERNAL. Use Tag.assets.create() instead.
            "prototype$__create__assets": {
              url: urlBase + "/Tags/:id/assets",
              method: "POST",
            },

            // INTERNAL. Use Tag.assets.destroyAll() instead.
            "prototype$__delete__assets": {
              url: urlBase + "/Tags/:id/assets",
              method: "DELETE",
            },

            // INTERNAL. Use Tag.assets.count() instead.
            "prototype$__count__assets": {
              url: urlBase + "/Tags/:id/assets/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#create
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/Tags",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#createMany
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/Tags",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#patchOrCreate
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/Tags",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#replaceOrCreate
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/Tags/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#upsertWithWhere
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/Tags/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#exists
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/Tags/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#findById
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/Tags/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#replaceById
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/Tags/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#find
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/Tags",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#findOne
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/Tags/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#updateAll
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/Tags/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#deleteById
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/Tags/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#count
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/Tags/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#prototype$patchAttributes
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/Tags/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Tag#createChangeStream
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/Tags/change-stream",
              method: "POST",
            },

            // INTERNAL. Use Asset.tags.findById() instead.
            "::findById::Asset::tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/:fk",
              method: "GET",
            },

            // INTERNAL. Use Asset.tags.destroyById() instead.
            "::destroyById::Asset::tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.tags.updateById() instead.
            "::updateById::Asset::tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.tags.link() instead.
            "::link::Asset::tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/rel/:fk",
              method: "PUT",
            },

            // INTERNAL. Use Asset.tags.unlink() instead.
            "::unlink::Asset::tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/rel/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.tags.exists() instead.
            "::exists::Asset::tags": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/Assets/:id/tags/rel/:fk",
              method: "HEAD",
            },

            // INTERNAL. Use Asset.tags() instead.
            "::get::Asset::tags": {
              isArray: true,
              url: urlBase + "/Assets/:id/tags",
              method: "GET",
            },

            // INTERNAL. Use Asset.tags.create() instead.
            "::create::Asset::tags": {
              url: urlBase + "/Assets/:id/tags",
              method: "POST",
            },

            // INTERNAL. Use Asset.tags.createMany() instead.
            "::createMany::Asset::tags": {
              isArray: true,
              url: urlBase + "/Assets/:id/tags",
              method: "POST",
            },

            // INTERNAL. Use Asset.tags.destroyAll() instead.
            "::delete::Asset::tags": {
              url: urlBase + "/Assets/:id/tags",
              method: "DELETE",
            },

            // INTERNAL. Use Asset.tags.count() instead.
            "::count::Asset::tags": {
              url: urlBase + "/Assets/:id/tags/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.Tag#upsert
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Tag#updateOrCreate
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Tag#patchOrCreateWithWhere
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.Tag#update
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.Tag#destroyById
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Tag#removeById
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Tag#prototype$updateAttributes
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Tag` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.Tag#modelName
        * @propertyOf lbServices.Tag
        * @description
        * The name of the model represented by this $resource,
        * i.e. `Tag`.
        */
        R.modelName = "Tag";

    /**
     * @ngdoc object
     * @name lbServices.Tag.assets
     * @header lbServices.Tag.assets
     * @object
     * @description
     *
     * The object `Tag.assets` groups methods
     * manipulating `Asset` instances related to `Tag`.
     *
     * Call {@link lbServices.Tag#assets Tag.assets()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.Tag#assets
             * @methodOf lbServices.Tag
             *
             * @description
             *
             * Queries assets of Tag.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `filter` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::get::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#count
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Counts assets of Tag.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.assets.count = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::count::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#create
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.create = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::create::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#createMany
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Creates a new instance in assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.createMany = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::createMany::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#destroyAll
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Deletes all assets of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `where` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyAll = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::delete::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#destroyById
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Delete a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.destroyById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::destroyById::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#exists
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Check the existence of assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.exists = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::exists::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#findById
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Find a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.findById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::findById::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#link
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Add a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.link = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::link::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#unlink
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Remove the assets relation to an item by id.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `options` – `{object=}` -
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.assets.unlink = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::unlink::Tag::assets"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.Tag.assets#updateById
             * @methodOf lbServices.Tag.assets
             *
             * @description
             *
             * Update a related item by id for assets.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Tag id
             *
             *  - `fk` – `{*}` - Foreign key for assets
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.assets.updateById = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::updateById::Tag::assets"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.SalesPriority
 * @header lbServices.SalesPriority
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `SalesPriority` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "SalesPriority",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/SalesPriorities/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use SalesPriority.asset() instead.
            "prototype$__get__asset": {
              url: urlBase + "/SalesPriorities/:id/asset",
              method: "GET",
            },

            // INTERNAL. Use SalesPriority.user() instead.
            "prototype$__get__user": {
              url: urlBase + "/SalesPriorities/:id/user",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#create
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/SalesPriorities",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#createMany
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/SalesPriorities",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#patchOrCreate
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/SalesPriorities",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#replaceOrCreate
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/SalesPriorities/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#upsertWithWhere
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/SalesPriorities/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#exists
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/SalesPriorities/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#findById
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/SalesPriorities/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#replaceById
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/SalesPriorities/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#find
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/SalesPriorities",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#findOne
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/SalesPriorities/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#updateAll
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/SalesPriorities/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#deleteById
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/SalesPriorities/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#count
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/SalesPriorities/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#prototype$patchAttributes
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SalesPriority id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/SalesPriorities/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#createChangeStream
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/SalesPriorities/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#upsert
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#updateOrCreate
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#patchOrCreateWithWhere
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#update
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#destroyById
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#removeById
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#prototype$updateAttributes
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SalesPriority id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SalesPriority` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.SalesPriority#modelName
        * @propertyOf lbServices.SalesPriority
        * @description
        * The name of the model represented by this $resource,
        * i.e. `SalesPriority`.
        */
        R.modelName = "SalesPriority";


            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#asset
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Fetches belongsTo relation asset.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SalesPriority id
             *
             *  - `options` – `{object=}` -
             *
             *  - `refresh` – `{boolean=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Asset` object.)
             * </em>
             */
        R.asset = function() {
          var TargetResource = $injector.get("Asset");
          var action = TargetResource["::get::SalesPriority::asset"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SalesPriority#user
             * @methodOf lbServices.SalesPriority
             *
             * @description
             *
             * Fetches belongsTo relation user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - SalesPriority id
             *
             *  - `options` – `{object=}` -
             *
             *  - `refresh` – `{boolean=}` -
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserProfile` object.)
             * </em>
             */
        R.user = function() {
          var TargetResource = $injector.get("UserProfile");
          var action = TargetResource["::get::SalesPriority::user"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.Statistics
 * @header lbServices.Statistics
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `Statistics` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "Statistics",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/Statistics/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.Statistics#create
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/Statistics",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#createMany
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/Statistics",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#patchOrCreate
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "patchOrCreate": {
              url: urlBase + "/Statistics",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#replaceOrCreate
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/Statistics/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#upsertWithWhere
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/Statistics/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#exists
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/Statistics/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#findById
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/Statistics/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#replaceById
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/Statistics/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#find
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/Statistics",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#findOne
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({"something":"value"})
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/Statistics/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#updateAll
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
            "updateAll": {
              url: urlBase + "/Statistics/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#deleteById
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/Statistics/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#count
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/Statistics/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#prototype$patchAttributes
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Statistics id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
            "prototype$patchAttributes": {
              url: urlBase + "/Statistics/:id",
              method: "PATCH",
            },

            /**
             * @ngdoc method
             * @name lbServices.Statistics#createChangeStream
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/Statistics/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.Statistics#upsert
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
        R["upsert"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Statistics#updateOrCreate
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `data` – `{object=}` - Model instance data
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
        R["updateOrCreate"] = R["patchOrCreate"];

            /**
             * @ngdoc method
             * @name lbServices.Statistics#patchOrCreateWithWhere
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.Statistics#update
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Information related to the outcome of the operation
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.Statistics#destroyById
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Statistics#removeById
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.Statistics#prototype$updateAttributes
             * @methodOf lbServices.Statistics
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Statistics id
             *
             *  - `options` – `{object=}` -
             *
             *  - `data` – `{object=}` - An object of model property name/value pairs
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `Statistics` object.)
             * </em>
             */
        R["prototype$updateAttributes"] = R["prototype$patchAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.Statistics#modelName
        * @propertyOf lbServices.Statistics
        * @description
        * The name of the model represented by this $resource,
        * i.e. `Statistics`.
        */
        R.modelName = "Statistics";



        return R;
      }]);


  module
  .factory('LoopBackAuth', function() {
    var props = ['accessTokenId', 'currentUserId', 'rememberMe'];
    var propsPrefix = '$LoopBack$';

    function LoopBackAuth() {
      var self = this;
      props.forEach(function(name) {
        self[name] = load(name);
      });
      this.currentUserData = null;
    }

    LoopBackAuth.prototype.save = function() {
      var self = this;
      var storage = this.rememberMe ? localStorage : sessionStorage;
      props.forEach(function(name) {
        save(storage, name, self[name]);
      });
    };

    LoopBackAuth.prototype.setUser = function(accessTokenId, userId, userData) {
      this.accessTokenId = accessTokenId;
      this.currentUserId = userId;
      this.currentUserData = userData;
    };

    LoopBackAuth.prototype.clearUser = function() {
      this.accessTokenId = null;
      this.currentUserId = null;
      this.currentUserData = null;
    };

    LoopBackAuth.prototype.clearStorage = function() {
      props.forEach(function(name) {
        save(sessionStorage, name, null);
        save(localStorage, name, null);
      });
    };

    return new LoopBackAuth();

    // Note: LocalStorage converts the value to string
    // We are using empty string as a marker for null/undefined values.
    function save(storage, name, value) {
      try {
        var key = propsPrefix + name;
        if (value == null) value = '';
        storage[key] = value;
      } catch (err) {
        console.log('Cannot access local/session storage:', err);
      }
    }

    function load(name) {
      var key = propsPrefix + name;
      return localStorage[key] || sessionStorage[key] || null;
    }
  })
  .config(['$httpProvider', function($httpProvider) {
    $httpProvider.interceptors.push('LoopBackAuthRequestInterceptor');
  }])
  .factory('LoopBackAuthRequestInterceptor', ['$q', 'LoopBackAuth',
    function($q, LoopBackAuth) {
      return {
        'request': function(config) {
          // filter out external requests
          var host = getHost(config.url);
          if (host && config.url.indexOf(urlBaseHost) === -1) {
            return config;
          }

          if (LoopBackAuth.accessTokenId) {
            config.headers[authHeader] = LoopBackAuth.accessTokenId;
          } else if (config.__isGetCurrentUser__) {
            // Return a stub 401 error for User.getCurrent() when
            // there is no user logged in
            var res = {
              body: { error: { status: 401 }},
              status: 401,
              config: config,
              headers: function() { return undefined; },
            };
            return $q.reject(res);
          }
          return config || $q.when(config);
        },
      };
    }])

  /**
   * @ngdoc object
   * @name lbServices.LoopBackResourceProvider
   * @header lbServices.LoopBackResourceProvider
   * @description
   * Use `LoopBackResourceProvider` to change the global configuration
   * settings used by all models. Note that the provider is available
   * to Configuration Blocks only, see
   * {@link https://docs.angularjs.org/guide/module#module-loading-dependencies Module Loading & Dependencies}
   * for more details.
   *
   * ## Example
   *
   * ```js
   * angular.module('app')
   *  .config(function(LoopBackResourceProvider) {
   *     LoopBackResourceProvider.setAuthHeader('X-Access-Token');
   *  });
   * ```
   */
  .provider('LoopBackResource', function LoopBackResourceProvider() {
    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#setAuthHeader
     * @methodOf lbServices.LoopBackResourceProvider
     * @param {string} header The header name to use, e.g. `X-Access-Token`
     * @description
     * Configure the REST transport to use a different header for sending
     * the authentication token. It is sent in the `Authorization` header
     * by default.
     */
    this.setAuthHeader = function(header) {
      authHeader = header;
    };

    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#getAuthHeader
     * @methodOf lbServices.LoopBackResourceProvider
     * @description
     * Get the header name that is used for sending the authentication token.
     */
    this.getAuthHeader = function() {
      return authHeader;
    };

    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#setUrlBase
     * @methodOf lbServices.LoopBackResourceProvider
     * @param {string} url The URL to use, e.g. `/api` or `//example.com/api`.
     * @description
     * Change the URL of the REST API server. By default, the URL provided
     * to the code generator (`lb-ng` or `grunt-loopback-sdk-angular`) is used.
     */
    this.setUrlBase = function(url) {
      urlBase = url;
      urlBaseHost = getHost(urlBase) || location.host;
    };

    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#getUrlBase
     * @methodOf lbServices.LoopBackResourceProvider
     * @description
     * Get the URL of the REST API server. The URL provided
     * to the code generator (`lb-ng` or `grunt-loopback-sdk-angular`) is used.
     */
    this.getUrlBase = function() {
      return urlBase;
    };

    this.$get = ['$resource', function($resource) {
      var LoopBackResource = function(url, params, actions) {
        var resource = $resource(url, params, actions);

        // Angular always calls POST on $save()
        // This hack is based on
        // http://kirkbushell.me/angular-js-using-ng-resource-in-a-more-restful-manner/
        resource.prototype.$save = function(success, error) {
          // Fortunately, LoopBack provides a convenient `upsert` method
          // that exactly fits our needs.
          var result = resource.upsert.call(this, {}, this, success, error);
          return result.$promise || result;
        };
        return resource;
      };

      LoopBackResource.getUrlBase = function() {
        return urlBase;
      };

      LoopBackResource.getAuthHeader = function() {
        return authHeader;
      };

      return LoopBackResource;
    }];
  });
})(window, window.angular);
