module.exports = function(grunt) {

  grunt.initConfig({

    pkg: grunt.file.readJSON('package.json'),

    docular: {
      groups: [
      ]
    },

    ngdocs: {
      options: {
        dest: 'docs',
        scripts: ['./node_modules/angular/angular.js', './node_modules/angular-animate/angular-animate.js'],
        html5Mode: true,
        bestMatch: true
      },
      loopback: {
        src: ['client/lb-services.js'],
        title: 'LoopBack API'
      }
    }

  })

  grunt.loadNpmTasks('grunt-docular')
  grunt.loadNpmTasks('grunt-ngdocs')

  grunt.registerTask('default', ['ngdocs'])

}