# Deployable Server Resources

These files are meant to be deployed on the AWS server running the application.
It is assumed that nginx is installed and that Apache is not running on ports
80 or 443. The nginx configuration folder is located at /etc/nginx

_Below is a list of files and their purposes_

| File                        | Purpose                                                                 | Location                   |
| --------------------------- | ----------------------------------------------------------------------- | -------------------------- |
| `dhparams.pem`              | Strong Diffie-Hellman group, see [here][1]                              | /home/bitnami              |
| `entrust_l1k.cer`           | Entrust Root CA Non-EV SSL Chain Certificate, downloaded from [here][2] | /home/bitnami              |
| `espn.chained.crt`          | Combined certificate, required for proper TLS security                  | /home/bitnami              |
| `espn.config.js`            | PM2 configuration file                                                  | /home/bitnami              |
| `espnsalesapp_exp_2022.cer` | 2020-2022 ESPN SSL Certificate                                          | (not uploaded)             |
| `nginx-default.conf`        | nginx server configuration file                                         | /etc/nginx/sites-available |

[1]: https://weakdh.org/sysadmin.html
[2]: https://www.entrust.com/get-support/ssl-certificate-support/root-certificate-downloads/
