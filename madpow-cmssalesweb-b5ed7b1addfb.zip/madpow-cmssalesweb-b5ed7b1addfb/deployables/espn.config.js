/* eslint-disable */
module.exports = {
  /**
   * Application configuration section
   * http://pm2.keymetrics.io/docs/usage/application-declaration/
   */
  apps: [

    // First application
    {
      name: 'API',
      script: 'server/server.js',
      watch: ["server", "client"],
      error_file: './logs/error.log',
      out_file: './logs/out.log',
      env: {
        NODE_ENV: 'development',
        AWS_S3_BUCKET: 'cmssales-dev'
      },
      env_production: {
        NODE_ENV: 'production',
        AWS_S3_BUCKET: 'cmssales'
      }
    }
  ]

}
