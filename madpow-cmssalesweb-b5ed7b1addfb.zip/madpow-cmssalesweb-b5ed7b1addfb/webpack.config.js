'use strict';

const path = require('path');
const webpack = require('webpack');
const autoprefixer = require('autoprefixer');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const GitRevisionPlugin = require('git-revision-webpack-plugin')

const PATHS = {
  client: path.resolve(__dirname, 'client'),
  build: path.resolve(__dirname, 'build')
};

module.exports = function (env) {
  process.env.WEBPACK_PUBLIC_PATH = env === 'production' ? '/asset/' : '/'
  return {
    // Needed to resolve discrepency with AMD/CommonJS issues
    // See: https://github.com/jtblin/angular-chart.js/issues/194
    resolve: {
      alias: {
        'chart': require.resolve('chart.js')
      }
    },
    entry: {
      client: ['babel-polyfill', PATHS.client],
      vendor: path.resolve(PATHS.client, 'vendor')
    },
    output: {
      path: path.resolve(PATHS.build, 'asset'),
      publicPath: process.env.WEBPACK_PUBLIC_PATH,
      pathinfo: true, // Disable for production!
      filename: '[name]-[hash].js'
    },
    devtool: 'source-map',
    devServer: {
      inline: true,
      port: 8080,
      historyApiFallback: true,
      proxy: {
        '/api': 'http://localhost:9001'
      },
      publicPath: '/',
      watchOptions: {
        ignored: /uploads/
      }
    },
    module: {
      rules: [
        {
          test: /\.js$/,
          loader: 'babel-loader',
          query: {
            compact: true
          }
        },
        {
          test: /\.css$/,
          use: ExtractTextPlugin.extract({
            fallback: 'style-loader',
            use: [
              { loader: 'css-loader', options: { sourceMap: true } },
              { loader: 'postcss-loader', options: { sourceMap: true } }
            ]
          })
        },
        {
          test: /\.scss$/,
          use: ExtractTextPlugin.extract({
            fallback: 'style-loader',
            use: [
              { loader: 'css-loader', options: { sourceMap: true } },
              { loader: 'postcss-loader', options: { sourceMap: true } },
              { loader: 'sass-loader', options: { sourceMap: true } }
            ]
          })
        },
        {
          test: /\.less$/,
          use: ExtractTextPlugin.extract({
            fallback: 'style-loader',
            use: [
              { loader: 'css-loader', options: { sourceMap: true } },
              { loader: 'postcss-loader', options: { sourceMap: true } },
              { loader: 'less-loader', options: { sourceMap: true } }
            ]
          })
        },
        {
          test: /\.html$/,
          loader: 'raw-loader'
        },
        {
          test: /\.otf(\?\S*)?$/,
          loader: 'url-loader'
        },
        {
          test: /\.eot(\?\S*)?$/,
          loader: 'url-loader'
        },
        {
          test: /\.svg(\?\S*)?$/,
          loader: 'url-loader'
        },
        {
          test: /\.ttf(\?\S*)?$/,
          loader: 'url-loader'
        },
        {
          test: /\.woff2?(\?\S*)?$/,
          loader: 'url-loader'
        },
        {
          test: /\.(jpe?g|png|gif)$/,
          exclude: '/uploads/',
          loader: 'url-loader'
        }
      ]
    },
    plugins: [
      new GitRevisionPlugin({
        branch: true
      }),
      new webpack.EnvironmentPlugin({
        NODE_ENV: 'development',
        DEBUG: true,
        WEBPACK_PUBLIC_PATH: null
      }),
      new webpack.optimize.CommonsChunkPlugin({
        name: ['client', 'vendor']
      }),
      new CopyWebpackPlugin([
        {
          from: path.resolve(__dirname, 'asset'),
          ignore: 'uploads/**'
        }
      ]),
      new ExtractTextPlugin('[name].css'),
      new HtmlWebpackPlugin({
        title: 'ESPN Sales CMS Administrator',
        template: path.resolve(PATHS.client, 'index.html'),
        filename: env === 'production' ? '../index.html' : 'index.html'
      }),
      new webpack.NoEmitOnErrorsPlugin()
    ]
  }
};
