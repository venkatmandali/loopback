'use strict'
let path = require('path')

var loopback = require('loopback')
var boot = require('loopback-boot')
var bodyParser = require('body-parser')
var compression = require('compression')

var app = module.exports = loopback()

app.set('view engine', 'pug')
app.set('views', path.join(__dirname, 'views'))

app.use(compression())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use(loopback.token({
  currentUserLiteral: 'me'
}))

app.start = function () {
  // start the web server
  return app.listen(function () {
    app.emit('started')
    var baseUrl = app.get('url').replace(/\/$/, '')
    app.logger.info('Web server listening at: %s', baseUrl)
    if (app.get('loopback-component-explorer')) {
      var explorerPath = app.get('loopback-component-explorer').mountPath
      app.logger.info('Browse your REST API at %s%s', baseUrl, explorerPath)
    }
  })
}

// Bootstrap the application, configure models, datasources and middleware.
// Sub-apps like REST API are mounted via boot scripts.
let bootOptions = {
  'appRootDir': __dirname,
  'bootDirs': [
    './server/preboot'
  ]
}
boot(app, bootOptions, function (err) {
  if (err) throw err

  // start the server if `$ node server.js`
  if (require.main === module) { app.start() }
})
