
module.exports = function (AssetFile) {
  // AssetFile.disableRemoteMethodByName('createContainer')
  // AssetFile.disableRemoteMethodByName('getContainer')
  // AssetFile.disableRemoteMethodByName('destroyContainer')
  AssetFile.disableRemoteMethodByName('download')
  AssetFile.disableRemoteMethodByName('removeFile')
  AssetFile.disableRemoteMethodByName('getFiles')
  AssetFile.disableRemoteMethodByName('getFile')

  // AssetFile.on('attached', function () {
  //   app = AssetFile.app

  //   AWS.config.update({
  //     accessKeyId: app.get('assets').s3.accessKeyId,
  //     secretAccessKey: app.get('assets').s3.secretAccessKey
  //   })

  //   AWS.config.region = app.get('assets').s3.region
  // })
}
