'use strict';

module.exports = function(AssetHtml) {

  AssetHtml.on('attached', function () {
    const app = AssetHtml.app
    const containerName = app.get('env') === 'production' ? 'cmssales-htmlAssets' : 'cmssales-dev-htmlAsets'
    AssetHtml.activeContainer = containerName

    // Check if the container exists
    AssetHtml.getContainer(containerName, function (err, s3Container) {
      if (err) {
        if (err.code === 'NoSuchBucket') {
          AssetHtml.createContainer(containerName, function (err, container) {
            app.logger.info('HTML Asset Storage Container Created')
            app.logger.debug(container)
          })
        }
      }
    })
  })

}
