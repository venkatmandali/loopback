'use strict'

const p = require('../package.json')
const version = p.version.split('.').shift()

module.exports = {
  restApiRoot: '/api' + (version > 0 ? '/v' + version : ''),
  host: process.env.HOST || 'localhost',
  port: process.env.PORT || 9001,
  assets: {
    s3: {
      bucket: process.env.AWS_S3_BUCKET || 'cmssales-dev',
      region: process.env.AWS_S3_REGION || 'us-east-1',
      accessKeyID: process.env.AWS_S3_ACCESS_KEY_ID || 'AKIAJKTRIPQ5GXLVMDNQ',
      secretAccessKey: process.env.AWS_S3_SECRET_ACCESS_KEY || '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'
    }
  }
}
