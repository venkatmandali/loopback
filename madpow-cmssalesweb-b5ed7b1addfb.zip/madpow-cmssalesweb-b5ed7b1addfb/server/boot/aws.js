'use strict'

const AWS = require('aws-sdk')
const path = require('path')

module.exports = function configureAws(server) {
  const configPath = path.resolve(__dirname, '../', 'aws.json')
  AWS.config.loadFromPath(configPath)
}
