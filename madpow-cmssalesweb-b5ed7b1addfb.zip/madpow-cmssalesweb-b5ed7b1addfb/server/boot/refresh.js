module.exports = function (app) {
  /* Access token live time prolongation */
  app.use(function accessTokenProlongation (req, res, next) {
    let token = req.accessToken
    let now = new Date()
    let createTS = token ? token.created.getTime() : 0
    let expiredTS = token ? req.accessToken.ttl * 1000 : 0
    let dayTS = 24 * 60 * 60 * 1000
    let defaults = app.get('defaults')
    let idleTimeout = defaults.idleTimeout || dayTS

    if (!token || (token && (createTS + expiredTS < now))) {
      return next()
    }

    if (now.getTime() - createTS < idleTimeout) {
      return next()
    }

    token.updateAttribute('created', now, next)
  })
}
