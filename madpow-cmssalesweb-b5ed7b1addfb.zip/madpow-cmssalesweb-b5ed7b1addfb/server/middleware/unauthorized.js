module.exports = function () {
  return function unauthorized (err, req, res, next) {
    console.log('Unauthorized request, redirecting to /login ...')
    res.redirect('/login')
    next()
  }
}
