'use strict'

const path = require('path')
const providers = require('./providers.json')

const html = {
  provider: 'amazon',
  key: providers.amazon.key,
  keyId: providers.amazon.keyId,
  nameConflict: 'makeUnique',
  allowedContentTypes: ['image/jpeg', 'image/jpg', 'image/gif', 'image/png', 'application/pdf', 'video/mp4'],
  acl: 'public-read',
  maxFileSize: 100 * 1024 * 1024
}
const asset = {
  provider: 'filesystem',
  root: './asset/uploads',
  acl: 'public-read',
  allowedContentTypes: ['image/jpeg', 'image/jpg', 'image/gif', 'image/png', 'application/pdf', 'video/mp4'],
  maxFileSize: 100 * 1024 * 1024,
  getFilename: function (fileInfo) {
    const filename = fileInfo.name.replace(/\s+/g, '-').toLowerCase()
    // Add the file extension to the front of the filename to make filtering on S3 easier
    const ext = path.extname(filename)
    return `${ext.slice(1)}-${new Date().getTime()}-${filename}`
  }
}
module.exports = {
  assetStorage: asset,
  htmlStorage: html
}
