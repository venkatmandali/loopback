module.exports = function (server) {
  let winston = require('winston')
  winston.configure({
    level: server.get('logger').level,
    transports: [
      new winston.transports.Console({
        timestamp: true,
        colorize: true,
        prettyPrint: true,
        depth: 3,
        humanReadableUnhandledException: true
      })
    ]
  })
  server.logger = winston
}
