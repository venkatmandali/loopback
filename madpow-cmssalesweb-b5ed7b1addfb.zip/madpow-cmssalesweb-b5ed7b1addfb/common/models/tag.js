'use strict'

module.exports = function (Tag) {
  Tag.validateAsync('name', validateName, {
    message: 'This tag has already been created. Please enter another name.'
  })

  function validateName (err, next) {
    if (!this.name) {
      return err()
    }

    let regex = '/^' + this.name + '$/i'
    let where = {
      and: [
        { name: { regexp: regex } }
      ]
    }
    if (this.id) {
      where.and.push({
        id: {
          neq: this.id
        }
      })
    }

    Tag.find({
      where: where
    }, function (error, result) {
      if (error || result.length) {
        err()
      }
      return next()
    })
  }
}
