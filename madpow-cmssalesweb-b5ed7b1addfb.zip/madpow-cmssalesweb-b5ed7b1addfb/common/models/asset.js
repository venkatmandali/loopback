'use strict'

const async = require('async')
const PDFImage = require('pdf-image').PDFImage
const ffmpeg = require('fluent-ffmpeg')
const sharp = require('sharp')
const Inliner = require('inliner')
const webshot = require('webshot')
const tmp = require('tmp')
const fs = require('fs')
const path = require('path')
const AWS = require('aws-sdk')

module.exports = function(Asset) {
  Asset.observe('before save', function checkCategoriesAndTags(ctx, next) {
    // When updating attributes ()
    const data = ctx.data || ctx.instance
    const app = Asset.app
    if (data.categoryIds) {
      ctx.hookState.categoryIds = data.categoryIds
      delete data.categoryIds
    }

    if (data.tagIds) {
      ctx.hookState.tagIds = data.tagIds
      delete data.tagIds
    }

    if (!data.originalFilename && data.url) {
      // This is really only for legacy data, all new assets will have this field set
      data.originalFilename = data.url.slice(data.url.lastIndexOf('/') + 1)
    }

    // Check for WYSIWYG content
    if (data.type === 'text/html' && data.editorContent) {
      if (data.originalContent && data.editorContent === data.originalContent) {
        return next()
      }
      const logger = app.logger
      data.originalContent = data.editorContent
      delete data.editorContent
      // Inline all styles, images, and scripts
      new Inliner(data.originalContent, function(err, html) {
        if (err) {
          logger.error(err)
          next(err)
        } else {
          const basename = data.name.replace(/\s+/g, '-').toLowerCase()
          const timestamp = new Date().getTime()
          // Create a buffer to hold the HTML string (for S3)
          const htmlBuffer = Buffer.from(html, 'utf8')
          const uploadParams = {
            Bucket: app.get('assets').s3.bucket,
            ACL: 'public-read'
          }
          if (data.id) {
            uploadParams.Metadata = { 'Asset-Id': data.id }
          }
          const assetParams = {
            Key: `assetStorage/html-${timestamp}-${basename}.html`,
            ContentType: 'text/html'
          }
          const thumbnailParams = {
            Key: `assetStorage/html-${timestamp}-${basename}_thumb.png`,
            ContentType: 'image/png'
          }
          const s3obj = new AWS.S3()

          // Upload HTML file to S3
          const assetPromise = s3obj
            .upload(
              Object.assign({}, uploadParams, assetParams, {
                Body: htmlBuffer
              })
            )
            .on('httpUploadProgress', function(evt) {
              // TODO: Is there a way to send these progress events to the client?
              logger.debug('Progress:', evt)
            })
            .promise()
            .then(awsResult => {
              logger.debug('Upload Successful', awsResult)
              data.url = awsResult.Location
              data.size = htmlBuffer.length
            })
            .catch(err => {
              throw err
            })

          // Create Screenshot
          const assetConfig = app.get('assets')
          const options = {
            siteType: 'html',
            streamType: 'png',
            windowSize: { width: 900, height: 768 },
            shotSize: { width: 'all', height: 'all' }
          }
          // Create a screenshot of the rendered HTML
          // Use a temporary file so we can work with buffers
          const tmpShot = tmp.fileSync({ postfix: '.png' })
          logger.debug('Saving thumbnail:', tmpShot.name, tmpShot.fd)
          webshot(html, tmpShot.name, options, function(err) {
            if (err) {
              logger.error(err)
              throw err
            } else {
              logger.debug('Checking thumbnail dimensions ...')
              let imageFile = fs.readFileSync(tmpShot.name)
              const overlay = path.resolve(
                __dirname,
                '../../',
                'deployables/cropOverlay.png'
              )

              const image = sharp(imageFile)
              image
                .metadata()
                .then(dimensions => {
                  logger.debug('Metadata', dimensions)
                  if (dimensions.height >= assetConfig.htmlMaxHeight) {
                    logger.debug('Resizing w/overlay')
                    const adjustedWidth =
                      dimensions.width *
                      (assetConfig.htmlMaxHeight / dimensions.height)
                    if (adjustedWidth < assetConfig.htmlThumbWidth) {
                      return image
                        .resize(
                          assetConfig.htmlThumbWidth,
                          assetConfig.htmlMaxHeight
                        )
                        .background({ r: 0, g: 0, b: 0, alpha: 0 })
                        .embed(sharp.gravity.north)
                        .overlayWith(overlay, { gravity: sharp.gravity.south })
                        .png()
                        .toBuffer()
                    } else {
                      return image
                        .resize(
                          assetConfig.htmlThumbWidth,
                          assetConfig.htmlMaxHeight
                        )
                        .withoutEnlargement()
                        .max()
                        .overlayWith(overlay, { gravity: sharp.gravity.south })
                        .png()
                        .toBuffer()
                    }
                  } else {
                    logger.debug('Resizing')
                    return image
                      .resize(
                        Math.min(dimensions.width, assetConfig.htmlThumbWidth),
                        Math.min(dimensions.height, assetConfig.htmlMaxHeight)
                      )
                      .withoutEnlargement()
                      .max()
                      .png()
                      .toBuffer()
                  }
                })
                .then(imageThumbnail => {
                  const params = Object.assign(
                    {},
                    uploadParams,
                    thumbnailParams,
                    {
                      Body: imageThumbnail
                    }
                  )
                  // logger.debug(params)
                  const thumbnailPromise = s3obj
                    .upload(params)
                    .on('httpUploadProgress', function(evt) {
                      // TODO: Is there a way to send these progress events to the client?
                      logger.debug('Thumbnail Progress:', evt)
                    })
                    .promise()
                    .then(thumbnailResult => {
                      logger.debug(
                        'Thumbnail Upload Successful',
                        thumbnailResult
                      )
                      data.thumbnailUrl = thumbnailResult.Location
                      // Be sure to clean up the temp file, since this app is a long-running process
                      tmpShot.removeCallback()
                    })
                    .catch(err => {
                      throw err
                    })

                  // Finally, wait for both Promises before calling next()
                  Promise.all([assetPromise, thumbnailPromise])
                    .then(({ url, thumbnailUrl }) => {
                      next()
                    })
                    .catch(err => {
                      next(err)
                    })
                })
                .catch(e => {
                  logger.error(e)
                })
            }
          })
        }
      })
    } else {
      next()
    }
  })

  Asset.observe('after save', function addCategoriesAndTags(ctx, next) {
    const app = Asset.app

    app.logger.info(
      'Asset::after save: ' + (ctx.isNewInstance ? 'create' : 'update')
    )
    if (ctx.instance && ctx.instance.id) {
      app.logger.info(ctx.instance.name + ': ' + ctx.instance.id)
      if (ctx.hookState.categoryIds) {
        ctx.instance.categories(function(err, categories) {
          if (err) {
            next(err)
          } else {
            app.logger.info('Got ' + categories.length + ' categories')
            // Unlink any existing categories
            categories.forEach(function(category) {
              if (
                ctx.hookState.categoryIds.indexOf(category.id.toString()) === -1
              ) {
                app.logger.info(
                  'Removing category ' + category.name + ': ' + category.id
                )
                ctx.instance.categories.remove(category)
              }
            })
            // Link categories based on the list passed in to the save call
            ctx.hookState.categoryIds.forEach(function(categoryId) {
              app.logger.info('Adding category ' + categoryId)
              ctx.instance.categories.add(categoryId)
            })
          }
        })
      }

      if (ctx.hookState.tagIds) {
        ctx.instance.tags(function(err, tags) {
          if (err) {
            next(err)
          } else {
            app.logger.info('Got ' + tags.length + ' tags')
            // Unlink any existing tags
            tags.forEach(function(tag) {
              if (ctx.hookState.tagIds.indexOf(tag.id.toString()) === -1) {
                app.logger.info('Removing tag ' + tag.name)
                ctx.instance.tags.remove(tag)
              }
            })
            // Link tags based on the list passed in to the save call
            ctx.hookState.tagIds.forEach(function(tagId) {
              app.logger.info('Adding tag ' + tagId)
              ctx.instance.tags.add(tagId)
            })
          }
        })
      }
    }

    next()
  })

  Asset.upload = function(ctx, options, callback) {
    if (!options) options = {}

    const app = Asset.app
    const container = 'assetStorage'
    ctx.req.params.container = container

    // Upload the file to local storage for processing
    // TODO: Refactor this into multiple functions (try to use Promises)
    app.models.AssetFile.upload(ctx.req, ctx.result, options, function(
      err,
      uploadResult
    ) {
      if (err) {
        app.logger.error('Error uploading file', err)
        return callback(err)
      } else {
        // Set up some useful values
        const fileInfo = uploadResult.files.file[0]
        const assetId = uploadResult.fields.assetId
        if (Array.isArray(assetId) && assetId.length) {
          assetId = assetId[0]
        }
        app.logger.info('File info:', fileInfo)

        const fileRoot = path.resolve(
          __dirname,
          '../../',
          app.datasources.assetStorage.settings.root,
          container
        )

        // User-editable configuration, mainly for thumbnail specs
        const assetConfig = app.get('assets')

        // Used to handle resizing and uploading details
        const specs = [
          {
            filePath: path.resolve(fileRoot, fileInfo.name),
            fileInfo: fileInfo,
            localRoot: fileRoot,
            assetId: assetId
          },
          {
            fileInfo: fileInfo,
            localRoot: fileRoot,
            width: assetConfig.thumbWidth,
            ext: assetConfig.thumbExt,
            isThumbnail: true,
            assetId: assetId
          }
        ]

        // Process files, creating thumbnails
        async.eachSeries(specs, processUpload, function(err) {
          app.logger.debug('Completed upload processing')
          if (err) {
            app.logger.error('Error during upload processing', err)
            return callback(err)
          }
          postUpload(specs, callback)
        })
      }
    })
  }

  function processUpload(spec, cb) {
    const app = Asset.app
    if (!spec.isThumbnail) {
      return cb()
    }

    const ext = path.extname(spec.fileInfo.name)
    const fileNameRoot = path.basename(spec.fileInfo.name, ext)
    const srcFile = path.resolve(spec.localRoot, spec.fileInfo.name)
    const destFile = (spec.filePath = path.resolve(
      spec.localRoot,
      fileNameRoot + spec.ext
    ))
    app.logger.debug('Processing', spec.fileInfo.name)

    switch (spec.fileInfo.type) {
      case 'image/jpeg':
      case 'image/jpg':
      case 'image/gif':
      case 'image/png':
        createImageThumbnail(
          srcFile,
          destFile,
          spec.width,
          spec.fileInfo.type,
          cb
        )
        break
      case 'video/mp4':
        createVideoThumbnail(srcFile, destFile, spec.width, cb)
        break
      case 'application/pdf':
        createPDFThumbnail(srcFile, destFile, spec.width, cb)
        break
    }
  }

  function createImageThumbnail(src, dest, width, type, cb) {
    const app = Asset.app
    app.logger.debug('createImageThumbnail')
    if (type === 'image/gif') {
      // For GIFs, specify a frame in case of animated GIFs
      // This will prevent ImageMagick from creating multiple thumbnails
      src = src + '[0]'
    }
    // Create the image thumbnail
    sharp(src)
      .resize(width)
      .png()
      .toFile(dest)
      .then(info => {
        app.logger.info('Image Thumbnail created:', dest)
        app.logger.info('Details:', info)
        cb()
      })
      .catch(cb)
  }

  function createVideoThumbnail(src, dest, width, cb) {
    const app = Asset.app
    app.logger.debug('createVideoThumbnail')
    const filename = path.basename(src)
    const ext = path.extname(filename)
    const fileNameRoot = path.basename(src, ext)
    const filePathRoot = path.dirname(src)

    // Create the video thumbnail
    // Thumbnail overlay image for video assets
    const buttonPlay = path.resolve(
      __dirname,
      '../../',
      'deployables/button_play.svg'
    )

    const screenshotFile = fileNameRoot + '-screenshot.png'
    const screenshotFilePath = path.resolve(filePathRoot, screenshotFile)

    // Use ffmpeg to take a screenshort first
    ffmpeg(src)
      .takeScreenshots({
        count: 1,
        filename: screenshotFile,
        folder: filePathRoot
      })
      .on('codecData', function(data) {
        app.logger.info('Got Video Metadata:', data)
      })
      .on('end', function() {
        // Now use sharp to resize and overlay the screenshot
        sharp(screenshotFilePath)
          .resize(width)
          .overlayWith(buttonPlay)
          .png()
          .toFile(dest)
          .then(info => {
            app.logger.info('Video Thumbnail w/overlay created:', dest)
            app.logger.info('Details:', info)
            // Delete the intermediary screenshot file
            fs.unlink(screenshotFilePath, function(err) {
              if (err) {
                app.logger.error(
                  'There was a problem deleting the Video Thumbnail intermediary image:',
                  screenshotFilePath
                )
                return cb(err)
              }
              app.logger.info(
                'Video Thumbnail intermediary image deleted:',
                screenshotFilePath
              )
              cb()
            })
          })
          .catch(cb)
      })
      .on('error', cb)
  }

  function createPDFThumbnail(src, dest, width, cb) {
    const app = Asset.app
    app.logger.debug('createPDFThumbnail')
    // TODO: Here are possible options for ImageMagick, but they don't improve the output so we aren't using them
    const options = {
      convertOptions: {
        '-verbose': '',
        '-density': 72,
        '-trim': '',
        '-flatten': '',
        '-quality': 100,
        '-sharpen': '0x1.0'
      }
    }
    const pdfImage = new PDFImage(src)
    pdfImage.convertPage(0).then(function(imagePath) {
      app.logger.debug('Resizing PDF Thumbnail')
      sharp(imagePath)
        // .resize(width)
        .png()
        .toFile(dest)
        .then(info => {
          // spec.filePath = imagePath
          app.logger.info('PDF Thumbnail created:', imagePath)
          fs.unlink(imagePath, function(err) {
            if (err) {
              app.logger.error(
                'There was a problem deleting the PDF Thumbnail intermediary image:',
                imagePath
              )
              return cb(err)
            }
            app.logger.info(
              'PDF Thumbnail intermediary image deleted:',
              imagePath
            )
            cb()
          })
        })
        .catch(cb)
    })
  }

  function postUpload(specs, callback) {
    const app = Asset.app
    app.logger.debug('postUpload')
    // Upload files and thumbnails to S3
    async.eachSeries(specs, handleS3Upload, function(err) {
      app.logger.debug('Completed S3 upload')
      if (err) {
        app.logger.error(err)
        return callback(err)
      }

      // Clean up and return details to the client
      const mainFileSpec = specs[0]
      const thumbnailSpec = specs[1]
      const url = mainFileSpec.aws.Location
      const thumbnailUrl = thumbnailSpec.aws.Location

      const updatedAttributes = {
        type: mainFileSpec.fileInfo.type,
        size: mainFileSpec.fileInfo.size,
        url: url,
        thumbnailUrl: thumbnailUrl,
        originalFilename: mainFileSpec.fileInfo.originalFilename
      }

      // Delete the local storage - the client doesn't need to wait for this
      async.eachSeries(specs, removeUploadedFiles, function(err) {
        app.logger.debug('Completed local file removal')
        if (err) {
          app.logger.error(err)
          // If there's an error cleaning up the files, don't notify the client
          // TODO: Notify somebody, though.
          // callback(err)
        }
      })

      if (mainFileSpec.assetId) {
        // Remove any old files
        // TODO: Should this be a seperate method for the client to call after save?
        // We can't use the 'after save' hook because we don't have access to the old
        // asset data at that point
        Asset.findById(mainFileSpec.assetId, function(err, asset) {
          if (err) {
            app.logger.error(err)
            // return callback(err)
          } else {
            // Delete the old file and thumbnail from S3
            const thumbnailUrl =
              mainFileSpec.fileInfo.container +
              asset.thumbnailUrl.slice(asset.thumbnailUrl.lastIndexOf('/'))
            const assetUrl =
              mainFileSpec.fileInfo.container +
              asset.url.slice(asset.url.lastIndexOf('/'))
            app.logger.info('Deleting: ' + assetUrl)
            app.logger.info('Deleting: ' + thumbnailUrl)

            const s3obj = new AWS.S3({
              params: {
                Bucket: app.get('assets').s3.bucket
              }
            })
            s3obj.deleteObjects(
              {
                Delete: {
                  Objects: [{ Key: thumbnailUrl }, { Key: assetUrl }]
                }
              },
              function(err, data) {
                if (err) {
                  app.logger.error(err)
                }
                app.logger.debug(data)
              }
            )
          }
        })
      }

      // Return the updated attributes to the client
      // The client will call save() when it receives this data
      return callback(null, updatedAttributes)
    })
  }

  function removeUploadedFiles(spec, cb) {
    const app = Asset.app
    app.logger.debug('Removing file: %s', spec.filePath)

    fs.unlink(spec.filePath, function(err) {
      if (err) {
        return cb(err)
      }
      app.logger.debug('Removed:', spec.filePath)
      cb()
    })
  }

  function handleS3Upload(spec, cb) {
    const app = Asset.app
    app.logger.debug('handleS3Upload')
    // Read the file
    // app.logger.debug('Preparing to upload', spec)
    fs.readFile(spec.filePath, function(err, buffer) {
      if (err) {
        return cb(err)
      }

      app.logger.info('Uploading to S3:', spec.filePath)
      // app.logger.debug('Name:', spec.fileInfo.name)
      // app.logger.debug('Path:', spec.filePath)
      // app.logger.debug(AWS.config)
      const uploadParams = {
        Bucket: app.get('assets').s3.bucket,
        Key: spec.fileInfo.container + '/' + path.basename(spec.filePath),
        ContentType: spec.isThumbnail ? 'image/png' : spec.fileInfo.type,
        ACL: 'public-read'
      }
      // Add Content-Disposition header for the full asset file (but not the thumbnail)
      if (!spec.isThumbnail) {
        uploadParams.ContentDisposition =
          'attachment;filename=' + spec.fileInfo.originalFilename
      }
      // Add assetId for existing files - This won't work for new assets, since
      // upload() is called before $save() but it might be useful in the future
      if (spec.assetId) {
        uploadParams.Metadata = {
          'Asset-Id': spec.assetId
        }
      }
      // TODO: Look into creating one instance of S3 and just changing the parameters for each file
      const s3obj = new AWS.S3({
        params: uploadParams
      })
      // app.logger.debug(s3obj)

      // Upload the file to S3
      s3obj
        .upload({ Body: buffer })
        .on('httpUploadProgress', function(evt) {
          // TODO: Is there a way to send these progress events to the client?
          app.logger.debug('Progress:', evt)
        })
        .send(function(err, data) {
          if (err) {
            return cb(err)
          }

          app.logger.debug('Upload Successful', data)

          spec.aws = data
          cb()
        })
    })
  }

  Asset.remoteMethod('upload', {
    description: 'Upload an Asset',
    accepts: [
      { arg: 'ctx', type: 'object', http: { source: 'context' } },
      { arg: 'options', type: 'object', http: { source: 'query' } }
    ],
    returns: {
      arg: 'fileObject',
      type: 'object',
      root: true
    },
    http: { verb: 'post' }
  })

  /**
   * Uploads a linked file (primarily images) from the WYSIWYG editor (CKEditor)
   *
   * This method uses the Storage Component to save files to S3.
   * It will return an accessible path to the editor.
   */
  Asset.uploadHTMLAsset = function(req, res, body, callback) {
    const UploadModel = Asset.app.models.AssetHTML
    const options = {
      container: UploadModel.activeContainer
    }
    const functionName = req.query.CKEditorFuncNum
    // TODO: This does not store any metadata (like original name or asset ID)
    // See here for a way to handle that: https://stackoverflow.com/questions/28885282/how-to-store-files-with-meta-data-in-loopback
    UploadModel.upload(req, res, options, function(err, result) {
      if (err) {
        // TODO: This, along with the afterRemoteError handler below, doesn't seem to actually work
        // Find a way to actually return the error to the client
        const message = `Error uploading file, please try again. ${err.message}`
        const editorCallback = `<script type="text/javascript">window.parent.CKEDITOR.tools.callFunction(${functionName}, '', '${message}');</script>`
        return callback(editorCallback)
      } else {
        const fileResult = result.files.upload[0]
        const fileUrl = fileResult.providerResponse.location
        const message = `Successfully uploaded ${fileResult.originalFilename}`
        const editorCallback = `<script type="text/javascript">window.parent.CKEDITOR.tools.callFunction(${functionName}, '${fileUrl}', '${message}');</script>`
        return callback(null, editorCallback)
      }
    })
  }

  Asset.remoteMethod('uploadHTMLAsset', {
    description: 'Upload images for an HTML Asset',
    accepts: [
      { arg: 'req', type: 'object', http: { source: 'req' } },
      { arg: 'res', type: 'object', http: { source: 'res' } },
      { arg: 'body', type: 'object', http: { source: 'body' } }
    ],
    returns: [{ type: 'string', root: true }],
    http: { verb: 'post' }
  })

  Asset.afterRemote('uploadHTMLAsset', function(ctx, result, next) {
    ctx.res.contentType('text/html')
    ctx.res.status(200).send(result)
  })

  Asset.afterRemoteError('uploadHTMLAsset', function(ctx, next) {
    ctx.res.contentType('text/html')
    ctx.res.status(500).send(ctx.error)
  })

  /**
   * Search Assets by name, description, category and tag
   * @param {string} query The query string to search by
   * @param {object} options
   * @param {Function(Error, array)} callback
   */

  Asset.search = function(query, filter, options, callback) {
    // In order to properly search Tags and Categories along with Assets,
    // we'll need to perform lookups on all 3, then merge the results.
    // This is parly a limitation of NoSQL, but also a result of using
    // Loopback as a sort of ORM layer
    const app = Asset.app
    const Tag = app.models.Tag
    const Category = app.models.Category
    const regex = '/' + query + '/i'

    if (query.length < 3) {
      return callback(null, [])
    }

    const assetFilter = {
      where: {
        and: [
          { deleted: false },
          {
            or: [{ name: { regexp: regex } }, { summary: { regexp: regex } }]
          }
        ]
      }
    }
    if (filter) {
      Object.assign(assetFilter, filter)
    }
    Asset.find(assetFilter)
      .then(assetList => {
        const assetIds = assetList.map(asset => asset.id.toString())
        const tags = Tag.find({
          where: {
            name: { regexp: regex }
          },
          include: {
            relation: 'assets',
            scope: {
              where: {
                and: [{ deleted: false }, { id: { nin: assetIds } }]
              }
            }
          }
        })
        const categories = Category.find({
          where: {
            name: { regexp: regex }
          },
          include: {
            relation: 'assets',
            scope: {
              where: {
                and: [{ deleted: false }, { id: { nin: assetIds } }]
              }
            }
          }
        })
        return Promise.all([categories, tags]).then(function(results) {
          // Loop over the tags/categories and add them to the result set
          const items = Array.prototype.concat.apply([], results)
          const assetPromises = []
          items.forEach(function(item) {
            assetPromises.push(item.assets())
          })
          return Promise.all(assetPromises).then(function(
            additionalAssetLists
          ) {
            const additionalAssets = Array.prototype.concat.apply(
              [],
              additionalAssetLists
            )
            additionalAssets.forEach(function(asset) {
              // THe 'nin' clause above should prevent duplicate assets, but it doesn't appear
              // to be working properly
              if (assetIds.indexOf(asset.id.toString()) === -1) {
                assetList.push(asset)
                // Add the asset ID to the list, to prevent additional duplicates
                assetIds.push(asset.id.toString())
              }
            })
            return callback(null, assetList)
          })
        })
      })
      .catch(function(err) {
        return callback(err)
      })
  }

  // Disable the POST and DELETE verbs for the 'library' scope
  Asset.disableRemoteMethodByName('__create__library')
  Asset.disableRemoteMethodByName('__delete__library')

  Asset.on('dataSourceAttached', function(obj) {
    // Override the delete method to set the 'deleted' flag instead
    Asset.deleteById = function(id, options, cb) {
      Asset.findById(id, function(err, asset) {
        if (err) {
          cb(err)
        } else {
          asset.updateAttribute('deleted', true, function(err) {
            if (err) {
              cb(err)
            } else {
              // Remove asset relationships
              // Since we're overriding deleteById, we aren't triggering any
              // operation hooks, so we need to handle this here. Unlike in
              // the hooks, however, we have the full instance already, so
              // this is actually slightly better than using hooks
              // Remove:
              // - Categories
              // - Tags
              // - Favorites (UserProfile)
              // - Sales Priorities
              // - Conversations
              // - Shared Conversations

              // let logger = Asset.app.logger
              // asset.categories(function (err, categories) {
              //   if (err) {
              //     console.error('Categories', err)
              //   } else {
              //     app.logger.debug(categories)
              //     categories.forEach(function (category) {
              //       logger.info(category.name)
              //       asset.categories.remove(category)
              //     })
              //   }
              // })
              // asset.tags(function (err, tags) {
              //   if (err) {
              //     console.error('Tags', err)
              //   } else {
              //     app.logger.debug(tags)
              //     tags.forEach(function (tag) {
              //       logger.info(tag.name)
              //       asset.tags.remove(tag)
              //     })
              //   }
              // })

              // let UserProfile = Asset.app.models.UserProfile
              // UserProfile.find({
              //   where: {
              //     assetIds: asset.id
              //   }
              // }, function (err, users) {
              //   if (err) {
              //     console.error('UserProfile', err)
              //   } else {
              //     app.logger.debug(users)
              //     users.forEach(function (user) {
              //       logger.info(user.email)
              //       user.favoriteAssets.remove(asset)
              //     })
              //   }
              // })

              // let SalesPriority = Asset.app.models.SalesPriority
              // SalesPriority.find({
              //   where: {
              //     assetId: asset.id
              //   }
              // }, function (err, salesPriorities) {
              //   if (err) {
              //     console.error('SalesPriority', err)
              //   } else {
              //     app.logger.debug(salesPriorities)
              //     salesPriorities.forEach(function (salesPriority) {
              //       logger.info(salesPriority.id.toString())
              //       salesPriority.asset(null)
              //     })
              //   }
              // })

              // let Conversation = Asset.app.models.Conversation
              // Conversation.find({
              //   where: {
              //     assetIds: asset.id
              //   }
              // }, function (err, conversations) {
              //   if (err) {
              //     console.error('Conversation', err)
              //   } else {
              //     app.logger.debug(conversations)
              //     conversations.forEach(function (conversation) {
              //       logger.info(conversation.name)
              //       conversation.assets.remove(asset)
              //     })
              //   }
              // })

              // let SharedConversation = Asset.app.models.SharedConversation
              // SharedConversation.find({
              //   where: {
              //     assetIds: asset.id
              //   }
              // }, function (err, sharedConversations) {
              //   if (err) {
              //     console.error('SharedConversation', err)
              //   } else {
              //     app.logger.debug(sharedConversations)
              //     sharedConversations.forEach(function (sharedConversation) {
              //       logger.info(sharedConversation.subject)
              //       sharedConversation.assets.remove(asset)
              //     })
              //   }
              // })

              // Mimic the built-in delete return value
              // TODO: How do we un-delete an asset? What happens to its files?
              cb(null, {
                count: 1
              })
            }
          })
        }
      })
    }
  })

  function addCategoryIds(ctx, instance, next) {
    if (!Array.isArray(instance)) {
      instance = [instance]
    }
    // console.time('assets')
    const promises = []
    instance.forEach(function(asset) {
      const promise = new Promise(function(resolve, reject) {
        // app.logger.debug('Populating', asset.name)
        asset.categoryIds = []
        // This call shouldn't hit the DB for the /library call, since that includes a filter
        // to fetch categories already, but for other find methods, we need to fetch the objects
        asset.categories(function(err, categories) {
          if (err) {
            return reject(err)
          }
          categories.forEach(function(category) {
            // app.logger.debug(asset.name, 'Adding Category', category.name)
            asset.categoryIds.push(category.id)
          })
          // While we're here, let's do the same for tags
          // This is inside the categories() call because relations don't support promises yet
          asset.tagIds = []
          asset.tags(function(err, tags) {
            if (err) {
              return reject(err)
            }
            tags.forEach(function(tag) {
              // app.logger.debug(asset.name, 'Adding Tag', tag.name)
              asset.tagIds.push(tag.id)
            })
            // Finally, resolve the promise
            resolve()
          })
        })
      })
      promises.push(promise)
    })
    Promise.all(promises).then(function() {
      // app.logger.debug('Done')
      // console.timeEnd('assets')
      next()
    })
  }
  Asset.afterRemote('find', addCategoryIds)
  Asset.afterRemote('findById', addCategoryIds)
  Asset.afterRemote('__get__library', addCategoryIds)
}
