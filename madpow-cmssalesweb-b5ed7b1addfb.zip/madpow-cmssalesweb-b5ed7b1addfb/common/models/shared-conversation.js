'use strict'

const juice = require('juice')
const path = require('path')
const pug = require('pug')

module.exports = function (SharedConversation) {
  SharedConversation.observe('before save', function (ctx, next) {
    // Ignore already created instances
    if (!ctx.isNewInstance) {
      return next()
    }
    // When a Shared Conversation is created from the REST API using the /SharedConversations endpoint,
    // a User ID is not automatically added, so we add one here using the access token
    // NOTE: In order to have this happen automatically, we'd need to create a relation on the User model
    // for SharedConversation and then use the /UserProfile/{id}/sharedConversation endpoint. THat's how
    // the $owner gets set.
    if (ctx.options.accessToken && ctx.options.accessToken.id) {
      if (ctx.instance) {
        ctx.instance.userId = ctx.options.accessToken.userId
      } else if (ctx.data) {
        ctx.data.userId = ctx.options.accessToken.userId
      }
      return next()
    } else {
      var e = new Error('Authorization required')
      e.status = e.statusCode = 401
      e.code = 'AUTH_REQUIRED'
      return next(e)
    }
  })

  SharedConversation.observe('after save', function (ctx, next) {
    // The 'after save' hook can be called without `ctx.instance` (via `updateAll()`) so check for it here
    // Be sure we're only acting on newly created instances
    if (ctx.instance && ctx.isNewInstance) {
      const app = SharedConversation.app
      const conversation = ctx.instance
      const template = pug.compileFile(path.resolve(app.get('views'), 'shared-conversation.pug'))

      // NOTE: Since this server binds to localhost only, and nginx does the
      // actual public facing hosting, we will use a hard-coded config value
      // (in /server/config.js) to set the base URL
      const urlBase = app.get('baseUrl')
      const url = conversation.url = urlBase + '/shared/' + conversation.id

      // You know what would make this better? Promises.
      conversation.assets((err, assets) => {
        if (err) {
          return next(err)
        }
        conversation.user((err, user) => {
          if (err) {
            return next(err)
          }
          const html = template(
            {
              conversation: conversation,
              assets: assets,
              user: user
            }
          )

          // Inline CSS and some images (like icons). This doesn't do as much
          // streamlining as we could if we handled mail server-side, but it's
          // a start. Inlined images are base64 encoded, and there is no text
          // version of the email available.
          juice.juiceResources(html, { webResources: { images: false }}, function (err, inlineHtml) {
            if (err) {
              return next(err)
            }
            conversation.html = inlineHtml
            next()
          })
        })
      })
    } else {
      next()
    }
  })
}
