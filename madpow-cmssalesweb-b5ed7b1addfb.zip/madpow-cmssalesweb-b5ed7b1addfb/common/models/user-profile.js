'use strict'

const path = require('path')
const pug = require('pug')
const async = require('async')

module.exports = function (UserProfile) {
  // Use Pug to render templates by overriding the loopback templateFn (which is hard-coded to use ejs)
  function templateFn (options, cb) {
    let compile = pug.compileFile(options.template)
    let body = compile(options)
    console.log(body)
    cb(null, body)
  }

  // TODO: Update this to enforce @espn.com domain in production mode
  // TODO: This should probably be an app configuration value
  let passwordCheck = /^(?=.*[a-zA-Z])(?=.*\d)[A-Za-z0-9-+_!@#$%^&*.,?]{8,50}$/
  let emailCheck = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/

  // UserProfile.validatesFormatOf('password', {
  //   with: passwordCheck,
  //   message: 'That password is in an invalid format.',
  // })
  UserProfile.validatesFormatOf('email', {
    with: emailCheck,
    message: 'That email address is invalid. Please enter an ESPN email address (name@espn.com).'
  })
  // There really should be a better way to update the default messages ...
  // let validators = [].concat(UserProfile.validations.email, UserProfile.validations.username)
  // for (let v = 0; v < validators.length; v++) {
  //   let validator = validators[v]
  //   if (validator.validation === 'uniqueness') {
  //     validator.message = 'A user with this e-mail address has already been created.'
  //   }
  // }

  UserProfile.beforeRemote('find', function (ctx, instance, next) {
    // NOTE: Removed default limit since we're using client-side paging and sorting
    // if (!ctx.args.filter || !ctx.args.filter.limit) {
    //   let limit = UserProfile.app.get('defaults').pagination.limit || 25
    //   if (!ctx.args.filter) ctx.args.filter = {}
    //   ctx.args.filter.limit = limit
    // }
    if (!ctx.args.filter) ctx.args.filter = {}
    ctx.args.filter.include = [
      {
        relation: 'favoriteAssets',
        scope: {
          'deleted': false
        }
      },
      {
        relation: 'conversations',
        scope: {
          'deleted': false
        }
      }
    ]
    next()
  })

  // Need to define and disable remote methods here since the boot script
  // gets overwritten when the model is attached
  UserProfile.getApp(function (err, app) {
    if (err) {
      throw err
    }

    let ACL = app.models.ACL
    let Role = app.models.Role
    let RoleMapping = app.models.RoleMapping

    // Ensure we have an administrator role available
    Role.findOrCreate({ name: 'administrator' })

    // Deny access to 'addToRole'/'removeFromRole' to everyone
    ACL.findOrCreate({
      model: UserProfile.modelName,
      principalType: ACL.USER,
      principalId: ACL.EVERYONE,
      property: 'addToRole',
      accessType: ACL.EXECUTE,
      permission: ACL.DENY
    })
    ACL.findOrCreate({
      model: UserProfile.modelName,
      principalType: ACL.USER,
      principalId: ACL.EVERYONE,
      property: 'removeFromRole',
      accessType: ACL.EXECUTE,
      permission: ACL.DENY
    })
    // Ensure that the `administrator` role has full access.
    ACL.findOrCreate({
      model: UserProfile.modelName,
      principalType: ACL.ROLE,
      principalId: 'administrator',
      property: ACL.ALL,
      accessType: ACL.ALL,
      permission: ACL.ALLOW
    })

    UserProfile.hasMany(
      Role,
      {
        through: RoleMapping,
        foreignKey: 'principalId'
      }
    )

    // Remove unwanted remote methods that we are overriding
    UserProfile.disableRemoteMethodByName('prototype.__create__roles')
    UserProfile.disableRemoteMethodByName('prototype.__delete__roles')
    UserProfile.disableRemoteMethodByName('prototype.__link__roles')
    UserProfile.disableRemoteMethodByName('prototype.__unlink__roles')
    UserProfile.disableRemoteMethodByName('prototype.__findById__roles')
    UserProfile.disableRemoteMethodByName('prototype.__updateById__roles')
    UserProfile.disableRemoteMethodByName('prototype.__destroyById__roles')
    UserProfile.disableRemoteMethodByName('prototype.__exists__roles')

    /**
     * Add the user to the given role by name.
     *
     * @param {string} roleName
     * @param {Function} callback
     */
    UserProfile.prototype.addToRole = function (roleName, callback) {
      var error
      var userId = this.id
      Role.findOne(
        {
          where: { name: roleName }
        },
        function (err, role) {
          if (err) {
            return callback(err)
          }

          if (!role) {
            error = new Error('Role ' + roleName + ' not found.')
            error['http_code'] = 404
            return callback(error)
          }

          RoleMapping.findOne(
            {
              where: {
                principalId: userId,
                roleId: role.id
              }
            },
            function (err, roleMapping) {
              if (err) {
                return callback(err)
              }

              if (roleMapping) {
                return callback()
              }

              role.principals.create(
                {
                  principalType: RoleMapping.USER,
                  principalId: userId
                },
                callback
              )
            }
          )
        }
      )
    }
    UserProfile.remoteMethod(
      'addToRole',
      {
        description: 'Add User to the named role',
        accessType: 'WRITE',
        isStatic: false,
        accepts: [
          {
            arg: 'roleName',
            type: 'string',
            required: true,
            description: 'Name of the role to add.',
            http: {
              source: 'path'
            }
          }
        ],
        http: {
          path: '/roles/:roleName',
          verb: 'put'
        }
      }
    )

    /**
     * Remove the user from the given role by name.
     *
     * @param {string} roleName
     * @param {Function} callback
     */
    UserProfile.prototype.removeFromRole = function (roleName, callback) {
      var error
      var userId = this.id
      Role.findOne(
        {
          where: { name: roleName }
        },
        function (err, role) {
          if (err) {
            return callback(err)
          }

          if (!role) {
            error = new Error('Role ' + roleName + ' not found.')
            error['http_code'] = 404
            return callback(error)
          }

          RoleMapping.findOne(
            {
              where: {
                principalId: userId,
                roleId: role.id
              }
            },
            function (err, roleMapping) {
              if (err) {
                return callback(err)
              }

              if (!roleMapping) {
                return callback()
              }

              roleMapping.destroy(callback)
            }
          )
        }
      )
    }
    UserProfile.remoteMethod(
      'removeFromRole',
      {
        description: 'Remove User to the named role',
        accessType: 'WRITE',
        isStatic: false,
        accepts: [
          {
            arg: 'roleName',
            type: 'string',
            required: true,
            description: 'Name of the role to remove.',
            http: {
              source: 'path'
            }
          }
        ],
        http: {
          path: '/roles/:roleName',
          verb: 'delete'
        }
      }
    )

    // Ensure a default Global Administrator user exists
    let adminUser = app.get('administrator')
    console.log('Checking for default administrator ...')
    UserProfile.findOrCreate({
      where: {
        email: adminUser.email
      },
      include: 'roles'
    }, adminUser, function (err, instance, created) {
      if (err) {
        console.log(err)
      } else {
        if (created) {
          // No need to verify this user (TODO: or is there?)
          instance.verificationToken = null
          instance.emailVerified = true
          console.log('Creating default admin user ...')
          instance.save(function (err, admin) {
            if (err) {
              throw err
            }
            console.log('Addming admin user to \'administrator\' role ...')
            admin.addToRole('administrator')
          })
        } else {
          console.log('Administrator already exists.')
          instance.roles(function (err, roles) {
            if (err) {
              console.log(err)
            } else {
              let exists = roles.some(function (role) { return role.name === 'administrator' })
              if (!exists) {
                console.log(`Adding ${instance.firstName} ${instance.lastName} to administrator role ...`)
                instance.addToRole('administrator')
              }
            }
          })
        }
      }
    })
  })

  UserProfile.afterRemote('create', function (ctx, instance, next) {
    let app = UserProfile.app
    let options = {
      type: 'email',
      to: instance.email,
      from: app.get('fromEmail'),
      subject: 'ESPN SalesCenter – New Account',
      template: path.resolve(__dirname, '../../server/views/verify.pug'),
      templateFn: templateFn,
      protocol: 'https',
      host: app.get('baseHost'),
      port: 443,
      redirect: '/profiles/reset',
      installHref: app.get('baseUrl') + '/install',
      user: instance
    }

    instance.verify(options, (err, response) => {
      if (err) {
        console.log(err)
        UserProfile.deleteById(instance.id)
        return next(err)
      }
      console.log('Verification email sent!', response.email.response.toString('utf8'))
      next()
    })
  })

  UserProfile.afterRemote('confirm', function (ctx, unused, next) {
    let userId = ctx.args.uid
    UserProfile.findById(userId, function (err, user) {
      if (!err) {
        UserProfile.resetPassword({ email: user.email, skipEmail: true }, function (err) {
          if (err) {
            return next(err)
          }
          UserProfile.once('resetPasswordRequest', function (info) {
            let redirect = (ctx.args && ctx.args.redirect) ? ctx.args.redirect : ''
            redirect += redirect.indexOf('?') === -1 ? '?' : '&'
            redirect += 'access_token=' + info.accessToken.id + '&firstTime=true'
            // Redirect the redirect, adding the reset password token
            ctx.res.location(redirect)
            next()
          })
        })
      } else {
        console.log(err)
        next(err)
      }
    })
  })

  UserProfile.afterRemoteError('confirm', function (ctx, next) {
    if (ctx.error && ctx.error.code === 'INVALID_TOKEN') {
      if (ctx.args && ctx.args.uid) {
        // Find the user ID listed in the request
        UserProfile.findById(ctx.args.uid, function (err, user) {
          if (err) {
            console.log(err)
            return next(err)
          }
          if (user) {
            // Settings form model.config aren't inherited
            let UserModel = UserProfile.app.models.User
            // Check if the email address has been verified already
            if (UserModel.settings.emailVerificationRequired && !user.emailVerified) {
              // Send a new verification email
              let app = UserProfile.app
              let options = {
                type: 'email',
                to: user.email,
                from: app.get('fromEmail'),
                subject: 'ESPN Sales App – Verify Account',
                template: path.resolve(__dirname, '../../server/views/verify.pug'),
                templateFn: templateFn,
                protocol: 'https',
                host: app.get('baseHost'),
                port: 443,
                redirect: '/profiles/verified',
                user: user
              }

              user.verify(options, (err, response) => {
                if (err) {
                  console.log(err)
                  UserProfile.deleteById(user.id)
                  return next(err)
                }
                console.log('Verification email sent!', response.email.response.toString('utf8'))
                ctx.res.redirect('/login')
              })
            } else {
              console.log('Email already verified, proceeding to login ...')
              // Email has been verified, send the user to the login page
              ctx.res.redirect('/login')
            }
          } else {
            console.log('User not found, proceeding to login ...')
            // No user found, redirect to login page
            ctx.res.redirect('/login')
          }
        })
      }
    } else {
      // Show the error - something else has gone wrong
      next()
    }
  })

  UserProfile.afterRemoteError('resetPassword', function (ctx, next) {
    // Override the 'Email not found' error so clients can't use it to
    // farm email addresses
    if (ctx.error && ctx.error.code === 'EMAIL_NOT_FOUND') {
      ctx.res.sendStatus(200)
    }
    next()
  })

  UserProfile.on('resetPasswordRequest', function (info) {
    let app = UserProfile.app
    let Email = UserProfile.email || app.models.Email
    let urlBase = app.get('baseUrl')
    let url = urlBase + '/profiles/reset'
    let resetUrl = url + '?access_token=' + info.accessToken.id
    if (!info.options.skipEmail) {
      let template = path.resolve(__dirname, '../../server/views/reset.pug')
      let compile = pug.compileFile(template)
      let html = compile({
        resetHref: resetUrl,
        installHref: app.get('baseUrl') + '/install'
      })

      Email.send({
        to: info.email,
        from: app.get('fromEmail'),
        subject: 'ESPN SalesCenter – Reset Password',
        html: html
      }, function (err) {
        if (err) {
          console.log('Error sending email')
        }
        console.log('Email sent to', info.email)
      })
    }
  })

  function validateToken (tokenId, callback) {
    let AccessToken = UserProfile.app.models.AccessToken
    if (tokenId) {
      AccessToken.findById(tokenId, function (err, token) {
        if (err) {
          return callback(err)
        } else if (token) {
          token.validate(function (err, isValid) {
            if (err) {
              return callback(err)
            } else if (isValid) {
              return callback(null, token)
            } else {
              var e = new Error('Invalid Access Token')
              e.status = e.statusCode = 401
              e.code = 'INVALID_TOKEN'
              return callback(e)
            }
          })
        } else {
          var e = new Error('Can\'t find Access Token')
          e.status = e.statusCode = 401
          e.code = 'INVALID_TOKEN'
          return callback(e)
        }
      })
    } else {
      var e = new Error('Missing Access Token')
      e.status = e.statusCode = 401
      e.code = 'MISSING_TOKEN'
      return callback(e)
    }
  }

  UserProfile.beforeRemote('replacePassword', function (ctx, instance, next) {
    if (ctx.args.credentials.accessToken) {
      let tokenId = ctx.args.credentials.accessToken
      validateToken(tokenId, function (err, result) {
        if (err) {
          return next(err)
        }
        ctx.args.credentials.accessToken = result
        next()
      })
    } else {
      var e = new Error('Missing Access Token')
      e.status = e.statusCode = 401
      e.code = 'MISSING_TOKEN'
      next(e)
    }
  })

/**
 * Reset a user's password. Requires a valid short-term auth token.
 * @param {string} password The new password to set.
 * @param {string} confirmPassword The same password, for validation purposes.
 * @param {Function(Error)} callback
 */

  UserProfile.replacePassword = function (credentials, callback) {
    if (!credentials.password ||
      !credentials.confirmPassword ||
      credentials.password !== credentials.confirmPassword) {
      let e = new Error('Passwords do not match')
      e.status = e.statusCode = 400
      e.code = 'PASSWORD_MATCH'
      return callback(e)
    }
    if (!credentials.password.match(passwordCheck)) {
      let e = new Error('Invalid password')
      e.status = e.statusCode = 400
      e.code = 'INVALID_PASSWORD'
      return callback(e)
    }
    UserProfile.findById(credentials.accessToken.userId, function (err, user) {
      if (err) {
        let e = new Error('User not found')
        e.status = e.statusCode = 404
        e.code = 'USER_NOT_FOUND'
        return callback(e)
      }
      user.updateAttribute('password', credentials.password, function (err) {
        if (err) {
          let e = new Error('User not found')
          e.status = e.statusCode = 404
          e.code = 'USER_NOT_FOUND'
          return callback(e)
        }
        return callback(err, user)
      })
    })
  }

  /**
  * Change the user's password
  * @param {string} currentPassword User's current password
  * @param {string} newPassword New password to set
  * @param {string} verifyPassword Validation field
  * @param {Function(Error, object)} callback
  */

  UserProfile.prototype.changePassword = function (currentPassword, newPassword, verifyPassword, callback) {
    let userObj = this
    if (newPassword !== verifyPassword) {
      let e = new Error('These passwords don\'t match. Please try again.')
      e.status = e.statusCode = 400
      e.code = 'PASSWORD_MATCH'
      return callback(e)
    }
    userObj.hasPassword(currentPassword, function (err, isMatch) {
      if (err) {
        return callback(err)
      }
      if (!isMatch) {
        let e = new Error('Invalid password')
        e.status = e.statusCode = 401
        e.code = 'INVALID_PASSWORD'
        return callback(e)
      }
      if (!newPassword.match(passwordCheck)) {
        let e = new Error('Invalid password')
        e.status = e.statusCode = 400
        e.code = 'INVALID_PASSWORD'
        return callback(e)
      }
      // The password will be automatically hashed before saving
      userObj.updateAttribute('password', newPassword, function (err) {
        if (err) {
          return callback(err)
        } else {
          return callback(null, userObj)
        }
      })
    })
  }

  /**
   * Mark a descendant conversation as 'dismissed' so it won't show when requesting this user's conversation list.
   * @param {string} fk The ID of the conversation to dismiss
   * @param {Function(Error)} callback
   */

  UserProfile.prototype.dismissDescendantConversation = function (fk, callback) {
    if (!this.dismissedConversations || !this.dismissedConversations.some(value => value.equals(fk))) {
      this.updateAttribute('$push', { 'dismissedConversations': fk }, function (err, instance) {
        if (err) {
          return callback(err)
        }
        callback()
      })
    }
  }

  UserProfile.beforeRemote('*.__get__conversations', function (ctx, result, next) {
    if (!ctx.args.filter) ctx.args.filter = {};
    if (ctx.args.filter.include && ctx.args.filter.include.length) {
      let dismissed = ctx.instance.dismissedConversations
      if (dismissed) {
        for (let f = 0; f < ctx.args.filter.include.length; f++) {
          let include = ctx.args.filter.include[f]
          if (include.relation && include.relation === 'descendants') {
            if (!include.scope) include.scope = {}
            if (!include.scope.where) {
              include.scope.where = {
                id: {
                  nin: dismissed
                }
              }
            }
            break
          }
        }
      }
    }
    next()
  })

  UserProfile.afterRemote('*.__get__conversations', function (ctx, result, next) {
    if (ctx.result && ctx.result.length) {
      async.each(ctx.result, function (conversation, cb) {
        conversation.reorderAssets(cb)
      }, function (err) {
        next(err)
      })
    } else {
      next()
    }
  })

  // Check if platform/version was passed in, and save it if so (and it's valid)
  UserProfile.afterRemote('login', function (ctx, result, next) {
    if (!ctx.args || !ctx.args.credentials) {
      return next()
    }
    if (!ctx.args.credentials.platform) {
      return next()
    }
    const platform = ctx.args.credentials.platform.toLowerCase().trim()
    if (platform !== 'ios' && platform !== 'android') {
      console.error('Invalid platform:', platform)
      return next()
    }
    if (!ctx.args.credentials.version) {
      return next()
    }
    const version = ctx.args.credentials.version.toLowerCase().trim()
    if (version.match(/(\d+)\.(\d+)\.(\d+)\s+(.*)/) === null) {
      console.error('Invalid version:', version)
      return next()
    }
    UserProfile.update({ id: result.userId }, {
      platform: platform,
      version: version
    }, next)
  })
}
