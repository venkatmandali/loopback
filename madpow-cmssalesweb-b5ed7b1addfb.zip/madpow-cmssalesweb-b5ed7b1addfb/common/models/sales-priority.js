'use strict'

const _ = require('lodash')

module.exports = function (SalesPriority) {
  SalesPriority.validatesUniquenessOf('assetId')

  SalesPriority.afterRemote('find', function (ctx, result, next) {
    // Filter out any results without assets, with deleted assets, and duplicate assets
    ctx.result = _.uniqWith(_.filter(result, function (item) {
      // Getting the JSON will give direct access to the asset, since it was loaded via the scope's `include` filter
      let priority = item.toJSON()
      // Ensure the item has a non-deleted asset
      // The `deleted` check should be unnecessary because of the scope, but we've learned to be wary of scopes
      return priority.asset && priority.asset.deleted === false
    }), function (itemA, itemB) {
      // We need to use ObjectID.equals() here
      // We use toJSON() again so we don't have to use the async asset() call, and we
      // already have the asset from the `include` filter
      return itemA.toJSON().asset.id.equals(itemB.toJSON().asset.id)
    })
    next()
  })
}
