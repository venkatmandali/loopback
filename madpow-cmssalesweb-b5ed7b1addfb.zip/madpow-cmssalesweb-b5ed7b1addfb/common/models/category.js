'use strict'

module.exports = function (Category) {
  // Disable the POST and DELETE verbs for the 'all' scope
  Category.disableRemoteMethodByName('__create__all')
  Category.disableRemoteMethodByName('__delete__all')

  // Ensure names are unique
  Category.validateAsync('name', validateName, {
    message: 'This category has already been created. Please enter another name.'
  })

  function validateName (err, next) {
    if (!this.name) {
      return err()
    }

    let regex = '/^' + this.name + '$/i'
    let where = {
      and: [
        { name: { regexp: regex } },
        { isTopLevel: this.isTopLevel }
      ]
    }
    if (this.parentId) {
      where.and.push({ parentId: this.parentId })
    }
    if (this.id) {
      where.and.push({
        id: {
          neq: this.id
        }
      })
    }

    Category.find({
      where: where
    }, function (error, result) {
      if (error || result.length) {
        err()
      }
      return next()
    })
  }

  Category.observe('after save', function (ctx, next) {
    let categoryId, parentId, isTopLevel
    if (ctx.instance) {
      categoryId = ctx.instance.id
      parentId = ctx.instance.parentId ? ctx.instance.parentId : null
      isTopLevel = ctx.instance.isTopLevel ? ctx.instance.isTopLevel : false
    } else if (ctx.where) {
      categoryId = ctx.where.id
      parentId = ctx.data.parentId ? ctx.data.parentId : null
      isTopLevel = ctx.data.isTopLevel ? ctx.data.isTopLevel : false
    }
    // Find any previous parents
    Category.findOne({
      where: {
        categoryIds: categoryId
      }
    }).then(function (oldParent) {
      // If a previous parent was found, and its ID does not match, remove the relation
      if (oldParent && (isTopLevel || !oldParent.id.equals(parentId))) {
        return oldParent.children.remove(categoryId).then(function () {
          return oldParent
        })
      } else {
        return oldParent
      }
    }).then(function (oldParent) {
      if (parentId) {
        // If we have a parentId, but it matches the previous one, continue
        if (oldParent && oldParent.id.equals(parentId)) {
          return null
        }
        // Now add the category to its new parent
        return Category.findById(parentId).then(function (parent) {
          if (parent) {
            return parent.children.add(categoryId)
          }
        })
      }
    }).then(function () {
      return next()
    }).catch(function (err) {
      return next(err)
    })
  })

  Category.observe('before delete', function (ctx, next) {
    console.log(ctx)
    let categoryId = ctx.where.id
    Category.findById(categoryId, function (err, category) {
      if (err) {
        return next(err)
      }
      console.log('Found category', category.name)
      category.assets(function (err, assets) {
        if (err) {
          return next(err)
        }
        console.log('Found', assets.length, 'assets')
        assets.forEach(function (asset) {
          console.log('Removing asset', asset.name)
          category.assets.remove(asset)
        })
      })
      // category.children(function (err, children) {
      //   children.forEach(function (child) {
      //     console.log('Deleting child', child.name)
      //     category.children.destroy(child.id)
      //   })
      // })
    })
    next()
  })
  Category.observe('after delete', function (ctx, next) {
    let categoryId = ctx.where.id
    console.log('Deleting children of', categoryId.toString())
    Category.find({
      where: {
        parentId: categoryId
      }
    }, function (err, children) {
      if (err) {
        return next(err)
      }
      console.log('Found', children.length, 'children')
      // If we call delete() on each model instance, we will get the ID in
      // the where clause above, allowing for a cascading delete.
      // Bulk deletes (via deleteAll()) don't provide IDs of deleted records
      // This is somewhat inefficient, but it's unlikely there will be a
      // large enough number of nested categories to make an impact
      children.forEach(function (child) {
        console.log('Deleting category', child.name)
        child.delete()
      })
    })
    next()
  })

  Category.afterRemote('deleteById', function (ctx, result, next) {
    Category.all(function (err, categories) {
      if (err) {
        return next(err)
      }
      result.categories = categories
      return next()
    })
  })

  // TODO: The proper way to filter on related models doesn't work
  // When this PR is merged, the below should work as expected
  // https://github.com/strongloop/loopback-datasource-juggler/pull/1522
  // Category.beforeRemote('*.__get__assets', function (ctx, instance, next) {
  //   ctx.args.filter = {
  //     where: {
  //       deleted: false
  //     }
  //   }
  //   next()
  // })

  Category.afterRemote('*.__get__assets', function (ctx, result, next) {
    ctx.result = result.filter(asset => asset.deleted === false)
    next()
  })
}
