'use strict'

const app = require('../../server/server')
const async = require('async')

module.exports = function (Conversation) {
  Conversation.on('dataSourceAttached', function (obj) {
    // Override the delete method to set the 'deleted' flag instead
    Conversation.deleteById = function (id, options, cb) {
      Conversation.findById(id, function (err, conversation) {
        if (err) {
          cb(err)
        } else {
          conversation.updateAttribute('deleted', true, function (err) {
            if (err) {
              cb(err)
            } else {
              // Mimic the built-in delete return value
              cb(null, {
                count: 1
              })
            }
          })
        }
      })
    }
  })

  /**
   * Force all Conversations create/update methods to get fresh Assets
   * The default scope doesn't work on create() at all, and there is a
   * bug with cached relation data. The workaround, which invovles passing
   * a boolean 'refresh' value to the relation accessors, also does not
   * work, at least for 'relatesToMany' relations.
   *
   * See: https://github.com/strongloop/loopback/issues/1094
   * See: https://github.com/strongloop/loopback/issues/2257
   */
  Conversation.observe('after save', function (ctx, next) {
    if (ctx.instance) {
      ctx.instance.reorderAssets(() => {
        if (ctx.instance.parentId) {
          // console.log('after save')
          // console.log('Instance ID:', ctx.instance.id)
          // console.log('Parent ID:', ctx.instance.parentId)
          // The relation doesn't work yet, need to grab the parent conversation manually
          Conversation.findById(ctx.instance.parentId, (err, target) => {
            if (err) {
              return next(err)
            }
            // console.log('Updating target ...')
            // console.log('Target ID:', target.id)
            target.updateAttributes({
              accepted: ctx.instance.accepted,
              rejected: ctx.instance.rejected
            }, (err) => {
              // console.log('Target updated')
              return next(err)
            })
          })
          // ctx.instance.target.update({
          //   accepted: ctx.instance.accepted,
          //   rejected: ctx.instance.rejected
          // }, (err) => {
          //   return next(err)
          // })
        } else {
          return next()
        }
      })
    } else {
      return next()
    }
  })

  Conversation.prototype.reorderAssets = function reorderAssets (callback) {
    if (this.assetIds) {
      let Asset = app.models.Asset
      Asset.find({
        where: {
          id: {
            inq: this.assetIds
          },
          deleted: false
        }
      }, (err, assets) => {
        if (err) {
          return callback(err)
        }
        let orderedAssets = []
        // Ensure that the assets array is in the same order as the 'assetIds' array
        for (let assetId of this.assetIds) {
          let asset = assets.find(function (item) {
            return item.id.equals(assetId)
          })
          if (asset) {
            orderedAssets.push(asset)
          }
        }
        // Override everything
        this.__cachedRelations.assets = this.__data.assets = orderedAssets
        callback()
      })
    } else {
      // If a Conversation has no assetIds, just make sure the cached assets are removed
      this.__cachedRelations.assets = this.__data.assets = null
      callback()
    }
  }

  /**
   * Share a Conversation with an existing User
   * @param {array} userIds The IDs of any valid recipients
   * @param {string} comment A comment to be shown to the recipient(s) prior to accepting this Conversation
   * @param {Function(Error)} callback
   */
  Conversation.prototype.share = function (userIds, comment, callback) {
    const shareConversation = (userId, next) => {
      // Create the intermediary conversation
      // console.log('Creating first copy ...')
      Conversation.create({
        name: this.name,
        summary: this.summary,
        conversationDate: this.conversationDate,
        shared: true,
        sharedOn: new Date(),
        // userId: this.userId,
        creatorId: this.userId,
        originalId: this.id,
        assetIds: this.assetIds
      }, (err, clone) => {
        if (err) {
          return next(err)
        }
        // console.log('Clone ID:', clone.id, 'Creating second clone ...')
        Conversation.create({
          name: this.name,
          summary: this.summary,
          conversationDate: this.conversationDate,
          shared: true,
          sharedOn: new Date(),
          userId: userId,
          creatorId: this.userId,
          // originalId: this.id,
          parentId: clone.id,
          assetIds: this.assetIds
        }, (err, target) => {
          // console.log('Second clone created')
          // console.log('Target ID:', target.id)
          next()
        })
      })
    }
    async.each(userIds, shareConversation, callback)
  }

  /**
   * Accept a Conversation share from another User
   * @param {Function(Error)} callback
   */
  Conversation.prototype.accept = function (callback) {
    const validation = this.validateAcceptOrReject()
    if (validation === true) {
      this.accepted = true
      this.acceptedOn = new Date()
      this.save(callback)
    } else if (validation instanceof Error) {
      callback(validation)
    } else {
      const error = new Error('An error has occurred.')
      error.status = error.statusCode = 400
      error.code = 'UNSPECIFIED_ERROR'
      callback(error)
    }
  }

  /**
   * Reject a Conversation share from another User
   * @param {Function(Error)} callback
   */
  Conversation.prototype.reject = function (callback) {
    const validation = this.validateAcceptOrReject()
    if (validation === true) {
      this.rejected = true
      this.rejectedOn = new Date()
      // Mark the conversation as deleted, but don't actually delete it from the database
      // This allows us to track shares and rejects, but prevents the conversation from showing up in the apps
      this.deleted = true
      this.save(callback)
    } else if (validation instanceof Error) {
      callback(validation)
    } else {
      const error = new Error('An error has occurred.')
      error.status = error.statusCode = 400
      error.code = 'UNSPECIFIED_ERROR'
      callback(error)
    }
  }

  Conversation.prototype.validateAcceptOrReject = function () {
    if (this.shared === false) {
      const error = new Error('This Conversation has not been shared.')
      error.status = error.statusCode = 400
      error.code = 'NOT_SHARED'
      return error
    }
    if (this.accepted === true) {
      const error = new Error('This Conversation has already been accepted.')
      error.status = error.statusCode = 400
      error.code = 'ALREADY_ACCEPTED'
      return error
    }
    if (this.rejected === true) {
      const error = new Error('This Conversation has already been rejected.')
      error.status = error.statusCode = 400
      error.code = 'ALREADY_REJECTED'
      return error
    }

    return true
  }

  /**
   * Dismiss a conversation from the Conversations list
   * @param {Object} options object, populated from the current context
   * @param {Function(Error)} callback
   */

  Conversation.prototype.dismiss = function (options, callback) {
    let conversationId = this.id
    let UserProfile = Conversation.app.models.UserProfile
    if (options && options.accessToken) {
      // We need to use the UserProfile class because `options.accessToken.user()` refers to the base `User` model, which doesn't work since there's no collection for that model
      UserProfile.findById(options.accessToken.userId, function (err, user) {
        if (err) {
          return callback(err)
        }
        if (user) {
          user.dismissDescendantConversation(conversationId, function (err) {
            callback(err)
          })
        } else {
          let e = new Error('Invalid request.')
          e.statusCode = 401
          callback(e)
        }
      })
    }
  }
}
