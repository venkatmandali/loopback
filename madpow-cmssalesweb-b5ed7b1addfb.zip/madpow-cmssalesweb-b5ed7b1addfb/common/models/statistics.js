'use strict';

module.exports = function(Statistics) {

  Statistics.disableRemoteMethodByName("create");
  Statistics.disableRemoteMethodByName("exists");
  Statistics.disableRemoteMethodByName("upsert");
  Statistics.disableRemoteMethodByName("upsertWithWhere");
  Statistics.disableRemoteMethodByName("updateAll");
  Statistics.disableRemoteMethodByName("replaceById");
  Statistics.disableRemoteMethodByName("replaceOrCreate");
  Statistics.disableRemoteMethodByName("deleteById");

  Statistics.disableRemoteMethodByName("prototype.updateAttributes");
  Statistics.disableRemoteMethodByName("prototype.replaceAttributes");

};
