'use strict'

const AWS = require('aws-sdk')
const path = require('path')
const fs = require('fs')
const sharp = require('sharp')
const ffmpeg = require('fluent-ffmpeg')

const buttonPlay = path.resolve(__dirname, '../', 'deployables/button_play.svg')
// Set the bucket name via AWS_BUCKET environment variable, or through NODE_ENV. Defaults to 'cmssales-dev'
const bucket = process.env.AWS_BUCKET ? process.env.AWS_BUCKET : process.env.NODE_ENV === 'production' ? 'cmssales' : 'cmssales-dev'

console.log('Using S3 bucket:', bucket)

AWS.config.loadFromPath(path.resolve(__dirname, '../server/aws.json'))

const S3 = new AWS.S3({
  Bucket: bucket
})

// Fetch all the objects in the assetStorage folder
S3.listObjectsV2({
  Bucket: bucket,
  Prefix: 'assetStorage'
}, function(err, data) {
  if (err) {
    console.error(err)
  } else {
    if (data.Contents) {
      // Get all the videos (you can't filter by suffix or regex on S3)
      const videos = data.Contents.filter(item => {
        const ext = path.extname(item.Key)
        return ext === '.mp4' || ext === '.m4v'
      }).map(item => {
        const ext = path.extname(item.Key)
        const filenameBase = path.basename(item.Key, ext)
        const thumbnail = filenameBase + '_thumb.png'
        // const dest = path.resolve(__dirname, 'thumbnails', thumbnail)

        console.log('Fetching thumbnail:', thumbnail)
        // Fetch each thumbnail, if it exists
        S3.getObject({
          Bucket: bucket,
          Key: 'assetStorage/' + thumbnail
        }, (err, result) => {
          if (err) {
            // We could use S3.headObject() to check if the file exists, but this error handler does the same thing
            console.error('Error fetching file:', thumbnail, err)
          } else {
            // We can pass the Buffer to sharp for overlaying
            sharp(result.Body)
              .png()
              .overlayWith(buttonPlay)
              .toBuffer()
              .then(data => {
                // Save the thumbnail back to S3, overwriting the existing file
                // S3 will version the change automatically
                console.log('Thumbnail ready, uploading to S3 ...', thumbnail)
                S3.putObject({
                  Bucket: bucket,
                  Key: 'assetStorage/' + thumbnail,
                  Body: data,
                  ContentType: 'image/png', // Need to specify ContentType and ACL or the new thumbnail will be inaccessible
                  ACL: 'public-read'
                }, (err, result) => {
                  if (err) {
                    throw err
                  } else {
                    console.log('Upload success!', thumbnail)
                    console.log(result)
                  }
                })
              })
              .catch(err => {
                console.error('Error converting file:', err)
              })
          }
        })
      })
    }
  }
})
