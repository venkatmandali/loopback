'use strict'

const AWS = require('aws-sdk')
const fs = require('fs')
const path = require('path')
const sanitize = require('sanitize-filename')
const bucket = process.env.AWS_BUCKET
  ? process.env.AWS_BUCKET
  : process.env.NODE_ENV === 'production'
    ? 'cmssales'
    : 'cmssales-dev'
const cutoffDate = new Date('Jun 7, 2018')

AWS.config.loadFromPath(path.resolve(__dirname, '../server/aws.json'))

const S3 = new AWS.S3({
  Bucket: bucket
})

const log = fs
  .readFileSync('./assets.log', 'utf8')
  .toString()
  .split('\n')
const assets = []
const toDelete = []
const listPromises = []

log.forEach(line => {
  const match = line.match(/Upload success! (.*)/)
  if (match) {
    assets.push(match[1])
  }
})

console.log(`Processing ${assets.length} assets ...`)
assets.forEach(asset => {
  // const rawAssetName = asset.match(/assetStorage\/(.*)/)[1]
  // const assetName = sanitize(rawAssetName)
  // console.log(`Fetching: ${rawAssetName}`)
  // if (assetName !== rawAssetName) {
  //   console.log(`Renaming to: ${assetName}`)
  // }

  // const file = fs.createWriteStream('./assetStorage/' + assetName)
  // S3.getObject({ Bucket: bucket, Key: asset }, (err, data) => {
  //   // console.log(data)
  // })
  //   .createReadStream()
  //   .pipe(file)

  console.log(`Checking ${asset} versions ...`)
  listPromises.push(
    S3.listObjectVersions({ Bucket: bucket, Prefix: asset }, (err, object) => {
      if (object.Versions && object.Versions.length) {
        const curr = object.Versions[0]
        const del = { Key: asset, VersionId: curr.VersionId }
        const found = toDelete.some(
          val => val.Key === del.Key && val.VersionId === del.VersionId
        )
        if (!found) {
          // console.log(asset, curr.IsLatest, curr.VersionId, curr.LastModified)
          toDelete.push(del)
          console.log(`Adding ${asset} to delete list`, toDelete.length)
          return curr
        }
      }
    })
      .promise()
      .then(result => {
        if (result) {
          console.log(
            `Verified: ${asset}: ${result.VersionId}, ${result.IsLatest}`
          )
        } else {
          console.log(`Didn't add ${asset}`)
        }
      })
      .catch(e => console.error(asset, e.message))
  )
})

Promise.all(listPromises).then(() => {
  console.log(`Deleting ${toDelete.length} objects ...`)
  // console.log(toDelete)
  S3.deleteObjects(
    { Bucket: bucket, Delete: { Objects: toDelete } },
    (err, result) => {
      console.log(result)
    }
  )
})
