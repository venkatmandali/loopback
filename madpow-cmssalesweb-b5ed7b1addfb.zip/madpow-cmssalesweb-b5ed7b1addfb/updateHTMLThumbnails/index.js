'use strict'

const AWS = require('aws-sdk')
const path = require('path')
const fs = require('fs')
const util = require('util')
const sizeOf = require('buffer-image-size')
const sharp = require('sharp')
const config = require('../server/config.json').assets

const overlay = path.resolve(__dirname, '../', 'deployables/cropOverlay.png')
// Set the bucket name via AWS_BUCKET environment variable, or through NODE_ENV. Defaults to 'cmssales-dev'
const bucket = process.env.AWS_BUCKET
  ? process.env.AWS_BUCKET
  : process.env.NODE_ENV === 'production'
    ? 'cmssales'
    : 'cmssales-dev'
const cutoffDate = new Date('Jun 7, 2018')

console.log('Using S3 bucket:', bucket)
console.log('Max height set to:', config.htmlMaxHeight)
console.log('Width set to:', config.htmlThumbWidth)

AWS.config.loadFromPath(path.resolve(__dirname, '../server/aws.json'))

const S3 = new AWS.S3({
  Bucket: bucket
})

// Fetch all the HTML objects in the assetStorage folder
S3.listObjectsV2(
  {
    Bucket: bucket,
    Prefix: 'assetStorage/html-'
  },
  function(err, data) {
    if (err) {
      console.error(err)
    } else {
      if (data.Contents) {
        // Get all the thumbnails (you can't filter by suffix or regex on S3)
        const thumbs = data.Contents.filter(item => {
          const ext = path.extname(item.Key)
          return (
            ext === '.png' && item.LastModified.getTime() < cutoffDate.getTime()
          )
        })
        console.log(`Processing ${thumbs.length} thumbnails ...`)
        thumbs.map(item => {
          const thumbnail = item.Key
          console.log('Fetching thumbnail:', thumbnail)
          // Fetch each thumbnail, if it exists
          S3.getObject(
            {
              Bucket: bucket,
              Key: thumbnail
            },
            (err, result) => {
              if (err) {
                // We could use S3.headObject() to check if the file exists, but this error handler does the same thing
                console.error('Error fetching file:', thumbnail, err.message)
              } else {
                // Get dimensions
                const dimensions = sizeOf(result.Body)
                if (dimensions.height >= config.htmlMaxHeight) {
                  console.log(
                    'Processing:',
                    thumbnail,
                    'Original dimensions:',
                    dimensions
                  )
                  let resizePromise
                  const adjustedWidth =
                    dimensions.width *
                    (config.htmlMaxHeight / dimensions.height)
                  if (adjustedWidth < config.htmlThumbWidth) {
                    resizePromise = sharp(result.Body)
                      .resize(config.htmlThumbWidth, config.htmlMaxHeight)
                      .background({
                        r: 0,
                        g: 0,
                        b: 0,
                        alpha: 0
                      })
                      .embed(sharp.gravity.north)
                      .overlayWith(overlay, {
                        gravity: sharp.gravity.south
                      })
                      .png()
                      .toBuffer()
                  } else {
                    resizePromise = sharp(result.Body)
                      .resize(config.htmlThumbWidth, config.htmlMaxHeight)
                      .withoutEnlargement()
                      .max()
                      .overlayWith(overlay, {
                        gravity: sharp.gravity.south
                      })
                      .png()
                      .toBuffer()
                  }
                  resizePromise
                    .then(data => {
                      // Save the thumbnail back to S3, overwriting the existing file
                      // S3 will version the change automatically
                      console.log(
                        'Thumbnail ready, uploading to S3 ...',
                        thumbnail
                      )
                      S3.putObject(
                        {
                          Bucket: bucket,
                          Key: thumbnail,
                          Body: data,
                          ContentType: 'image/png', // Need to specify ContentType and ACL or the new thumbnail will be inaccessible
                          ACL: 'public-read'
                        },
                        (err, result) => {
                          if (err) {
                            throw err
                          } else {
                            console.log('Upload success!', thumbnail)
                            console.log(result)
                          }
                        }
                      )
                    })
                    .catch(err => {
                      console.error(
                        'Error converting file:',
                        thumbnail,
                        dimensions,
                        err,
                        result
                      )
                    })
                }
              }
            }
          )
        })
      }
    }
  }
)
