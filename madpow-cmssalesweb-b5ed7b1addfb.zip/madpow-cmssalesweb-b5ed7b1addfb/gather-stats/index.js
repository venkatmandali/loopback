#!/opt/bitnami/nodejs/bin/node

'use strict'

const args = process.argv.slice(2)
const fs = require('fs')
const moment = require('moment')
const mongo = require('mongodb').MongoClient
const mailer = require('nodemailer')
const path = require('path')
const pug = require('pug')
const ds = require('../server/datasources.json')
const url = `mongodb://${ds.espncmssales.user}:${ds.espncmssales.password}@${
  ds.espncmssales.host
}:${ds.espncmssales.port}/${ds.espncmssales.database}`

const transport = ds.emailDs.transports[0]
const transporter = mailer.createTransport(transport)

let dateArg
if (args.length && moment(args[0]).isValid()) {
  dateArg = moment(args[0])
  console.log('Using date:', dateArg.format())
}

// Set up the variables we will output
const stats = {
  totalConversations: 0,
  totalSharedConversations: 0,
  totalInternalSharedConversations: 0,
  topSharedAssets: [],
  topFavoritedAssets: [],
  topActiveUsers: []
}

let totalConversationsPipeline = [
  {
    $lookup: {
      from: 'UserProfile',
      localField: 'userId',
      foreignField: '_id',
      as: 'user'
    }
  },
  {
    $match: {
      userId: {
        $nin: [null, ''],
        $exists: true
      },
      'user.email': {
        $not: /madpow/i
      }
    }
  },
  {
    $group: {
      _id: null,
      count: {
        $sum: 1
      }
    }
  }
]

if (dateArg) {
  totalConversationsPipeline[1]['$match']['createdDate'] = {
    $lte: dateArg.toDate()
  }
}

let totalSharedConversationsPipeline = [
  {
    $lookup: {
      from: 'UserProfile',
      localField: 'userId',
      foreignField: '_id',
      as: 'user'
    }
  },
  {
    $match: {
      userId: {
        $nin: [null, ''],
        $exists: true
      },
      'user.email': {
        $not: /madpow/i
      },
      recipients: {
        $not: /madpow/i
      }
    }
  },
  {
    $group: {
      _id: null,
      count: {
        $sum: 1
      }
    }
  }
]

if (dateArg) {
  totalSharedConversationsPipeline[1]['$match']['createdDate'] = {
    $lte: dateArg.toDate()
  }
}

let totalInternalSharedConversationsPipeline = [
  {
    $lookup: {
      from: 'UserProfile',
      localField: 'userId',
      foreignField: '_id',
      as: 'user'
    }
  },
  {
    $match: {
      shared: true,
      userId: {
        $nin: [null, ''],
        $exists: true
      },
      'user.email': {
        $not: /madpow/i
      }
    }
  },
  {
    $group: {
      _id: null,
      count: {
        $sum: 1
      }
    }
  }
]

if (dateArg) {
  totalInternalSharedConversationsPipeline[1]['$match']['createdDate'] = {
    $lte: dateArg.toDate()
  }
}

let topSharedAssetsPipeline = [
  {
    $lookup: {
      from: 'UserProfile',
      localField: 'userId',
      foreignField: '_id',
      as: 'user'
    }
  },
  {
    $match: {
      'user.email': {
        $not: /madpow/i
      }
    }
  },
  {
    $unwind: '$assetIds'
  },
  {
    $group: {
      _id: '$assetIds',
      count: { $sum: 1 }
    }
  },
  {
    $sort: {
      count: -1
    }
  },
  {
    $limit: 20
  },
  {
    $lookup: {
      from: 'Asset',
      localField: '_id',
      foreignField: '_id',
      as: 'asset'
    }
  },
  {
    $project: {
      'asset.name': 1,
      count: 1
    }
  }
]

if (dateArg) {
  topSharedAssetsPipeline[1]['$match']['createdDate'] = {
    $lte: dateArg.toDate()
  }
}

let topFavoritedAssetsPipeline = [
  {
    $match: {
      email: {
        $not: /madpow/i
      }
    }
  },
  {
    $unwind: '$assetIds'
  },
  {
    $group: {
      _id: '$assetIds',
      count: { $sum: 1 }
    }
  },
  {
    $sort: {
      count: -1
    }
  },
  {
    $limit: 20
  },
  {
    $lookup: {
      from: 'Asset',
      localField: '_id',
      foreignField: '_id',
      as: 'asset'
    }
  },
  {
    $project: {
      'asset.name': 1,
      count: 1
    }
  }
]

if (dateArg) {
  topFavoritedAssetsPipeline = [
    {
      $match: {
        email: {
          $not: /madpow/i
        }
      }
    },
    {
      $unwind: '$assetIds'
    },
    {
      $lookup: {
        from: 'Asset',
        localField: '_id',
        foreignField: '_id',
        as: 'asset'
      }
    },
    {
      $project: {
        assetIds: 1,
        asset: {
          $filter: {
            input: '$asset',
            as: 'asset',
            cond: {
              $lte: ['$$asset.createdDate', dateArg.toDate()]
            }
          }
        }
      }
    },
    {
      $group: {
        _id: '$assetIds',
        count: { $sum: 1 }
      }
    },
    {
      $sort: {
        count: -1
      }
    },
    {
      $limit: 20
    },
    {
      $lookup: {
        from: 'Asset',
        localField: '_id',
        foreignField: '_id',
        as: 'asset'
      }
    },
    {
      $project: {
        'asset.name': 1,
        count: 1
      }
    }
  ]
}

let topActiveUsersPipeline = [
  {
    $match: {
      email: {
        $not: /madpow/i
      }
    }
  },
  {
    $lookup: {
      from: 'Conversation',
      localField: '_id',
      foreignField: 'userId',
      as: 'conversations'
    }
  },
  {
    $lookup: {
      from: 'SharedConversation',
      localField: '_id',
      foreignField: 'userId',
      as: 'sharedConversations'
    }
  },
  {
    $lookup: {
      from: 'Conversation',
      localField: '_id',
      foreignField: 'creatorId',
      as: 'internalSharedConversations'
    }
  },
  {
    $project: {
      email: 1,
      assetIds: 1,
      nConversations: { $size: '$conversations' },
      nShared: { $size: '$sharedConversations' },
      nInternalShared: { $size: '$internalSharedConversations' },
      nFavorites: { $size: '$assetIds' }
    }
  },
  {
    $project: {
      email: 1,
      assetIds: 1,
      nConversations: 1,
      nShared: 1,
      nInternalShared: 1,
      nFavorites: 1,
      score: {
        $sum: [
          '$nConversations',
          '$nShared',
          '$nInternalShared',
          { $divide: ['$nFavorites', 2] }
        ]
      }
    }
  },
  {
    $sort: {
      score: -1
    }
  },
  {
    $limit: 10
  }
]

if (dateArg) {
  let filter = [
    {
      $project: {
        email: 1,
        conversations: {
          $filter: {
            input: '$conversations',
            as: 'conversation',
            cond: {
              $lte: ['$$conversation.createdDate', dateArg.toDate()]
            }
          }
        },
        sharedConversations: {
          $filter: {
            input: '$sharedConversations',
            as: 'conversation',
            cond: {
              $lte: ['$$conversation.createdDate', dateArg.toDate()]
            }
          }
        },
        internalSharedConversations: {
          $filter: {
            input: '$internalSharedConversations',
            as: 'conversation',
            cond: {
              $lte: ['$$conversation.createdDate', dateArg.toDate()]
            }
          }
        },
        assetIds: 1
      }
    }
  ]
  topActiveUsersPipeline.splice(4, 0, ...filter)
}

mongo.connect(url).then(
  function(db) {
    let statsPromises = []

    statsPromises.push(
      db
        .collection('Conversation')
        .aggregate(totalConversationsPipeline)
        .next()
        .then(
          result => {
            stats.totalConversations = result ? result.count : null
          },
          error => console.log(error)
        )
    )

    statsPromises.push(
      db
        .collection('SharedConversation')
        .aggregate(totalSharedConversationsPipeline)
        .next()
        .then(
          result => {
            stats.totalSharedConversations = result ? result.count : null
          },
          error => console.log(error)
        )
    )

    statsPromises.push(
      db
        .collection('Conversation')
        .aggregate(totalInternalSharedConversationsPipeline)
        .next()
        .then(
          result => {
            stats.totalInternalSharedConversations = result
              ? result.count
              : null
          },
          error => console.log(error)
        )
    )

    statsPromises.push(
      db
        .collection('SharedConversation')
        .aggregate(topSharedAssetsPipeline)
        .toArray()
        .then(
          result => {
            stats.topSharedAssets = result.map(asset => {
              return {
                assetId: asset._id,
                name: asset.asset[0].name,
                count: asset.count
              }
            })
          },
          error => console.log(error)
        )
    )

    statsPromises.push(
      db
        .collection('UserProfile')
        .aggregate(topFavoritedAssetsPipeline)
        .toArray()
        .then(
          result => {
            stats.topFavoritedAssets = result.map(asset => {
              return {
                assetId: asset._id,
                name: asset.asset[0].name,
                count: asset.count
              }
            })
          },
          error => console.log(error)
        )
    )

    statsPromises.push(
      db
        .collection('UserProfile')
        .aggregate(topActiveUsersPipeline)
        .toArray()
        .then(
          result => {
            stats.topActiveUsers = result.map(user => {
              return {
                userId: user._id,
                email: user.email,
                score: user.score,
                conversations: user.nConversations,
                shared: user.nShared,
                internalShared: user.nInternalShared,
                favorites: user.nFavorites
              }
            })
          },
          error => console.log(error)
        )
    )

    Promise.all(statsPromises).then(
      function() {
        let now = new Date()
        stats.timestamp = dateArg ? dateArg.toDate() : now
        // let fmt = moment(now).format('YYYY-MM-DD-hhmmss')
        // let filename = path.resolve(__dirname, 'stats', `DEV-stats-${fmt}.json`)
        // fs.writeFile(filename, JSON.stringify(stats, null, 4), function (err) {
        //   if (err) {
        //     console.log(err)
        //   }
        // })

        db.collection('Statistics').insertOne(stats)

        // let template = pug.compileFile(path.resolve(__dirname, 'stats.pug'))
        // let locals = Object.assign({}, stats, {
        //   timestamp: moment().format('dddd, MMMM Do YYYY, h:mm:ss a UTC')
        // })
        // let html = template(locals)
        // let email = {
        //   from: 'info@espnsalesapp.com',
        //   to: 'mike@madpow.net',
        //   // to: 'kdunnington@madpow.net',
        //   subject: 'Stats',
        //   html: html
        // }
        // transporter.sendMail(email, (err, result) => {
        //   if (err) {
        //     console.log(err)
        //   } else {
        //     console.log(result)
        //   }
        // })
        db.close()
      },
      function(error) {
        console.error(error)
        db.close()
      }
    )
  },
  function(error) {
    console.log(error)
  }
)
