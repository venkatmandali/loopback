/**
 * This script is used to import the original statistics files
 * which were recorded on the filesystem instead of the database.
 * It should no longer be used as the import has already been done.
 */

let fs = require('fs')
let path = require('path')
let async = require('async')
let mongo = require('mongodb').MongoClient
let ds = require('../server/datasources.json')
let url = `mongodb://${ds.espncmssales.user}:${ds.espncmssales.password}@${ds.espncmssales.host}:${ds.espncmssales.port}/${ds.espncmssales.database}`

let statsDir = path.resolve(__dirname, 'stats')

function process (db) {
  let statistics = db.collection("Statistics")
  let assets = db.collection("Asset")
  let users = db.collection("UserProfile")
  users.find({}).project({ email: 1 }).toArray().then(allUsers => {
    let usersMap = new Map(allUsers.map(u => [u.email, u._id]))
    assets.find({}).project({ name: 1 }).toArray().then(allAssets => {
      let assetMap = new Map(allAssets.map(o => [o.name, o._id]))
      fs.readdir(statsDir, (err, files) => {
        let statFiles = files.filter((name, index) => { return name.indexOf('.json') > -1 })
        // Process each file asynchronously
        async.map(statFiles, (statFile, callback) => {
          let filePath = path.resolve(statsDir, statFile)
          fs.stat(filePath, (err, stats) => {
            if (err) {
              return callback(err)
            }
            let timestamp = stats.birthtime
            fs.readFile(filePath, (err, file) => {
              if (err) {
                return callback(err)
              }
              let stat = JSON.parse(file)
              // Correct for test data
              stat.totalConversations -= 253
              stat.totalSharedConversations -= 160
              stat.totalInternalSharedConversations -= 160
              // Gather up all the names used in the document
              let assetNames = stat.topSharedAssets.concat(stat.topFavoritedAssets)
              // Set the timestamp on the JSON object
              stat.timestamp = timestamp
              // Look for any existing records to avoid duplicates
              statistics.count({
                timestamp: stat.timestamp
              }).then((count) => {
                if (count) {
                  return callback(null, stat)
                }
                // Loop over the two arrays and add IDs
                assetNames.forEach(item => {
                  item.assetId = assetMap.has(item.name) ? assetMap.get(item.name) : null
                })
                // Look up all matching user IDs
                stat.topActiveUsers.forEach(user => {
                  user.userId = usersMap.has(user.email) ? usersMap.get(user.email) : null
                })
                statistics.insertOne(stat, callback)
              })
            })
          })
        }, (err, stats) => {
          if (err) { console.error(err) }
          console.log("Complete!")
          db.close()
        })
      })
    })
  })
}

mongo.connect(url).then(process)
