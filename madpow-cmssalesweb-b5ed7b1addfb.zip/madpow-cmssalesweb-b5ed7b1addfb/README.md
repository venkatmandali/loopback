# ESPN Sales App

## Setup (macOS)

1. Install Homebrew

    See [here](https://brew.sh/) for instructions

1. Update Homebrew

    `brew update`

1. Install Yarn

    `brew install yarn`

    _This will install Node if it is not already installed. If you have installed Node via a different method (installer, nvm, etc.) be sure to run `brew install yarn --without-node` instead._

    **NOTE:** This application will **not** work with Node v`10`! Be sure to use the LTS version (currently `8.11.2`) instead! Version 10 is slated to be the new LTS in October, 2018, and dependencies will hopefully be updated by then (especially `bcrypt`, `fsevents` and `sharp`).

1. Install supporing libraries (for thumbnail generation)

    `brew install imagemagick ghostscript poppler ffmpeg`

1. Install MongoDB

	  `brew install mongodb`

    The default path is `/data/db`, optionally create your own `/Users/<USERNAME>/Databases/MongoDB`.

1. Run mongod

	  `mongod`

    _Optionally_: `mongod --dbpath /Users/<USERNAME>/Databases/MongoDB`

1. Shutdown

    `mongod --shutdown`

### Remote Repository

To deploy any changes, you must set up remotes for your local git repository. Make sure you have the ESPN Lightsail SSH key (`LightsailDefaultPrivateKey.pem`)

1. Create/edit the file `~/.ssh/config` to resemble the following:

        Host *
          PreferredAuthentications publickey
          ServerAliveInterval 120
          UseKeychain yes
          AddKeysToAgent yes
          ForwardAgent yes
          IdentitiesOnly yes

        Host aws-espn
          HostName 34.199.179.177
          User bitnami
          IdentityFile /Users/<your username>/.ssh/LightsailDefaultPrivateKey.pem
          LocalForward 8010 127.0.0.1:443
          LocalForward 9010 127.0.0.1:9001

        Host aws-espn-dev
          HostName 34.196.22.149
          User bitnami
          IdentityFile /Users/<your username>/.ssh/LightsailDefaultPrivateKey.pem
          LocalForward 8000 127.0.0.1:443
          LocalForward 9000 127.0.0.1:9001

1. Add a remote to the git repository

        git remote add dev bitnami@aws-espn-dev:~/projects/espn.git

      This expects that you've successfully set up an ssh alias for the dev server as `aws-espn-dev`, like in the example above.

## Setup (Windows)

1. Get a Mac

## Local Workflow

1. Start the local front-end server
    * `yarn run webdev`
    * Starts a webpack-dev-server instance that recompiles and hot-reloads the client application
    * Client is accessible via http://localhost:8080
    * Default login credentials are in /server/config.json under "administrator" block. If using an imported database (from dev or prod), this will likely be different.

1. In a second terminal, start the back-end server
    * `yarn run server`
    * Starts the loopback server using nodemon to watch for file changes in the /server or /common folders
    * Available for debugging via Chrome dev tools (or similar devtool-compatible tools)

1. Make changes and test as needed
    * Commit changes to origin
    * Commit changes to dev
      * This will run the git hook, which checks out the latest branch, installs any dependencies, and gracefully restarts the PM2 instance.

## Folder structure

| Path                          | Description                                                                                          |
| ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| `/asset`                      |
| `../downloads`                | Mobile app installers and version files                                                              |
| `../editor-templates`         | WYSIWYG editor template files                                                                        |
| `../uploads`                  |
| `../../assetStorage`          | Temporary work area for uploaded assets                                                              |
| `/client`                     | Client application (AngularJS)                                                                       |
| `/common`                     |
| `../models`                   | Loopback Model files (config & custom code)                                                          |
| `/deployables`                | Various server-specific config files, see README.md                                                  |
| `../lightsail-auto-snapshots` | AWS Lambda Function for server backup                                                                |
| `../db-backup`                | Database backup script (run by cron)                                                                 |
| `/gather-stats`               | Small application (run by cron) to record and mail various statistics                                |
| `/server`                     | All server-specific (Loopback) functionality                                                         |
| `../views`                    | [Pug](https://pugjs.org/) templates for server views                                                 |
| `../config.json`              | Loopback configuration file                                                                          |
| `../config.local.js`          | Local override for configuration settings                                                            |
| `../config.production.json`   | Production override for configuration settings. Overrides are determined by the value of `NODE_ENV`. |

## Dev/Prod Server Information

The application server is an Amazon Web Services LightSail instance running Ubuntu 14.04 via a Bitnami MEAN Stack install.

The AWS credentials used for the LightSail instance and S3 uploads are:

    "key": "nGe6KrVaIWQ5JXyvrMKKh9zpHqOqejzm8wEOmRFJ",
    "keyId": "AKIAJKTRIPQ5GXLVMDNQ"

The application uses [PM2](http://pm2.keymetrics.io) for process management, under the ID 'API'.

In order to install ffmpeg, a `PPA` was added using 

`sudo add-apt-repository ppa:mc3man/trusty-media`

Additional packages installed (using `apt`):

    imagemagick
    ghostscript
    poppler-utils

Repository build scripts use Yarn, which can be installed by following the instructions [here](https://yarnpkg.com/lang/en/docs/install/).

## Production Server-specific Notes

The Production server has a few different settings from development that must be preserved when upgrading.

1. Several active cron jobs run to populate the statistics collection and perform regular database backups. The crontab looks like this:
    ```
    # Every Friday at 5pm EST
    0 12 * * 5 /home/bitnami/projects/cmssalesweb/deployables/db-backup
    # Every day at 3am
    0 3 * * * /home/bitnami/projects/cmssalesweb/gather-stats/index.js
    ```
1. The files above need to have their permissions set to allow execution
    ```
    chmod +x deployables/db-backup
    chmod +x gather-stats/index.js
    ```
1. The email address in `gather-stats/index.js` should be set to `mike@madpow.net`.
2. If the application is stopped, the environment should be set when calling PM2:
    ```
    pm2 start deployables/espn.config.js --env production
    ```

The server software stack consists of:

* [LoopBack](http://loopback.io/)
* [MongoDB](https://www.mongodb.com/)
* [nginx](http://nginx.org/en/)

The web client is written in [AngularJS](https://angularjs.org/) using ES6 syntax, transpiled by Babel / Webpack.

Deployment is done using a git hook (see [workflow](#local-workflow) above).
